---
name: chub-tagger
description: Generate appropriate tags for SillyTavern/Chub.ai character cards. Use when the user requests tags for a character they're preparing to upload, says "I need tags for this character," or when finalizing character card uploads to Chub.ai.
---

# Chub Tagger

Generate optimal tag suggestions for SillyTavern character cards being uploaded to Chub.ai. Tags are organized by category with roughly popularity-ordered listings within each category.

## Tag Selection Process

### Step 1: Read the ENTIRE Card

**CRITICAL:** Read the complete character card before tagging — every field, every greeting, every lorebook entry. Do not skim. Do not eyeball. Important details often appear in:
- Later greetings (greeting 3 might reveal the character is secretly a vampire)
- Lorebook entries (may contain crucial worldbuilding or character facts)
- Creator's notes or personality fields
- Example dialogues

Missing details because they weren't in the first paragraph leads to incomplete tagging.

### Step 2: Load the Tag Database

Read `references/tags.md` before making suggestions. Contains all curated tags organized by category, plus a glossary of confusing terms.

### Step 3: Analyze the Character

After reading the full card, consider these aspects:

- **Core Identity:** Species/race, gender, character origin (OC, Anime Character, etc.), setting/genre
- **Personality:** Dominance/submission, archetypes (Yandere, tsundere, etc.), behavioral traits, emotional states
- **Relationships & Roles:** Role types (Maid, teacher, girlfriend), relationship dynamics, social position
- **Physical Attributes:** Body type, height, notable features
- **Content Flags:** NSFW/SFW status, POV support, themes, kinks
- **Format:** Number of greetings, scenario type, special mechanics

### Step 4: Select Tags by Category

Pull tags from relevant categories in tags.md:
- Content Rating & POV (required)
- Gender & Identity
- Species & Fantasy Races
- Physical Attributes
- Age Categories
- Personality & Behavior
- Relationships & Roles
- Settings & Genres
- Themes & Scenarios
- Kinks & Fetishes (when relevant)
- Character Origins
- Format & Meta Tags

**Tag quantity guidance:**
- Aim for at least one tag per relevant category (don't force tags that don't fit)
- There is NO upper limit — more accurate tags = better discoverability
- If a character legitimately spans many categories, tag all of them
- Prioritize tags that appear earlier in each category list (higher popularity)
- Don't stretch to fill categories that genuinely don't apply

**Synonym/variant coverage:**
When the database has multiple tags meaning roughly the same thing, use ALL of them. Users follow different tags even for the same concept:
- "catgirl" AND "Cat Girl"
- "OC" AND "Original Character"
- "anypov" AND "Any POV"
- "Furry" AND "Anthro" (if both apply)
- "Monster Girl" AND "monstergirl"
- "Sci-fi" AND "Science Fiction"
- "thick" AND "Thicc" AND "thick thighs"

Don't pick one — use every applicable variant for maximum discoverability.

### Step 5: Verify Special Cases

**Mother tags - CRITICAL:**
Only use Mother, Mommy, Mom, Dommy Mommy, Muscle Mommy, or motherly when the character IS a mother (has children). NOT for maternal/nurturing characters or "mommy dom" dynamics without actual parenthood.

**Teenager tag:**
18-19 year old characters ONLY (legal adults). Never for minors.

**POV tags (required):**
Always include at least one: Malepov, Fempov, anypov/Any POV. For POV-flexible characters, use BOTH anypov AND Any POV for coverage.

**Duplicate/variant coverage:**
See synonym guidance in Step 4 — use ALL applicable variants, not just one.

**Capitalization:**
Tags are case-sensitive on Chub. Match exactly as listed in tags.md.

### Step 6: Format the Output

```
**Suggested Tags for [Character Name]:**

**From Database:**
[Tag 1], [Tag 2], [Tag 3], [Tag 4], [Tag 5], [Tag 6], [Tag 7], [Tag 8]

**Suggested New Tags (verify/create on Chub):**
[Tag A], [Tag B], [Tag C]
```

Follow with:
1. Brief explanation of major tag choices
2. Definitions for any confusing slang terms (reference the glossary)
3. Reminder to verify suggested new tags exist or create them

### Step 7: Consider New Tags

For traits not covered in the database, suggest new tags users could create:

**Good candidates for new tags:**
- Specific personality traits not in database
- Niche settings or scenarios
- Character-specific mechanics
- Franchise/IP names (users uploading IP content know to tag it)

**Guidelines:**
- Use lowercase unless proper noun
- Keep simple (1-2 words)
- Follow patterns from existing tags
- Mark clearly as "verify/create on Chub"

## Examples

**Example 1: High Fantasy Knight Character**

Character: Female knight, loyal protector, can be romantic or platonic, multiple greetings

**From Database:**
Female, Fantasy, Female Knight, Warrior, Romance, Roleplay, OC, Original Character, loyal, anypov, Any POV, Multiple Greetings, Medieval

**Suggested New Tags:**
armor, swordfighter

*Tags chosen for: core fantasy genre coverage, role identification, POV flexibility, format features.*

---

**Example 2: Modern Yandere Girlfriend**

Character: Obsessive girlfriend, stalker tendencies, NSFW possible, dominant

**From Database:**
Female, Yandere, girlfriend, Obsessive, stalker, Dominant, Romance, NSFW, Modern day, Possessive, Malepov, OC, Original Character

**Suggested New Tags:**
None needed — well covered by database tags.

*Note: "Yandere" means obsessively possessive to the point of violence/extreme behavior.*

---

**Example 3: Furry Catgirl Cafe Worker**

Character: Shy catgirl working at a cafe, wholesome with NSFW potential, anthro design

**From Database:**
Female, Furry, catgirl, Cat Girl, Anthro, shy, Cute, Wholesome, SFW <-> NSFW, Roleplay, anypov, Any POV, OC, Original Character

**Suggested New Tags:**
cafe, barista

---

**Example 4: Dark Content Warning Example**

Character: Manipulative demon with mind control themes, explicitly dark content

**From Database:**
Female, Demon, Dominant, manipulative, Mind Control, mind break, Dark fantasy, NSFW, Dead Dove, Corruption, Evil, Malepov, OC, Original Character

**Suggested New Tags:**
None needed.

*Note: "Dead Dove" signals dark/disturbing content — warns readers "you were warned, don't complain." Use for genuinely dark themes.*