# Chub.ai Tags Reference

This file contains curated tags for Chub.ai character uploads, organized by category. Tags within each category are roughly ordered by popularity (most followed first).

## Usage Notes

- **Prioritize high-popularity tags** for maximum discoverability
- **Multiple similar tags are intentional** for coverage (e.g., "OC" and "Original Character", "anypov" and "Any POV")
- **"Mother" tags** (Mother, Mommy, Mom, Dommy Mommy, Muscle Mommy, motherly) should ONLY be used when the character IS a mother (has children), not just maternal/nurturing
- **"Teenager" tag** is for 18-19 year old characters only (legal adults)
- **Spelling and capitalization must be exact** — Chub tags are case-sensitive

---

## Content Rating & POV Tags

### Content Ratings
NSFW, SFW <-> NSFW, can be wholesome, can be sexy, Wholesome, SFW, Smut, Lewd, can be wholesome, Extreme-NSFW, Hardcore NSFW, R18, SuperNSFW

### POV Tags
Malepov, Fempov, anypov, Any POV, Futapov, MonsterPov, Femboypov, blackpov, Male or Female, AnimalPov, beastpov, NeutralPov, bullpov, milfpov, slavepov, demihuman pov, humanpov, pokemonpov, victim pov

---

## Gender & Identity

Female, Male, Transgender, Non-Human, Human, Bisexual, Lesbian, Gay🏳️‍🌈, gay, mlm, WLW, Trans, Futapov, futanari, Genderswap, gender bender, Genderbend, Gender Swap, Trans Female, 🏳️‍⚧️ Trans, non-binary, nonbinary, Transfem, mtf, FTM Trans, ftm, intersex, cuntboy, Hermaphrodite, Dickgirl

---

## Species & Fantasy Races

### Common Species
Human, Furry, Anthro, Monster Girl, Demon, Elf, Vampire, succubus, Dragon, Alien, Robot, Ghost, Angel, Witch, Goddess, monstergirl, demihuman, Feral, Scalie, Demi-Human, werewolf, zombie, Goblin girl, Kitsune, Foxgirl, Wolfgirl, catgirl, Cat Girl, dog girl, Bunny Girl, Dragon Girl, Demon Girl, Robot Girl, Alien Girl, Slime, Kobold, Orc, Fairy, Lamia, Centaur, Harpy, Dullahan, Oni, Hellhound, Minotaur, Minotaur Girl, Spider Girl, Snake Girl, Insect girl, slime girl, Mousegirl, Cow Girl, Rat Girl, fox girl, Bird Girl, Clown girl, bee girl, Rabbit Girl, Bug Girl, Wolf Girl, horse girl, ghost girl, sharkgirl, plant girl, Moth, skunkgirl, Wendigo, Imp, Xenomorph, Cryptid, Gynoid

### Furry-Specific
Anthro, Feral, Scalie, Anthropomorphic Animals, kemonomimi, Anthropomorphic, Dog, Wolf, Horse, cat, fox, Bunny, Bear, Pony, Bird, deer, Rabbit, pig, Bee, shark, Canine, Feline, equine, mare, avian, reptile, protogen

### Mythological & Supernatural
Goddess, God, Demon, Angel, Vampire, werewolf, Ghost, Witch, Kitsune, Dragon, Fairy, Tentacles, Eldritch, Supernatural, Youkai, Yokai, Spirit, Devil, Genie, fallen angel, Deity, Elemental

---

## Physical Attributes

### Body Type & Build
Muscular, Chubby, Petite, Fat, thick, Thicc, Curvy Figure, Voluptous, bbw, Shortstack, obese, Skinny, plump, curvy, SSBBW, ussbbw, Slightly chubby

### Height
Tall woman, Giantess, tall, short, Size Difference, Sizeplay, Mini Giantess, Giant, shrink, shrinking, Macrophilia, minigirl, miniguy, micro, microphilia

### Breasts
Huge Breasts, Big Breast, large breasts, Big boobies, big breasts, Massive Breasts, Flat Chest, small breasts, big tits, huge boobs, big boobs, Gigantic Breasts, Hyper Breasts, small breast, Boobs bigger than head, small tits big ass, Busty Boy

### Butt & Hips
Big Butt, Huge Butt, Huge Ass, Massive Ass, thick thighs, wide hips, Big thighs, Hyper Butt, Fat Ass, Large Butt, Thick Ass, huge thighs, gigantic ass, massive butt, large ass, Huge Bubble Butt, bubble butt, PAWG

### Other Physical
Muscular Female, Strong Woman, Dark-Skinned, Tanned, blonde, Redhead, Black, Asian, Latina, black hair, White Hair, Blonde Hair, Pink Hair, Red Hair, Long Hair, Short Hair, Blue Eyes, Red Eyes, Freckles, Tattoos, Scars, glasses, Tanlines, Hairy Pussy, Pubic Hair, hairy, Hairy Pubes, hairy armpits, Long Tongue, Big Lips, Horns, Fluffy Tail, Animal Ears, Plumpy lips, bimbo lips

---

## Age Categories

Teenager, Milf, Mature, Older female, Gilf, Older Woman, young adult, Hag, College Student, college, Adult, grown woman, Mature woman, adult woman, cougar, Almost a Milf

**Note:** "Teenager" is for 18-19 year old characters ONLY (legal adults).

---

## Personality & Behavior

### Dominance/Submission
Dominant, Submissive, Dominant <-> Submissive, femdom, switch, Gentle Femdom, Dommy Mommy, Soft Femdom, maledom, dominatrix, Sub, Femsub, Power bottom, bratdom, Gentle Femboydom, soft submissive, Obedient, submissive female, Malesub, dominant female, femboydom

### Personality Archetypes
Yandere, tsundere, Kuudere, Brat, Sadistic, shy, Obsessive, Possessive, manipulative, bratty, Evil, Psychopath, clingy, Dumb, Aggressive, Crazy, Insane, Naive, smug, Stupid, Airhead, Clumsy, nerd, nerdy, Sweet, kind, caring, Gentle, Loving, Friendly, Playful, Cheerful, Adorable, Confident, stoic, emotionless, Cold, Grumpy, Mean, Rude, bitchy, Arrogant, Toxic, awkward, Silly, Introvert, insecure, Autistic, Energetic, Sassy, Mysterious, quiet, Devoted, Shameless, Pathetic, ditzy, Gullible, mischievous, Annoying, desperate

### Mental States
Depressed, Lonely, Mental illness, Abuse Victim, Bully Victim, traumatized, suicidal, anxiety, Trauma, Depression, schizophrenia, PTSD, autism, Low self-esteem, self-loathing, Broken, Melancholic

### Sexual Behavior
horny, Pervert, Virgin, Seductive, Flirty, innocent, Perverted, Nympho, Nymphomaniac, Slutty, slut, Sexually Frustrated, Needy, Exhibitionist, Nudist, whore, cum addict, Porn Addict, Sex addict, gooner, Goonette, Gooning, Degenerate, Shameless Coombot, Undeniably a coom bot, Cock Worship, cock addict, Secretly Horny

---

## Relationships & Roles

### Family Roles
Mother, Mommy, Mom, Sister, Daughter, Big Sister, Aunt, Grandmother, Grandma, Father, Brother, Big brother, Older Sister, younger sister, Twin sister, Cousin, grandmother, granny, stepmother, Stepsister, Step Daughter, Stepdaughter, Step-Sister, Stepmom, Stepdad, adoptive mother, Sister-in-law, Single mother, Loving mother, bad mom, imouto

### Romantic Roles
girlfriend, Wife, Boyfriend, Husband, Loving wife, Married, childhood friend, roommate, best friend, Enemies to Lovers, Friends to Lovers, ex-girlfriend, Sexfriend, Friends with benefits

### Professional/Social Roles
Maid, teacher, student, Slave, Villain, Goddess, Princess, Royalty, Noble, queen, Warrior, Police Officer, nurse, doctor, Soldier, Assassin, Criminal, idol, Celebrity, babysitter, Neighbor, Classmate, streamer, Boss, secretary, CEO, Butler, Servant, Bartender, Waitress, Office lady, Prostitute, pornstar, Escort, stripper, bodyguard, Dancer, Singer, Mercenary, Samurai, Ninja, Knight, Female Knight, Prince, Priestess, Priest, nun, Model, Cosplayer, Farmer, scientist, Detective, Professor, Therapist, Psychologist, Wrestler, Fighter, Athlete, youtuber, Twitch Streamer, Livestreamer, OnlyFans Model, Actress, Musician, Artist, Gamer, Gamer Girl, Gym Gal, Cheerleader, Housewife

### Dynamics
Master-Servant, student-teacher, Petplay, Pet Play, Harem, Threesome, Group, Gangbang, Orgy, oyakodon, Mother and Daughter, Mother and Son, Father-daughter, Dad and son, Older Brother, Sibling, twins, Twincest

---

## Settings & Genres

### Time Periods
Fantasy, Modern day, Medieval, Sci-fi, Science Fiction, Cyberpunk, Post-apocalypse, Historical, Victorian, Feudal Japan, Steampunk, Futuristic, Future, Wild West, post-apocalyptic, Urban Fantasy, Modern Fantasy, Historical fantasy, Alternative History

### Genres
Romance, Horror, Dark fantasy, Adventure, Action, Comedy, Drama, Mystery, Slice of Life, Angst, Isekai, Superhero, Psychological Horror, Survival, Sandbox, RPG, Simulation, Dating, life simulation, Visual Novel, Gothic Horror, Cosmic Horror, Lovecraftian, Grimdark, Dystopian, dystopia, Xianxia, Wuxia, Cultivation

### Settings
School, Highschool, college, University, Military, Prison, Mafia, yakuza, Cult, Brothel, Hospital, Office, gym, beach, Farm, Space, hell, Dungeon

---

## Themes & Scenarios

### Romance/Relationship Themes
Romance, Love, Romantic, True Love, Wholesome, Fluff, Cuddles, Slowburn, Arranged Marriage, Forbidden Love, Established Relationship, polyamory, Toxic Relationship, Betrayal, Affair

### Dark Themes
Horror, Violent, Violence, Abuse, Abusive, Kidnapping, Kidnapper, Kidnapped, Blackmail, Murder, Murderer, serial killer, Death, War, Cannibal, Captive, Prisoner, Imprisonment, revenge, cruel, Betrayal, Trauma

### Power Dynamics
Slave, sex slavery, slavery, slave girl, Master-Servant, Corruption, Defeated, Domination, Domination Loss, submission, Captive, Brainwashed, Hypnotized, Mind Control, brainwashing, Hypnosis, mind control, mind break, Body control, Personality control, common sense modification

### Transformation
transformation, Genderswap, gender bender, Gender Swap, Body modification, body transformation, body swap, Bodyswap, Growth, Breast Expansion, Butt Expansion, Dick Growth, muscle growth, Expansion, shrink, shrinking, feminization, forced feminization, Bimbofication, sissification, sissyfication, tf, forced transformation, gender transformation, new body

### Infidelity Themes
NTR, Netori, Cheating, Cuckolding, Netorare, anti-NTR, netorase, Reverse NTR, Post-NTR, Cuckquean, hotwife, cuck, cuckold, Motherly Cuckold, Cucked Female, NTR Avoidable, NTR Revenge, Kinda Netori, Homewrecker

---

## Kinks & Fetishes

### Common Kinks
BDSM, Bondage, Breeding Kink, breeding, Impregnation, Humiliation, Fetish, kinky, exhibitionism, Lactation, freeuse, Free Use, Petplay, Pet Play, Feet, Foot Fetish, Feet Fetish, Footjob, Foot Worship, Tentacles, Pregnant, Pregnancy, Hypnosis, mind control, Corruption

### Size Play
Size Difference, Sizeplay, Giantess, shrink, shrinking, Macrophilia, Giant, minigirl, miniguy, micro, microphilia, Mini Giantess

### Vore & Related
oral vore, cock vore, soft vore, breast vore, unbirth vore, tail vore, Hard vore, Analvore, vore prey, vore pred, digestion, disposal vore

### Body Worship
Feet, Foot Fetish, Feet Fetish, Footjob, Foot Worship, armpits, Sweat, musk, Musky, smelly, Stinky Feet, sweat and musk, smelly feet, body odor, Sniffing, Scent, smell fetish, ass worship, Ball Worship, Cock Worship

### Bodily Functions
Lactation, Breastfeeding, breast milk, BreastMilk, milking, Male milking, semen milking, Milk, Watersports, pissplay, pissing, Urine, Urination, peeing, piss drinking, pissfetish, Omorashi, Farts, facefarting, gassy, Burping, Burp, Vomit, Squirting

### Inflation & Expansion
Cum Inflation, Cumflation, belly stuffing, bellyinflation, Breast Expansion, Butt Expansion, Growth, huge belly, muscle growth, hyper pregnancy, breast inflation, belly expansion, blueberry inflation, stuffing, forced inflation, inflated, weightgain, Big Belly, Expansion

### Pain & Extreme
Sadistic, Masochistic, Masochist, sadomasochistic, ryona, cbt, cock and ball torture, Ballbusting, Castration, Painslut, spanking, Rough Sex, brutal

### Domination Types
femdom, maledom, Gentle Femdom, Soft Femdom, Dommy Mommy, dominatrix, bratdom, Gentle Futadom, femboydom, Gentle Femboydom, findom, grossdom

### Oral
Blowjobs, Blowjob, Deepthroat, Fellatio, fellatrix, Oral fixation, oral, Cunnilingus, Rimjob, Rimming, gokkun, cum eating, Eat cum, cum drinking, THROATGOAT, Blowjob Machine

### Specific Fetishes
Breeding Kink, breeding, Impregnation, Pregnancy, Pregnant, excessive cum, huge dick, Big cock, huge cock, Hyper, hyper cock, Huge balls, big balls, hyperspermia, creampie, cum, Cum Fetish, Cumplay, cumslut, bukkake, Paizuri, titfuck, Onahole, sex toys, chastity, chastity cage, Latex, Rubber, collared, Bodysuit, stockings, pantyhose, swimsuit, Bikini, Nudist, casual nudity, Public Nudity, ENF, exhibitionism, Exhibitionist, voyeurism, voyeur, Public Sex, Hidden Sex, Public Masturbation, Masturbation, Mutual Masturbation, caught masturbating, Orgasm Denial, Orgasm Control, Edging, joi, jerk off instructions, praise kink, Daddy Kink, Mommy kink, dirty talk

### Taboo Dynamics
Incest, stepcest, Twincest, wincest, Family, oyakodon, Mother and Son, Father-daughter, Dad and son, Brocon, step incest, Pseudo-Incest, inbreeding, Family Bonding

### Racial Fetish Tags
bbc, BWC, bnwo, WMAF, qos, queen of spades, Snowbunny, Interracial, ebony, Queen of Hearts

### Miscellaneous Fetishes
Petplay, Pet Play, Submissive Petplay, Daddy Kink, Mommy kink, Breeding Farm, Human Livestock, hucow, Breeding Mount, Forniphilia, Feederism, Feeder, feedee, forcefeeding, stuffing, tickling, Tickle, Wrestling, gloryhole, Bukkake, oviposition, Egg laying, birth, somnophilia, sleep sex, sleeping, Timestop, freeuse, Free Use, casual sex, Sex with strangers, Chikan, Public Sex, stuck in wall, stuck, Clothing Entrapment, trapped in clothes, living clothing, living suit, Skinsuit, Body possession, possession, symbiote, plushie, plushophilia, Inanimate Object, Sentient Object, sex doll, Living Doll, Doll, Onahole, onahole rooms, hypno, Hypnotist, Aphrodisiac, in heat, Heat Cycles, Heat, Knot, knotting

---

## Character Origins

OC, Original Character, Fictional Character, Fictional, Game Characters, Anime Character, Anime Game Characters, Video Game, video game character, Game Character, Cartoon character, TV Character, Movie Character, Book Character, Doujinshi Character, Visual Novel Character, Comic Characters, Fan Character, VTuber, V-Tuber, hentai, Manga, Anime, Cartoon, doujin, hentai manga character

---

## Format & Meta Tags

### Greetings/Scenarios
Multiple Greetings, Multiple Scenarios, Scenario, Roleplay, Multiple Characters, Multiple Girls, Multiple Men, two characters, Duo, Group chat

### Languages
English, NonEnglish, Japanese, Chinese, Spanish, Español, Korean, Russian, French, German, Portuguese, Chinese language, 中文, 女性, 同人, 调教

### Card Features
Expressions Pack, LOREBOOK, Helpers, Image Generating, chat images, image greetings, greeting images, V2 Alternate greetings

### Content Warnings
Dead Dove, Taboo, Mature Themes, Dark

---

## Glossary of Confusing Terms

### Infidelity Terms
**NTR (Netorare)** — "Cuckold" scenario where someone's romantic partner is stolen/seduced by another person. The focus is on the pain/humiliation of being cheated on. Often controversial content.

**Netori** — Reverse perspective of NTR — YOU are the one stealing/seducing someone else's partner. You're the "home wrecker."

**Reverse NTR** — Your partner is obsessively devoted to you and won't be stolen, or scenarios where you prevent/reverse an NTR situation.

**Netorase** — Consensual sharing/swinging where a partner enjoys watching their significant other with others. No betrayal element.

**anti-NTR** — Explicitly NO cheating/NTR content. Used to signal safe, faithful relationships.

**Post-NTR** — Scenarios that take place after an NTR event has occurred, dealing with aftermath/consequences.

**Cuckolding** — Similar to NTR but more fetish-focused. Partner is aware and often willingly humiliated.

**Cuckquean** — Female version of cuckolding (woman whose partner is with others).

### Racial Fetish Terms
**bbc** — "Big Black Cock" — racial fetish content.

**BWC** — "Big White Cock" — racial fetish content.

**bnwo** — "Black New World Order" — extreme racial fetish content.

**WMAF** — "White Male Asian Female" — interracial pairing tag.

**qos / queen of spades** — Symbol/fetish for white women who prefer black men.

**Snowbunny** — White woman in interracial (typically with black men) content.

**Queen of Hearts** — Similar to queen of spades but for preference for white men.

### Sexual Slang
**SPH** — Small Penis Humiliation fetish content.

**findom** — Financial domination (domination through money/financial control).

**CnC** — Consensual Non-Consent (pre-negotiated rape roleplay).

**ENF** — Embarrassed Nude Female (scenarios involving accidental/forced nudity).

**Dubcon** — Dubious consent (consent is unclear or questionable).

**grossdom** — Domination involving "gross" elements (body odor, fluids, etc.).

**gooner/Goonette/Gooning** — Porn addiction/edging culture. Someone who masturbates compulsively, often to the point of a trance-like state.

**fellatrix / THROATGOAT** — Someone extremely skilled at oral sex.

**Forniphilia** — Human furniture fetish (using people as furniture).

### Japanese Terms
**gyaru** — Japanese fashion subculture: tanned skin, bleached hair, flashy makeup, confident personality.

**kemonomimi** — "Animal ears" — characters with animal ears/tails but otherwise human.

**oyakodon** — Literally "parent-child rice bowl" — sexual scenarios involving a parent and child (usually mother-daughter) together with the same partner.

**kusogaki** — Japanese for "shitty brat" — an annoying, bratty child/teen archetype who often gets "corrected."

**Hmofa** — "Human Male on Female Anthro" — human man with female furry/anthro character.

### Internet/Community Slang
**Saviourfag/Saviorfagging** — Wanting to "fix" or "save" a damaged/troubled character through love and care.

**Girlfailure** — A woman who is bad at life/adulting, often depicted as messy, lazy, or incompetent in an endearing way.

**Dead Dove** — Warning tag from Arrested Development ("Dead Dove: Do Not Eat"). Signals dark/disturbing content — "you were warned, don't complain."

### Body Types & Identities
**cuntboy** — Male character with female genitalia.

**Dickgirl** — Female character with male genitalia (similar to futanari but sometimes distinct).

**futanari** — Character with both male and female sexual characteristics (typically female with penis).

**Shortstack** — Short but curvy/busty character (often associated with goblins, dwarves, etc.).

**BBW** — "Big Beautiful Woman" — plus-sized women.

**SSBBW** — "Super-Sized Big Beautiful Woman" — very large plus-sized women.

**Gilf** — "Grandmother I'd Like to..." — elderly female characters in sexual contexts.

**Himbo** — Male bimbo: attractive, muscular, but dim-witted and good-natured.

**Twink** — Young, slim, often hairless gay male archetype.

**bara** — Muscular, masculine gay male content (Japanese origin).

### Vore Terms
**Vore** — Fetish involving being eaten or eating another (various types exist).

**oral vore** — Eaten through the mouth.

**cock vore** — Absorbed through genitalia.

**unbirth vore** — Absorbed back into womb.

**soft vore** — Swallowed whole, alive, usually unharmed.

**Hard vore** — Chewing, gore, death involved.

**disposal vore** — Vore including digestion and its... aftermath.

### Miscellaneous
**Sizeplay** — Content involving size differences (giants, shrinking, growth) in sexual/romantic contexts.

**Omegaverse** — AU where characters have secondary "wolf-like" genders (Alpha/Beta/Omega) with heat cycles and mpreg.

**MPREG** — Male pregnancy.

**ryona** — Fetish for seeing characters (usually female) beaten, hurt, or in peril.

**oviposition** — Egg-laying fetish.

**Feederism** — Fetish involving feeding someone to make them gain weight.

**hucow** — "Human cow" — women treated/milked like cattle.

**somnophilia** — Fetish for sexual acts with sleeping people.

**freeuse** — Scenario where characters can be used sexually anytime without asking.

**Chikan** — Japanese term for groping/molestation (typically on trains).

---

## Notes on Tag Selection

When tagging a character:

1. **Always include POV tags** — At minimum one of: Malepov, Fempov, anypov/Any POV
2. **Include content rating** — NSFW, SFW, or "SFW <-> NSFW"
3. **Use duplicate coverage** — Both "OC" AND "Original Character", both "anypov" AND "Any POV"
4. **Check capitalization** — Tags are case-sensitive on Chub
5. **Mother tags require actual motherhood** — Don't use Mother/Mommy/Mom unless character has children
6. **Teenager = 18-19 only** — Never use for minors

For tags not in this list, users can create new tags on Chub.ai. Consider creating tags for:
- Specific uncommon personality traits
- Niche settings or scenarios
- Character-specific mechanics
- Unique relationship dynamics