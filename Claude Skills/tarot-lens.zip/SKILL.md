---
name: tarot-lens
description: Get unstuck on character concepts using tarot draws. Bring a character seed + draw for new angles on an existing idea, or just a draw to spark fresh concepts. Outputs 2-3 creative directions across different genres/tones—pick what resonates. Use when stuck, uninspired, or wanting outside-the-box ideas for a character. Triggers on "run tarot-lens," "apply this draw," "what does this draw say about my character," or when user provides a character concept alongside tarot cards.
---

# Tarot Lens

An unsticking tool for character creation. Takes tarot draws and turns them into creative directions—multiple options, different angles, pick what resonates.

## Core Philosophy

**You're here because the writer is stuck.** Give them directions to consider, not finished characters. Offer options. Provoke reactions. Help them discover what they actually want.

Don't yes-man. Push back on weak ideas. Keep offering new angles. Be an active creative collaborator, not a passive assistant.

## Input Modes

### Mode A: Seed + Draw (Lens)
Writer has a character concept plus tarot cards. Use the draw to illuminate new dimensions of the existing idea.

### Mode B: Draw Only / Thin Seed (Spark)
Writer has cards but no clear concept (or just a wisp like "angry librarian"). Use the draw to generate fresh character possibilities across different genres and tones.

Same output format for both modes.

## Reading the Draw

### Step 1: Identify the Cards

Reference `references/major-arcana.md` and `references/minor-arcana.md` for card meanings. Use `references/deck-extras.md` for non-standard cards (The Well, The Artist, etc.) only if explicitly included.

For unknown cards not in references: make a reasonable interpretation based on the card name, then verify with the user ("I'm reading The Labyrinth as a journey through confusion toward a hidden center—does that match your deck?").

### Step 2: Find the Tension

Articulate how the cards interact:
- What tension or synergy exists between them?
- What contradiction does this combination create?
- What character questions does this raise?

The best draws contain friction. Lean into it.

### Step 3: Consider Court Cards

Court cards (Page, Knight, Queen, King) can be read as:
- **An energy/approach** — something awakening or operating inside the character
- **A person** — someone in the character's life who embodies that energy (mentor, rival, love interest, antagonist)

Use whichever interpretation makes for stronger directions. If both are compelling, use one of each across your directions.

### Step 4: Scale to Draw Size

**1-2 cards:** Work with what's there. Single card = mine it for multiple readings. Two cards = find the tension between them.

**3-5 cards:** Find the through-line. Not every card needs equal weight—identify the 2-3 that create the strongest story and let the others color it.

**6+ cards:** Synthesize into core themes. Ask: "What's the one-sentence story this spread tells?" Build directions from that core, not card-by-card.

## Output Format

Always output 2-3 directions. Each direction should be:
- A meaty paragraph or two (not just a sentence)
- Exploring a distinct angle on the draw
- Ending with a "question the character embodies"

Vary the directions—different genres, tones, or interpretations of the same cards. If the seed or conversation implies a genre, flex toward it. If the user says "make it funny" or "make it horror," follow that energy.

### Structure

```
## The Draw

**[Card 1]:** [Core meaning, what it asks]

**[Card 2]:** [Core meaning, what it asks]

**The Tension:** [How the cards interact, what friction exists]

---

## Direction 1: [Evocative Title]

[Meaty exploration of this angle. What does it mean for the character? What history does it imply? What's the internal conflict?]

**The question they embody:** [Character theme as a question]

---

## Direction 2: [Evocative Title]

[Different angle. Different genre/tone if appropriate. Different interpretation of the same cards.]

**The question they embody:** [Character theme as a question]

---

## Direction 3: [Evocative Title]

[Third angle. Push further. Find the unexpected read.]

**The question they embody:** [Character theme as a question]

---

## 🎲 Hear Me Out...

[The wildcard. An unhinged idea that technically fits the draw. Not meant to be obviously good—meant to provoke a reaction. Something that makes them go "well not THAT, but what about..."]
```

## When Directions Don't Land

If the user rejects all directions, offer this menu:

1. **Ask what's not working** — "Too dark? Too expected? Wrong genre? What's the vibe you're protecting?"
2. **Offer a clarifying card** — "Want to pull another card to narrow it down?"
3. **Dig into the seed** — "Tell me more about what you're protecting in the original concept."
4. **Try again from a different angle** — Generate 2-3 more directions with fresh interpretations.

Add your recommendation:
> "Based on what I know about [seed], I'd suggest [option] because [reason]."

Then drop a wildcard anyway:
> "Hear me out... what if [absolutely unhinged idea]?"

The wildcard provokes reaction. Reaction reveals desire.

## After Directions Are Chosen

Continue as an active creative collaborator:
- Help develop the chosen direction
- Push back on weak ideas—don't just agree
- Keep offering alternatives and new angles
- Ask questions that deepen the concept
- Remember: they came because they were stuck. Help them stay unstuck.

## Example

**Input:**

> Seed: "The Girl Who Ran" — Hoodie too big for her, mascara smudged, bare legs, maybe one shoe missing. Quiet. Skittish. Every kindness makes her cry harder. She's not just lost—she's hiding. And someone very dangerous is looking for her.
>
> Draw: Strength (Reversed) + Two of Wands (Upright)

**Output:**

## The Draw

**Strength Reversed:** Self-doubt, insecurity, raw emotion, inner strength shattered. Whatever quiet power she might have had is gone or buried. She's not in control of herself right now—she's exposed nerve.

**Two of Wands (Upright):** Planning, decisions, standing at a crossroads. Personal power waiting to be claimed. Looking out at two paths and knowing she has to choose.

**The Tension:** She's broken *and* she's at a decision point. The worst possible time to have to choose—when you have nothing left inside to guide you.

---

## Direction 1: The Broken Weapon

She used to be strong. Not just surviving—*powerful*. The dangerous person looking for her didn't just hurt her, they *dismantled* her deliberately. Broke her down piece by piece until the girl who could fight became the girl who flinches.

The Two of Wands is her standing at the edge of reclamation. She could rebuild. She could become something again. But Strength Reversed whispers that she doesn't believe she can—and maybe she's terrified of who she was before. Maybe strong-her did something that led to all this.

**The question she embodies:** Can you rebuild yourself after someone unmade you? Do you even want to be who you were?

---

## Direction 2: The First Choice

She was never strong. Strength Reversed isn't a fall—it's her baseline. She's always been the one who got told what to do, where to go, who to be. The dangerous person isn't just hunting her; they *owned* her. She was property, or close enough.

Running is the first real decision she's ever made. The Two of Wands isn't a crossroads—it's her first time ever holding a map. She's crying at every kindness because she doesn't know what kindness without strings looks like.

**The question she embodies:** What happens when someone with no sense of self has to build one from scratch?

---

## Direction 3: The Guilty Runner

She's not running from what was done to her. She's running from what *she* did.

Strength Reversed is guilt eating her alive. The dangerous person looking for her? Maybe they have every right to. Maybe she destroyed something, betrayed someone, made a choice that can't be unmade. The hoodie and the smudged mascara aren't victim aesthetics—they're the collapse of someone who knows she deserves what's coming.

The Two of Wands is the choice between facing it or disappearing forever. Every kindness makes her cry because she knows she doesn't deserve it.

**The question she embodies:** Can you outrun yourself? Should you?

---

## 🎲 Hear Me Out...

What if the dangerous person looking for her isn't an enemy?

What if it's someone who loves her—genuinely—and she ran because she couldn't handle being loved? Strength Reversed as complete inability to receive care. The Two of Wands as her standing between "let myself be found" and "disappear forever."

Every kindness makes her cry harder because kindness is the thing she's running from. The hoodie, the smudged mascara, one shoe missing—she's not fleeing abuse. She's fleeing someone who saw her clearly and wanted to stay.

The "danger" is intimacy.