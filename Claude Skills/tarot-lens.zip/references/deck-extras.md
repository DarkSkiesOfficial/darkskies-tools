# Deck Extras (Non-Standard Cards)

These cards are **not part of the standard 78-card tarot deck**. They are deck-specific additions (e.g., Ethereal Visions deck). Use only if the user explicitly includes them in their draw.

---

## 🕳️ The Well

### Upright: Access to Depth

**Core meaning:**
- Emotional or spiritual reserves are present
- Intuition is reliable and available
- Past experience is a resource, not a weight
- Slow nourishment, sustainability, and patience

**Psychological translation:** "You have inner resources. You can draw from them safely."

**Situational reading:**
- A stable foundation exists
- Healing is possible through reflection
- The answer is already within reach, but not flashy

**Character question:** "What sustains this character beneath the surface?"

**What you're defining:**
- Core emotional truth
- Long memory or formative past
- Inner stability, patience, or quiet resilience
- A value or wound that feeds everything else

**Character logic:** This is a character who has depth they can access. They may not be loud or dramatic, but they are internally coherent.

**Examples:**
- A character whose trauma has been metabolized into wisdom
- Someone emotionally self-sufficient
- A person who can endure because they know why they endure

### Reversed: Blocked or Contaminated Depth

**Core meaning:**
- Emotional exhaustion or burnout
- Avoidance of inner truth
- Old memories poisoning present decisions
- Seeking nourishment from an empty or harmful source

**Psychological translation:** "You're either not looking inward—or what you're drawing up is distorted."

**Situational reading:**
- A person or situation used to nourish you but no longer does
- Reflection without integration (rumination instead of insight)

**Reversal logic:** A well reversed doesn't mean "no depth." It means depth without access, clarity, or safety. Think:
- Rope snapped
- Water stagnant
- Bucket lowered into the wrong place

**Character question:** "What is missing, tainted, or inaccessible at this character's core?"

**What you're defining:**
- Emotional neglect, burnout, or loss
- A past that drains rather than sustains
- A blocked intuition or suppressed memory
- An internal contradiction they can't resolve

**Character logic:** This character has depth, but it's dangerous, painful, or unreachable.

**Examples:**
- Someone running on fumes
- A character who avoids introspection at all costs
- A person whose past keeps poisoning the present

---

## 🎨 The Artist

### Upright: Conscious Creation

**Core meaning:**
- Authentic self-expression
- Active authorship of your life or work
- Turning inner truth into form
- Courage to be seen

**Psychological translation:** "I choose how this becomes real."

**Situational reading:**
- A project, decision, or identity is ready to be shaped
- You are allowed to take up space

**Character question:** "How does this character assert authorship over their life?"

**What you're defining:**
- Their mode of expression (art, leadership, rebellion, caretaking, invention)
- How they impose meaning on chaos
- Their relationship to choice and identity

**Character logic:** This is a character who acts. Even passivity is a choice they own.

**Examples:**
- A character who reframes suffering into purpose
- Someone who insists on living truthfully, even at cost
- A person who defines themselves rather than being defined

### Reversed: Suppressed or Hijacked Creation

**Core meaning:**
- Creative block or self-censorship
- Fear of judgment overriding authenticity
- Letting others write your story
- Perfectionism, procrastination, or imitation

**Psychological translation:** "I know what I'd make—but I'm afraid to claim it."

**Situational reading:**
- Creativity exists but is constrained
- Expression is filtered for safety instead of truth

**Reversal logic:** The Artist reversed does not mean lack of creativity. It means creativity without agency. Think:
- The artist painting what sells, not what's true
- The story written by committee
- Hands tied, voice muted

**Character question:** "Who is actually writing this character's story?"

**What you're defining:**
- External control (family, society, lover, institution)
- Internal censorship (fear, shame, perfectionism)
- Loss of voice or agency

**Character logic:** This character is being authored, not authoring.

**Examples:**
- Someone living a life they didn't choose
- A character afraid to claim desire or ambition
- A person who imitates instead of creates