# Major Arcana Reference

Complete character-focused interpretations for all 22 Major Arcana cards.

---

## 0 - The Fool

### Upright: The Leap

**Core meaning:**
- New beginnings, innocence, spontaneity
- Leap of faith into the unknown
- Freedom from fear (or ignorance of danger)
- The moment before everything changes

**Psychological translation:** "I don't know what's out there, and I'm going anyway."

**Character question:** What is this character willing to risk without knowing the outcome?

**What you're defining:**
- Their relationship to risk and the unknown
- Whether their courage is wisdom or naivety
- The moment they chose to begin
- What they left behind to leap

**Character logic:** This is someone at the edge of a cliff—either about to fly or fall, and they don't care which yet.

**Examples:**
- A sheltered noble who abandons their inheritance to see the world
- A scientist who publishes a theory that will destroy their career if wrong
- A teenager running away from home with $40 and a dream

### Reversed: The Hesitation

**Core meaning:**
- Recklessness without purpose
- Fear of beginning, holding back
- Naivety that leads to harm
- The leap not taken, or taken badly

**Psychological translation:** "I'm either too scared to jump or too stupid to look down."

**Character question:** What is this character refusing to begin—or beginning without thinking?

**What you're defining:**
- Paralysis vs. recklessness (two sides of the same coin)
- What fear is stopping them
- What consequences they're ignoring
- The cost of not leaping

**Character logic:** This is someone stuck at the edge—either frozen or flailing.

**Examples:**
- A would-be artist who's been "about to start" their masterpiece for ten years
- A gambler who mistakes recklessness for courage
- Someone who keeps almost leaving their toxic situation

---

## I - The Magician

### Upright: The Will Made Real

**Core meaning:**
- Manifestation, willpower, skill
- Having all the tools and knowing how to use them
- Turning intention into reality
- Mastery and resourcefulness

**Psychological translation:** "I can make this happen."

**Character question:** What does this character have the power to create—and do they know it?

**What you're defining:**
- Their competence and confidence
- What resources they command
- How they translate will into action
- The gap (or lack thereof) between desire and ability

**Character logic:** This is someone who can do the thing. The question is what they'll do with that power.

**Examples:**
- A con artist who could go straight but chooses not to
- A surgeon whose hands never shake
- An organizer who can mobilize a crowd with a speech

### Reversed: The Manipulation

**Core meaning:**
- Trickery, deception, wasted potential
- Having the tools but misusing them
- Untapped talent or talent turned toxic
- The lie that looks like magic

**Psychological translation:** "I could do something real, but this is easier."

**Character question:** How is this character misusing their gifts—or failing to use them at all?

**What you're defining:**
- Manipulation vs. squandered potential
- What they're faking
- What they could be but aren't
- The cost of their deception (to themselves and others)

**Character logic:** This is someone whose power has curdled—either into manipulation or into waste.

**Examples:**
- A brilliant student who cheats anyway because winning matters more than learning
- A charismatic leader who uses their influence for control
- A prodigy who burned out and now resents anyone who tries

---

## II - The High Priestess

### Upright: The Inner Knowing

**Core meaning:**
- Intuition, mystery, hidden knowledge
- The subconscious, dreams, the unseen
- Trusting what can't be proven
- Secrets held, not secrets hidden

**Psychological translation:** "I know things I can't explain."

**Character question:** What does this character understand that they can't—or won't—articulate?

**What you're defining:**
- Their relationship to intuition and the unseen
- What they know without knowing how
- The mystery they embody or protect
- Their comfort with ambiguity

**Character logic:** This is someone connected to deeper currents. They may not speak much, but they see.

**Examples:**
- A therapist who always knows the question to ask
- A child who sees things adults dismiss
- A keeper of traditions no one else remembers

### Reversed: The Hidden Agenda

**Core meaning:**
- Secrets, withdrawal, repressed intuition
- Hidden agendas (theirs or others')
- Disconnection from inner knowing
- The answer is there but blocked

**Psychological translation:** "I'm hiding something—maybe even from myself."

**Character question:** What is this character refusing to know—or refusing to reveal?

**What you're defining:**
- Repression vs. deception
- What they've buried
- Why they've cut themselves off from intuition
- The secret that's poisoning them

**Character logic:** This is someone who has sealed something away—and it's leaking.

**Examples:**
- Someone who dreams about something they won't acknowledge while awake
- A keeper of a terrible secret they've never told
- A person who "just knows" their relationship is wrong but won't admit it

---

## III - The Empress

### Upright: The Abundance

**Core meaning:**
- Fertility, creativity, nurturing
- Abundance in all forms
- Sensuality and embodiment
- Creation that flows naturally

**Psychological translation:** "I make things grow."

**Character question:** What does this character nurture—and what flourishes in their presence?

**What you're defining:**
- Their creative or nurturing nature
- What they bring to life
- Their relationship to abundance and pleasure
- How they care for others (or their creations)

**Character logic:** This is someone generative. Where they go, things grow.

**Examples:**
- A chef whose kitchen is always full of people
- A mentor who's launched a dozen careers
- A parent whose love is a force of nature

### Reversed: The Smothering

**Core meaning:**
- Dependence, creative block, neglect
- Smothering love or absent nurturing
- Emptiness where abundance should be
- The garden that won't grow

**Psychological translation:** "I'm either giving too much or nothing at all."

**Character question:** How has this character's nurturing impulse gone wrong—excess or absence?

**What you're defining:**
- Smothering vs. neglect (both are broken nurturing)
- What they can't create right now
- The emptiness they're hiding or drowning in
- What they're killing with kindness (or silence)

**Character logic:** This is someone whose generative nature is blocked or corrupted.

**Examples:**
- A parent who can't let their children fail
- An artist who hasn't made anything in years
- Someone who nurtures everyone else to avoid nurturing themselves

---

## IV - The Emperor

### Upright: The Authority

**Core meaning:**
- Structure, control, stability
- Authority earned through competence
- Protection and provision
- The rules that hold things together

**Psychological translation:** "I am responsible for this, and I will hold the line."

**Character question:** What does this character protect—and what power do they wield to protect it?

**What you're defining:**
- Their relationship to authority (having it, not just following it)
- What structure they've built or maintain
- How they handle responsibility
- What they'd do to protect their domain

**Character logic:** This is someone who holds power and uses it. The question is how, and for whom.

**Examples:**
- A CEO who built their company from nothing
- A single parent who keeps everything running through sheer will
- A general who's never lost a soldier they didn't have to

### Reversed: The Tyrant

**Core meaning:**
- Domination, rigidity, tyranny
- Authority without legitimacy
- Control for its own sake
- Structure that imprisons rather than protects

**Psychological translation:** "If I lose control, everything falls apart."

**Character question:** How has this character's authority become oppressive—to others or themselves?

**What you're defining:**
- Control that's tipped into domination
- What they're so afraid of that they've become rigid
- The rules that have become cages
- Who suffers under their authority

**Character logic:** This is someone whose strength has become a prison—their own or others'.

**Examples:**
- A parent who can't admit their children are adults
- A boss who micromanages because they can't trust
- A ruler who's forgotten they serve the people, not the other way around

---

## V - The Hierophant

### Upright: The Tradition

**Core meaning:**
- Tradition, institutions, spiritual wisdom
- Teaching and mentorship
- The value of established paths
- Conformity as belonging

**Psychological translation:** "There's wisdom in the way things have been done."

**Character question:** What tradition or institution does this character serve—and what do they gain from it?

**What you're defining:**
- Their relationship to orthodoxy and tradition
- What they teach or pass down
- The community they belong to through conformity
- What inherited wisdom they carry

**Character logic:** This is someone who operates within systems. They may preserve, teach, or believe—but they're not reinventing the wheel.

**Examples:**
- A priest who genuinely believes in the institution
- A master craftsman teaching the old ways
- A lawyer who believes in the system even when it fails

### Reversed: The Heretic

**Core meaning:**
- Rebellion, subversion, breaking from tradition
- Challenging conventions and orthodoxy
- Freedom through rejection
- The institution revealed as hollow

**Psychological translation:** "The old ways failed me. I'll find my own."

**Character question:** What tradition has this character rejected—and what did that cost them?

**What you're defining:**
- Their rebellion (what against, and why)
- What they lost by leaving
- What they're building instead (if anything)
- The difference between healthy questioning and destructive rejection

**Character logic:** This is someone who walked away from something established. They're either freer or lonelier for it.

**Examples:**
- A former believer who lost their faith
- An heir who rejected the family legacy
- A scientist whose theory got them excommunicated from their field

---

## VI - The Lovers

### Upright: The Union

**Core meaning:**
- Love, partnership, deep alignment
- Choices that define who you are
- Values made visible through relationship
- Union that transforms

**Psychological translation:** "This connection shows me who I am."

**Character question:** What relationship or choice has defined this character?

**What you're defining:**
- A bond that matters (romantic, platonic, or otherwise)
- A choice that revealed their values
- How they show up in partnership
- What they've discovered through connection

**Character logic:** This is someone whose identity is illuminated by union—with a person, a path, or a choice.

**Examples:**
- Someone whose partnership makes them braver than they'd be alone
- A person facing an impossible choice between two paths they love
- A character whose relationship to their work is a kind of marriage

### Reversed: The Disharmony

**Core meaning:**
- Imbalance, misalignment, difficult choices
- Relationship in conflict
- Self-love deficit
- The union that isn't working

**Psychological translation:** "We don't fit—or I don't fit with myself."

**Character question:** What relationship or internal divide is tearing this character apart?

**What you're defining:**
- A partnership in trouble (or the absence of one)
- A choice they're avoiding
- Misalignment between who they are and who they're with
- The self-betrayal underneath the relationship problem

**Character logic:** This is someone out of harmony—with another person or with themselves.

**Examples:**
- Someone staying in a relationship that's making them smaller
- A person who can't commit because they don't know what they want
- A character whose self-loathing sabotages every connection

---

## VII - The Chariot

### Upright: The Drive

**Core meaning:**
- Willpower, determination, victory through focus
- Controlling opposing forces
- Direction and momentum
- Success through discipline, not luck

**Psychological translation:** "I will get there. Nothing will stop me."

**Character question:** What is this character driving toward—and what are they harnessing to get there?

**What you're defining:**
- Their goal (clear and pursued with intensity)
- What opposing forces they're controlling
- Their relationship to willpower and discipline
- What they're willing to sacrifice for victory

**Character logic:** This is someone in motion. They've picked a direction and they're going.

**Examples:**
- An athlete training for one shot at the championship
- A refugee who will reach safety through sheer will
- A career climber who's turned their ambition into an engine

### Reversed: The Crash

**Core meaning:**
- Lack of direction, aggression without aim
- Losing control, scattered energy
- Obstacles that can't be overcome by force
- The drive that's run out of road

**Psychological translation:** "I don't know where I'm going—or I can't get there from here."

**Character question:** How has this character lost their direction—or mistaken aggression for progress?

**What you're defining:**
- What knocked them off course
- Whether they've lost direction or lost control
- The goal that's become impossible
- What happens when will isn't enough

**Character logic:** This is someone whose momentum has failed them—crashed, stalled, or spinning.

**Examples:**
- A workaholic who achieved the goal and felt nothing
- Someone whose anger keeps them moving but not toward anything
- A former champion who doesn't know who they are without the race

---

## VIII - Strength

### Upright: The Quiet Power

**Core meaning:**
- Inner strength, courage, patience
- Compassion that controls
- Gentle influence over raw force
- The lion tamed, not slain

**Psychological translation:** "I don't have to fight it. I can hold it."

**Character question:** What does this character have the strength to hold—without destroying it or being destroyed?

**What you're defining:**
- Their inner reserves
- How they handle what's wild in them or others
- Strength expressed through gentleness
- What they've tamed (inside or out)

**Character logic:** This is someone with power they don't have to prove. They can hold the lion's mouth closed because they're not afraid.

**Examples:**
- A caretaker who handles a violent patient with calm
- Someone who's made peace with their own darkness
- A leader who doesn't need to shout to command a room

### Reversed: The Collapse

**Core meaning:**
- Self-doubt, weakness, raw emotion
- Inner strength shattered or inaccessible
- The lion loose, or the hand too weak to hold
- Vulnerability without the container

**Psychological translation:** "I can't hold this. I can't hold myself."

**Character question:** What has broken this character's ability to contain themselves or their situation?

**What you're defining:**
- What cracked their strength
- Whether they're overwhelmed from outside or collapsing from within
- The rawness they can't control right now
- What they're afraid they'll do (or become) without containment

**Character logic:** This is someone whose inner strength has failed—temporarily or permanently.

**Examples:**
- Someone in the middle of a breakdown, finally feeling everything
- A person whose patience ran out after one insult too many
- A caretaker who can no longer care for themselves

---

## IX - The Hermit

### Upright: The Withdrawal

**Core meaning:**
- Solitude, introspection, inner guidance
- Wisdom found in withdrawal
- The lamp that lights only your own path
- Soul-searching that requires silence

**Psychological translation:** "I need to be alone to find what I'm looking for."

**Character question:** What truth is this character seeking in solitude?

**What you're defining:**
- Why they've withdrawn (healing, searching, hiding, or growing)
- What they're looking for inside
- Their relationship to solitude
- What wisdom they carry—or seek

**Character logic:** This is someone who has stepped back from the world. They may be a sage, a seeker, or just someone who needs silence to hear themselves think.

**Examples:**
- A teacher who's gone on sabbatical to remember why they teach
- A celebrity who vanished at the height of fame
- A healer who can help everyone but themselves

### Reversed: The Isolation

**Core meaning:**
- Loneliness, rejection, excessive withdrawal
- Lost in introspection
- Isolation as avoidance
- The lamp that's gone out

**Psychological translation:** "I've been alone so long I've forgotten how to come back."

**Character question:** How has this character's solitude become a prison?

**What you're defining:**
- Isolation vs. healthy solitude (they've crossed the line)
- What they're avoiding by staying withdrawn
- The loneliness they won't admit
- What they've lost by staying away too long

**Character logic:** This is someone whose withdrawal has calcified into isolation.

**Examples:**
- A genius who's burned every bridge and wonders why they're alone
- Someone whose "healing journey" has become a way to avoid life
- A recluse who tells themselves they prefer it this way

---

## X - Wheel of Fortune

### Upright: The Turn

**Core meaning:**
- Change, cycles, fate
- The turn you didn't control
- Luck—good or bad
- What goes up must come down (and vice versa)

**Psychological translation:** "Things are changing whether I'm ready or not."

**Character question:** What force outside this character's control is about to change everything?

**What you're defining:**
- The external change that reshapes them
- Their relationship to luck and fate
- Where they are in the cycle (rising, falling, turning)
- How they respond when they're not in control

**Character logic:** This is someone caught in a turn. The wheel moves; they adapt or don't.

**Examples:**
- A lottery winner whose life is about to get complicated
- A dynasty heir watching the family fortune collapse
- A nobody who's about to be in the right place at the right time

### Reversed: The Resistance

**Core meaning:**
- Bad luck, resistance to change
- Fighting the turn that's coming anyway
- Breaking cycles (or being broken by them)
- Feeling like a victim of fate

**Psychological translation:** "I can't stop this, but I can't accept it either."

**Character question:** What change is this character resisting—or what cycle has trapped them?

**What you're defining:**
- Their resistance to what's inevitable
- The cycle they're stuck in
- Whether they're breaking free or being broken
- Their relationship to fate when fate is cruel

**Character logic:** This is someone fighting the wheel—sometimes heroically, sometimes futilely.

**Examples:**
- Someone who keeps dating the same wrong person in different bodies
- A family trying to escape a generational curse
- A patient who refuses to accept a diagnosis

---

## XI - Justice

### Upright: The Reckoning

**Core meaning:**
- Fairness, truth, cause and effect
- Accountability that can't be escaped
- The scales balanced
- Decisions made clearly, without sentiment

**Psychological translation:** "What's true is true, whether I like it or not."

**Character question:** What truth is this character being forced to face—or what accountability is coming?

**What you're defining:**
- Their relationship to truth and fairness
- What consequence is arriving
- How they handle being judged (by others or themselves)
- The clarity that cuts through illusion

**Character logic:** This is someone at a moment of accounting. The truth will out.

**Examples:**
- A lawyer who has to prosecute someone they believe is innocent
- A whistleblower about to face the consequences of telling the truth
- Someone whose lies are about to catch up with them

### Reversed: The Injustice

**Core meaning:**
- Unfairness, dishonesty, accountability dodged
- The scales tipped
- Truth obscured or denied
- Legal complications, bias, corruption

**Psychological translation:** "It's not fair—and no one's going to fix it."

**Character question:** What injustice has shaped this character—or what accountability are they avoiding?

**What you're defining:**
- The unfairness they've suffered or committed
- How they cope with a world that isn't just
- What they're avoiding answering for
- The lie they're living with

**Character logic:** This is someone touched by injustice—as victim, perpetrator, or both.

**Examples:**
- Someone wrongfully convicted who's given up on appeals
- A person who got away with something and thinks about it every day
- A judge who knows the system is broken but keeps showing up

---

## XII - The Hanged Man

### Upright: The Suspension

**Core meaning:**
- Pause, surrender, new perspective
- Sacrifice for insight
- Waiting that isn't passive
- Seeing the world upside down

**Psychological translation:** "I can't move forward. Maybe I'm not supposed to."

**Character question:** What has this character surrendered to—and what are they seeing from this new angle?

**What you're defining:**
- What they're suspended in (waiting, sacrifice, forced pause)
- What they're learning from not-moving
- The perspective shift that only comes from hanging
- What they're giving up to gain something else

**Character logic:** This is someone paused—not stuck, but waiting. There's something to see that they couldn't see while moving.

**Examples:**
- A prisoner who's found unexpected peace in confinement
- Someone waiting for test results that will change everything
- An activist who's given up control and is trusting the process

### Reversed: The Stall

**Core meaning:**
- Stalling, resistance, unnecessary sacrifice
- Martyrdom without meaning
- Stuck not as growth but as avoidance
- The pause that's become permanent

**Psychological translation:** "I'm not waiting for insight. I'm just stuck."

**Character question:** What is this character refusing to surrender—or what are they sacrificing for nothing?

**What you're defining:**
- The difference between purposeful pause and stuck
- What they're martyring themselves for (and whether it's worth it)
- The delay that's become a lifestyle
- What they're afraid to see if they change perspective

**Character logic:** This is someone who's stopped moving and doesn't know how to start again—or is sacrificing without return.

**Examples:**
- Someone who's been "figuring things out" for a decade
- A caretaker who's destroyed themselves for people who don't appreciate it
- A person who won't make a decision because every option feels like loss

---

## XIII - Death

### Upright: The Ending

**Core meaning:**
- Transformation, endings, letting go
- Death of the old self
- The door that only opens when another closes
- Change that can't be undone

**Psychological translation:** "Something is ending, and I can't go back to who I was."

**Character question:** What is dying in this character's life—and what will grow in its place?

**What you're defining:**
- What's ending (relationship, identity, era, belief)
- How they're handling the death of the old
- What's being born in the space left behind
- Their relationship to irreversible change

**Character logic:** This is someone at a threshold. The person who walks through won't be the person who approached.

**Examples:**
- Someone leaving a marriage that defined their entire adult life
- A person whose belief system has collapsed and they're in the rubble
- A character whose mentor just died, leaving them to carry the work alone

### Reversed: The Resistance to Ending

**Core meaning:**
- Resistance to change, fear of endings
- Decay from holding on too long
- Stagnation, refusing to let go
- The death that's happening anyway, badly

**Psychological translation:** "I know it's over, but I can't let go."

**Character question:** What is this character clinging to that needs to die?

**What you're defining:**
- What they won't release
- The decay setting in because they won't let go
- The transformation they're resisting
- What it's costing them to hold on

**Character logic:** This is someone who won't let something end—and it's rotting in their grip.

**Examples:**
- Someone keeping a failing business alive through denial
- A person still texting their ex a year after the breakup
- A leader who won't step down even as they become irrelevant

---

## XIV - Temperance

### Upright: The Balance

**Core meaning:**
- Moderation, patience, synthesis
- Combining opposites into something new
- Healing through time and care
- The middle path that isn't compromise

**Psychological translation:** "I can hold both of these things. I can make them work together."

**Character question:** What opposites is this character learning to balance?

**What you're defining:**
- What they're synthesizing (opposing values, identities, demands)
- Their patience and how it serves them
- The healing they're in the middle of
- How they find harmony without erasing difference

**Character logic:** This is someone working toward integration. They're not choosing between two things; they're making a third.

**Examples:**
- Someone balancing career ambition with family needs
- A recovering addict learning moderation in all things
- A diplomat who actually believes in finding common ground

### Reversed: The Imbalance

**Core meaning:**
- Excess, imbalance, impatience
- The synthesis that failed
- Self-healing needed
- Discord from trying to force harmony

**Psychological translation:** "I can't make these pieces fit. Something has to give."

**Character question:** What is out of balance in this character's life—and what are they doing about it?

**What you're defining:**
- What's in excess or deficiency
- The harmony they can't achieve
- The impatience that's breaking the process
- What happens when you can't integrate the opposites

**Character logic:** This is someone whose balance has tipped—too much work, too little play, too many demands, not enough self.

**Examples:**
- A helper who gives everything and receives nothing
- Someone whose "moderation" is actually repression
- A person trying to please everyone and losing themselves

---

## XV - The Devil

### Upright: The Chains

**Core meaning:**
- Bondage, shadow self, addiction
- Attachment to what harms
- The chains we choose to wear
- Materialism, obsession, the trap that feels good

**Psychological translation:** "I know this is bad for me. I want it anyway."

**Character question:** What is this character chained to—and do they know they could leave?

**What you're defining:**
- Their addiction, obsession, or unhealthy attachment
- The shadow side they're expressing or suppressing
- How they stay stuck (and what pleasure they get from it)
- The chains and whether they see them

**Character logic:** This is someone bound to something that's harming them—and part of them likes it there.

**Examples:**
- Someone in a toxic relationship they can't quit
- A workaholic who's sacrificed everything for success and calls it ambition
- A person who knows their coping mechanism is killing them slowly

### Reversed: The Breaking Free

**Core meaning:**
- Release, reclaiming power, breaking free
- Detachment from what controlled you
- Facing the shadow instead of serving it
- The chains removed (or at least loosened)

**Psychological translation:** "I see what this is. I can choose to leave."

**Character question:** What is this character finally breaking free from—and what did it cost them to stay so long?

**What you're defining:**
- What they're releasing (addiction, attachment, obsession)
- The moment of clarity that let them see the chains
- What it's costing them to leave
- Who they are without the thing that bound them

**Character logic:** This is someone in the process of liberation—terrifying and exhilarating.

**Examples:**
- Someone walking away from a cult they believed in for decades
- A person finally getting sober and not knowing who they are without the substance
- A character who just realized their "great love" was actually control

---

## XVI - The Tower

### Upright: The Collapse

**Core meaning:**
- Sudden change, destruction, revelation
- The structure that couldn't stand
- Chaos that clears the ground
- Truth striking like lightning

**Psychological translation:** "Everything I built is falling down—and maybe it needed to."

**Character question:** What has just collapsed in this character's life—and what truth was revealed in the rubble?

**What you're defining:**
- What fell (relationship, identity, belief, security)
- Whether the destruction was external or self-inflicted
- What truth was exposed by the collapse
- How they're responding to sudden chaos

**Character logic:** This is someone in the middle of devastation. The question is what they'll build after—or if they can.

**Examples:**
- Someone whose secret just became public
- A person whose entire worldview was shattered by one piece of information
- A character who just lost everything in a fire (literal or metaphorical)

### Reversed: The Delayed Collapse

**Core meaning:**
- Avoiding disaster, fear of change
- The tower that should have fallen but hasn't (yet)
- Internal upheaval without external change
- Delaying the inevitable

**Psychological translation:** "I know it's going to fall. I'm just waiting."

**Character question:** What collapse is this character avoiding—or what internal destruction is happening while the outside looks fine?

**What you're defining:**
- What they're propping up that needs to fall
- The internal chaos behind the stable exterior
- The fear that keeps them rebuilding a condemned structure
- What it's costing them to delay the inevitable

**Character logic:** This is someone holding together something that shouldn't hold—and they know it.

**Examples:**
- A marriage that both partners know is over but neither will end
- A company running on fumes and denial
- Someone having a quiet breakdown while maintaining a perfect public image

---

## XVII - The Star

### Upright: The Hope

**Core meaning:**
- Hope, faith, renewal
- The calm after the storm
- Spiritual connection and healing
- Quiet confidence that things will be okay

**Psychological translation:** "I've been through the worst. I believe in what comes next."

**Character question:** What is this character hoping for—and what gives them the faith to keep reaching?

**What you're defining:**
- What they're reaching toward
- How they survived whatever came before (The Tower often precedes The Star)
- Their relationship to hope and faith
- The quiet resilience that doesn't need to prove itself

**Character logic:** This is someone who has been broken and is healing. The hope is real because they've earned it.

**Examples:**
- A survivor beginning to believe in a future again
- An artist who's found their voice after years of silence
- Someone who's lost everything and is rebuilding with strange peace

### Reversed: The Despair

**Core meaning:**
- Hopelessness, disconnection, loss of faith
- The light that can't be seen
- Discouragement and exhaustion
- Reaching and finding nothing

**Psychological translation:** "I don't believe it's going to get better."

**Character question:** What hope has this character lost—and what would it take to find it again?

**What you're defining:**
- What broke their faith
- The disconnection from meaning or future
- Whether the despair is temporary or settling in
- What they need (even if they can't ask for it)

**Character logic:** This is someone who can't see the light right now. It might still be there—but they can't reach it.

**Examples:**
- Someone who's tried everything and nothing worked
- A person going through the motions without believing in any of it
- A character who used to inspire others and now can't inspire themselves

---

## XVIII - The Moon

### Upright: The Illusion

**Core meaning:**
- Illusion, fear, the subconscious
- Things not as they appear
- Intuition vs. anxiety (hard to tell which is which)
- The path forward is unclear

**Psychological translation:** "I don't know what's real. I don't trust what I'm seeing."

**Character question:** What is this character not seeing clearly—and what fears are distorting their perception?

**What you're defining:**
- What they're misperceiving (in themselves, others, or situation)
- The fears that operate beneath the surface
- Their relationship to uncertainty and the unknown
- What the subconscious is trying to tell them

**Character logic:** This is someone in fog. The danger might be real or imagined—they can't tell, and that's the problem.

**Examples:**
- Someone who suspects their partner is cheating (and might be right or might be paranoid)
- A character who can't distinguish anxiety from intuition
- A person lost in a situation where nothing is what it seems

### Reversed: The Clarity

**Core meaning:**
- Release of fear, clarity emerging
- Truth revealed after confusion
- Overcoming anxiety and illusion
- The fog lifting

**Psychological translation:** "I can finally see what was there all along."

**Character question:** What illusion is this character finally seeing through—and what do they find underneath?

**What you're defining:**
- What's becoming clear
- The fear that's losing its grip
- What was real all along (for better or worse)
- How they're handling the clarity

**Character logic:** This is someone coming out of fog—relieved, or horrified by what they can now see.

**Examples:**
- Someone who realizes their "dream job" was making them miserable
- A person who finally understands why they keep making the same mistake
- A character whose paranoia turns out to have been justified all along

---

## XIX - The Sun

### Upright: The Joy

**Core meaning:**
- Joy, success, vitality
- Warmth and confidence
- The child who plays without fear
- Simple happiness, uncomplicated good

**Psychological translation:** "This is good. I'm allowed to enjoy it."

**Character question:** What brings this character genuine joy—and can they let themselves feel it?

**What you're defining:**
- Their relationship to happiness and success
- The warmth they bring (or receive)
- What lets them feel free
- The simplicity beneath the complexity

**Character logic:** This is someone in a good moment—or someone whose nature is fundamentally warm.

**Examples:**
- A child who hasn't yet learned to be afraid
- Someone who's genuinely happy in their life (rare in fiction, valuable when done well)
- A character whose optimism is a superpower, not a flaw

### Reversed: The False Brightness

**Core meaning:**
- Sadness behind the smile, false positivity
- Ego masking emptiness
- Burnout behind the brightness
- Joy that's performed, not felt

**Psychological translation:** "I look happy. I don't feel happy."

**Character question:** What is this character hiding behind their brightness—and who are they performing for?

**What you're defining:**
- The gap between appearance and reality
- What they're hiding (from others or themselves)
- The cost of performing happiness
- What would happen if they stopped smiling

**Character logic:** This is someone whose light is a mask. The sun is painted on.

**Examples:**
- A social media influencer who's miserable in their "perfect" life
- A comedian who can't stop being funny long enough to feel anything
- A parent who won't let their kids see them struggle

---

## XX - Judgement

### Upright: The Reckoning

**Core meaning:**
- Reflection, reckoning, awakening
- The call to become who you're meant to be
- Rebirth through honest self-assessment
- Answering for what you've done—and choosing what comes next

**Psychological translation:** "I hear the call. I'm ready to answer."

**Character question:** What is this character being called to become—and what must they reckon with first?

**What you're defining:**
- The call they're hearing (purpose, transformation, accounting)
- What they need to face about their past
- The rebirth waiting on the other side
- Whether they're ready to rise

**Character logic:** This is someone at a moment of becoming. They're being asked to look at everything—and then to rise.

**Examples:**
- Someone offered a chance to make up for past wrongs
- A person who finally understands what they're supposed to do with their life
- A character returning to face something they ran from years ago

### Reversed: The Refusal

**Core meaning:**
- Self-doubt, refusal of the call
- Avoiding reckoning with the past
- Fear of judgment (self or others)
- The awakening that won't come

**Psychological translation:** "I know what I should do. I can't make myself do it."

**Character question:** What call is this character refusing to answer—and what are they afraid they'll find if they look honestly at themselves?

**What you're defining:**
- What they're avoiding (the call, the reckoning, both)
- The self-judgment that's paralyzing them
- What they're afraid to become
- The cost of refusing the rise

**Character logic:** This is someone who hears the call and covers their ears.

**Examples:**
- Someone who knows they should apologize and can't make themselves
- A person who keeps almost changing their life
- A character who's afraid that becoming better means admitting how bad things were

---

## XXI - The World

### Upright: The Completion

**Core meaning:**
- Completion, integration, wholeness
- The journey ended, the lesson learned
- Everything coming together
- Accomplishment that's truly earned

**Psychological translation:** "I made it. I understand now."

**Character question:** What has this character completed—and what do they understand now that they couldn't before?

**What you're defining:**
- What they've finished (journey, project, era, growth)
- The integration of everything they've learned
- What wholeness looks like for them
- What comes after completion

**Character logic:** This is someone at the end of a cycle. They've done the thing. The question is: what now?

**Examples:**
- Someone who's finally achieved the goal they've chased for years
- A traveler returning home, changed
- A character who's made peace with something that haunted them

### Reversed: The Incompletion

**Core meaning:**
- Incompletion, shortcuts, lack of closure
- The journey interrupted
- Fulfillment just out of reach
- Almost there, but not quite

**Psychological translation:** "I'm so close. Why can't I finish?"

**Character question:** What is this character unable to complete—and what's keeping them from wholeness?

**What you're defining:**
- What they can't finish
- What shortcuts they're tempted by (or took)
- The closure that eludes them
- What "almost" is costing them

**Character logic:** This is someone who can see the finish line but can't cross it.

**Examples:**
- A writer who can't end their book
- Someone who almost reconciled with a parent before they died
- A character who achieved the goal but feels nothing