# Minor Arcana Reference

Complete character-focused interpretations for all 56 Minor Arcana cards.

## Suit Associations

| Suit | Element | Domain | Energy |
|------|---------|--------|--------|
| **Wands** | Fire 🔥 | Passion, creativity, ambition, will, action | Outward, active, initiating |
| **Cups** | Water 💧 | Emotion, relationships, intuition, heart, dreams | Inward, receptive, feeling |
| **Swords** | Air 💨 | Intellect, conflict, truth, communication, pain | Mental, cutting, analytical |
| **Pentacles** | Earth 🌍 | Material, stability, craft, body, wealth | Grounded, practical, building |

---

# Wands (Fire — Passion/Action/Will)

## Ace of Wands

### Upright: The Spark

**Core meaning:**
- New inspiration, creative ignition
- Potential energy waiting to become kinetic
- The beginning of passion, a project, a calling
- "Yes" without knowing where it leads

**Psychological translation:** "Something is starting in me. I want to make it real."

**Character question:** What new fire is igniting in this character—and are they ready for where it leads?

**What you're defining:**
- A new passion, project, or direction
- The raw potential they're holding
- Their relationship to beginnings
- What they want to create

**Character logic:** This is someone holding a match. They haven't built the fire yet, but the spark is real.

**Examples:**
- Someone who just had the idea that will change their life
- A person feeling passion for the first time in years
- A character at the very beginning of a calling

### Reversed: The False Start

**Core meaning:**
- Delays, lack of direction, creative blocks
- The spark that won't catch
- Passion without outlet
- Premature action or inability to begin

**Psychological translation:** "I want to start something, but it won't ignite."

**Character question:** What is blocking this character's creative fire—or what are they starting before they're ready?

**What you're defining:**
- The obstacle to beginning
- Whether the problem is internal (fear) or external (circumstance)
- Wasted potential vs. poor timing
- The frustration of energy with no outlet

**Character logic:** This is someone with fuel but no spark—or a spark with no fuel.

**Examples:**
- An artist who can't start the work they know they should make
- Someone who keeps announcing projects they never begin
- A person whose passion is real but circumstances prevent action

---

## Two of Wands

### Upright: The Planning

**Core meaning:**
- Planning, future vision, decisions
- Holding the world in your hands
- The crossroads where you choose direction
- Personal power waiting to be deployed

**Psychological translation:** "I can see the paths. I have to choose one."

**Character question:** What future is this character planning—and what are they weighing in the decision?

**What you're defining:**
- A choice between directions
- Their relationship to planning and foresight
- The power they hold (and whether they see it)
- What they're looking at on the horizon

**Character logic:** This is someone at a lookout point. They can see far, but they haven't moved yet.

**Examples:**
- Someone deciding between two job offers that lead to very different lives
- A ruler planning an expansion they're not sure about
- A person who's mapped out their escape but hasn't taken the first step

### Reversed: The Paralysis

**Core meaning:**
- Fear of the unknown, lack of planning
- Paralysis at the crossroads
- Choosing safety over growth
- The future that feels impossible to see

**Psychological translation:** "I don't know which way to go—so I go nowhere."

**Character question:** What is keeping this character from choosing a direction?

**What you're defining:**
- The fear that freezes them
- Whether they lack vision or lack courage
- The comfort zone they can't leave
- What both paths would cost

**Character logic:** This is someone stuck at the crossroads, watching others walk past.

**Examples:**
- Someone who's been "thinking about" a major change for years
- A person with options who's terrified of choosing wrong
- A character who won't plan because planning means committing

---

## Three of Wands

### Upright: The Expansion

**Core meaning:**
- Expansion, foresight, progress
- Ships coming in, investments paying off
- Looking outward with confidence
- The first results of bold action

**Psychological translation:** "What I started is working. There's more ahead."

**Character question:** What is this character watching return to them—and what did they send out?

**What you're defining:**
- Early success, momentum
- Their relationship to expansion and growth
- What they're waiting for (with confidence, not anxiety)
- The payoff for earlier risk

**Character logic:** This is someone whose bet is paying off. They're watching their ships come in.

**Examples:**
- An entrepreneur seeing their first real success
- Someone whose reputation is starting to precede them
- A character whose past investment is about to mature

### Reversed: The Delay

**Core meaning:**
- Delays, obstacles to expansion
- Frustration with progress
- Plans not coming together
- The ships that haven't arrived

**Psychological translation:** "I did everything right. Why isn't it working?"

**Character question:** What progress is this character being denied—and how are they handling the wait?

**What you're defining:**
- Obstacles to growth
- Frustration vs. patience
- Whether the delay is temporary or a sign
- What they're doing while they wait

**Character logic:** This is someone watching the horizon and seeing nothing.

**Examples:**
- Someone whose career has stalled despite their best efforts
- A person waiting for news that never comes
- A character whose expansion has hit unexpected resistance

---

## Four of Wands

### Upright: The Celebration

**Core meaning:**
- Celebration, harmony, homecoming
- A milestone reached, a foundation completed
- Community and belonging
- Joy that's earned

**Psychological translation:** "We made it. This is worth celebrating."

**Character question:** What has this character built that's worth celebrating—and who celebrates with them?

**What you're defining:**
- A real achievement or milestone
- Their relationship to community and belonging
- What "home" means to them
- Whether they can actually enjoy success

**Character logic:** This is someone who's earned a party. They have something to celebrate and people to celebrate with.

**Examples:**
- A family at a wedding or reunion
- Someone who just finished building their house
- A team celebrating a project completion

### Reversed: The Hollowness

**Core meaning:**
- Lack of harmony, instability
- Celebration without meaning
- Home that doesn't feel like home
- The foundation that's cracking

**Psychological translation:** "This should feel like a celebration. It doesn't."

**Character question:** What milestone is this character unable to enjoy—or what foundation is unstable?

**What you're defining:**
- The gap between achievement and satisfaction
- Instability in what should be secure
- Alienation from community or home
- What's wrong underneath the party

**Character logic:** This is someone at a celebration who feels alone—or whose foundation isn't as solid as it looks.

**Examples:**
- Someone hosting a party while their marriage falls apart
- A character who achieved the dream and feels nothing
- A person who doesn't feel at home in their own home

---

## Five of Wands

### Upright: The Conflict

**Core meaning:**
- Competition, conflict, clashing egos
- Creative tension or destructive fighting
- Everyone wants to win
- The struggle that might be healthy or might be chaos

**Psychological translation:** "We're all fighting for the same thing—or just fighting."

**Character question:** What competition is this character in—and is it making them better or worse?

**What you're defining:**
- The nature of the conflict (productive vs. destructive)
- Their relationship to competition
- Who they're fighting and why
- What they're trying to win

**Character logic:** This is someone in the fray. They might be sharpening themselves—or just getting bruised.

**Examples:**
- Colleagues competing for the same promotion
- Siblings with unresolved rivalry
- A character who thrives on conflict (for better or worse)

### Reversed: The Avoidance

**Core meaning:**
- Avoiding conflict, suppressed competition
- Tension under the surface
- False harmony or conflict resolved
- Giving up the fight

**Psychological translation:** "I'm done fighting—or I'm pretending there's no fight."

**Character question:** What conflict is this character avoiding—or what competition have they walked away from?

**What you're defining:**
- Whether avoidance is wisdom or cowardice
- The tension that's being suppressed
- What they gave up by not fighting
- The cost of false peace

**Character logic:** This is someone who's stepped out of the fray—voluntarily or in defeat.

**Examples:**
- Someone who won't engage even when they should
- A person who surrendered a fight they could have won
- A character maintaining peace by pretending conflict doesn't exist

---

## Six of Wands

### Upright: The Victory

**Core meaning:**
- Victory, public recognition, success
- Triumph acknowledged by others
- The parade after the battle
- Pride that's earned

**Psychological translation:** "I won. People see it. This feels good."

**Character question:** What victory is this character being recognized for—and how does recognition feel?

**What you're defining:**
- A public success
- Their relationship to recognition and pride
- Who's cheering for them
- What the victory cost

**Character logic:** This is someone on the horse, banner raised. They won and people know it.

**Examples:**
- An athlete after a championship
- Someone whose work is finally being recognized
- A character whose reputation has reached a peak

### Reversed: The Hollow Victory

**Core meaning:**
- Lack of recognition, ego problems
- Victory that feels empty
- Success that came at too high a cost
- Pride becoming arrogance

**Psychological translation:** "I won—so why do I feel like this?"

**Character question:** What is this character's success costing them—or why isn't their victory being recognized?

**What you're defining:**
- The gap between success and satisfaction
- Recognition denied or ego inflated
- What they sacrificed to win
- Private failure behind public success

**Character logic:** This is someone who won but doesn't feel like a winner.

**Examples:**
- Someone whose success alienated everyone they care about
- A person whose achievement is being attributed to someone else
- A character whose victory came from compromising their values

---

## Seven of Wands

### Upright: The Defense

**Core meaning:**
- Defensiveness, standing ground, perseverance
- Holding position against pressure
- Fighting from higher ground
- Determination when challenged

**Psychological translation:** "I'm not giving this up without a fight."

**Character question:** What is this character defending—and from whom?

**What you're defining:**
- What they're protecting (position, belief, territory)
- The pressure they're under
- Their determination and resilience
- Whether the defense is justified or paranoid

**Character logic:** This is someone who has something and others want it. They're holding the line.

**Examples:**
- Someone defending their reputation against attacks
- A person fighting to keep a position they earned
- A character whose success has made them a target

### Reversed: The Overwhelm

**Core meaning:**
- Being overwhelmed, giving up ground
- Exhaustion from constant defense
- Wondering if it's worth fighting for
- Surrendering position

**Psychological translation:** "I can't keep fighting this forever."

**Character question:** What defense is this character losing—or what are they finally willing to let go?

**What you're defining:**
- The exhaustion of constant battle
- What they might surrender
- Whether giving up is wisdom or defeat
- The cost of endless defense

**Character logic:** This is someone whose defenses are failing—through exhaustion, doubt, or overwhelming opposition.

**Examples:**
- Someone who's been fighting the same battle for too long
- A person realizing what they're defending isn't worth it
- A character whose position has become indefensible

---

## Eight of Wands

### Upright: The Speed

**Core meaning:**
- Swift action, rapid change, movement
- Everything happening at once
- Messages arriving, things in motion
- Momentum that can't be stopped

**Psychological translation:** "It's all happening now. Hold on."

**Character question:** What is suddenly accelerating in this character's life?

**What you're defining:**
- Rapid change or movement
- Their ability to keep up
- What's arriving all at once
- The exhilaration or terror of speed

**Character logic:** This is someone in the middle of acceleration. Everything is moving fast.

**Examples:**
- Someone whose career just took off overnight
- A person receiving news that changes everything
- A character in a situation that's developing faster than they can process

### Reversed: The Stall

**Core meaning:**
- Delays, frustration, slowing down
- Waiting for something that should have arrived
- Resistance to rapid change
- Momentum lost

**Psychological translation:** "It should be happening by now. Where is it?"

**Character question:** What is this character waiting for—and why hasn't it arrived?

**What you're defining:**
- Frustrating delays
- Loss of momentum
- Whether the slowdown is external or self-imposed
- What's stuck

**Character logic:** This is someone watching things slow down when they expected speed.

**Examples:**
- Someone whose messages aren't being returned
- A person whose momentum has suddenly stalled
- A character stuck in frustrating waiting

---

## Nine of Wands

### Upright: The Resilience

**Core meaning:**
- Resilience, persistence, last stand
- Wounded but still fighting
- One more battle, almost there
- Boundaries hardened by experience

**Psychological translation:** "I've been hurt. I'm still standing. One more push."

**Character question:** What has wounded this character—and what keeps them fighting anyway?

**What you're defining:**
- The wounds they carry (visible or not)
- Their stubborn resilience
- What they're protecting after everything
- How close they are to the finish (or collapse)

**Character logic:** This is someone battered but unbowed. They've taken hits and they're still here.

**Examples:**
- Someone who's survived multiple failures and won't quit
- A person whose defenses are up because they've been hurt before
- A character on the edge of victory or collapse

### Reversed: The Exhaustion

**Core meaning:**
- Exhaustion, giving up, paranoia
- Too defensive, walls too high
- The last stand that's become a prison
- Collapse from prolonged siege

**Psychological translation:** "I can't do this anymore. I've got nothing left."

**Character question:** What is this character too exhausted to keep fighting—or too guarded to let in?

**What you're defining:**
- Exhaustion vs. paranoia
- Whether they need to surrender or just rest
- The cost of constant vigilance
- What breaks when they stop

**Character logic:** This is someone whose resilience has run out—or whose defenses have become a cage.

**Examples:**
- Someone whose boundaries have become walls
- A person who can't trust anyone because they've been hurt too much
- A character who finally collapsed after holding on too long

---

## Ten of Wands

### Upright: The Burden

**Core meaning:**
- Burden, responsibility, overcommitment
- Carrying too much, near breaking
- Success that's become a weight
- The final push before completion

**Psychological translation:** "I've taken on too much. I have to keep going."

**Character question:** What is this character carrying—and why won't they put it down?

**What you're defining:**
- What they're burdened by
- How they got here (success, obligation, inability to say no)
- Whether they're near the goal or just near collapse
- What they'd have to give up to lighten the load

**Character logic:** This is someone carrying more than they should. They might make it—or they might break.

**Examples:**
- Someone who's become indispensable and can't rest
- A person carrying everyone else's problems
- A character who achieved everything and now has to maintain it all

### Reversed: The Release

**Core meaning:**
- Putting down burdens, delegating
- Collapse from overload
- Refusing to carry anymore
- Learning to ask for help

**Psychological translation:** "I can't carry this alone. Something has to give."

**Character question:** What burden is this character finally putting down—or what's crushing them?

**What you're defining:**
- Whether this is healthy release or breakdown
- What they're learning to let go
- The collapse they've been avoiding
- What happens when they stop carrying

**Character logic:** This is someone whose load has become impossible—and something is changing.

**Examples:**
- Someone who finally asked for help
- A person whose responsibilities crushed them
- A character learning they don't have to do everything alone

---

## Page of Wands

### Upright: The Explorer

**Core meaning:**
- Enthusiasm, exploration, new adventures
- Free spirit, fearless creativity
- Beginning a journey with excitement
- Potential not yet tested

**Psychological translation:** "What's over there? Let's find out!"

**Character question:** What is this character excited to explore—and what innocence are they carrying into it?

**What you're defining:**
- Youthful enthusiasm (regardless of actual age)
- A new creative or adventurous beginning
- Fearlessness born from inexperience
- The energy they bring to discovery

**Character logic:** This is someone at the beginning of an adventure, still excited about everything.

**Examples:**
- Someone starting their first big project with pure enthusiasm
- A person whose curiosity hasn't been beaten out of them
- A character embarking on a journey they don't realize is dangerous

### Reversed: The Hesitation

**Core meaning:**
- Lack of direction, frustration
- Creative blocks, fear of starting
- Enthusiasm dampened
- The adventure that won't begin

**Psychological translation:** "I want to go somewhere, but I can't seem to start."

**Character question:** What is blocking this character's enthusiasm—or misdirecting their energy?

**What you're defining:**
- Lost or misdirected enthusiasm
- What's dampening their spark
- Fear disguised as practicality
- The adventure they're avoiding

**Character logic:** This is someone whose fire is struggling to catch.

**Examples:**
- A young person pressured to be practical instead of passionate
- Someone whose excitement keeps turning into anxiety
- A character who wants adventure but can't take the first step

---

## Knight of Wands

### Upright: The Charger

**Core meaning:**
- Energy, passion, adventure
- Action-first, think later
- Charging toward what they want
- Courage that might be recklessness

**Psychological translation:** "I want that. I'm going to get it. Move."

**Character question:** What is this character charging toward—and what are they ignoring in their rush?

**What you're defining:**
- Their passion and drive
- What they pursue without hesitation
- The blind spots of action-first thinking
- Whether their courage is inspiring or reckless

**Character logic:** This is someone in motion. They see what they want and they go—consequences later.

**Examples:**
- A person who starts projects with intense passion (finishing is another matter)
- Someone whose confidence is magnetic and occasionally destructive
- A character who acts on attraction immediately

### Reversed: The Burnout

**Core meaning:**
- Haste, frustration, scattered energy
- Passion without direction
- Burned bridges, impulsive damage
- The charge that went nowhere

**Psychological translation:** "I'm moving fast but getting nowhere."

**Character question:** What has this character's impulsiveness cost them—or where has their energy scattered?

**What you're defining:**
- Passion misdirected or exhausted
- Impulsive damage to relationships or opportunities
- Energy without focus
- The crash after the charge

**Character logic:** This is someone whose fire is burning out of control—or sputtering out.

**Examples:**
- Someone who's burned every bridge with their intensity
- A person who starts everything and finishes nothing
- A character whose impulsiveness has finally caught up with them

---

## Queen of Wands

### Upright: The Magnetism

**Core meaning:**
- Warmth, vibrancy, determination
- Magnetic presence, social confidence
- Creative power wielded with grace
- Fire that warms rather than burns

**Psychological translation:** "I know who I am. Come closer if you can handle the heat."

**Character question:** What does this character's confidence attract—and how do they handle their own magnetism?

**What you're defining:**
- Social and creative confidence
- Warmth that draws people in
- How they wield influence
- The fire they carry with grace

**Character logic:** This is someone whose presence changes a room. They're powerful and they know it—but they're not cruel about it.

**Examples:**
- A host whose parties are legendary
- Someone whose confidence makes others braver
- A character who leads through charisma rather than authority

### Reversed: The Tyranny

**Core meaning:**
- Selfishness, jealousy, domineering
- Warmth withdrawn or turned to heat
- Insecurity behind confidence
- The magnetism that repels

**Psychological translation:** "If I can't be the center, I'll burn it down."

**Character question:** What insecurity is corrupting this character's power—or what are they jealous of?

**What you're defining:**
- Confidence curdled into control
- Jealousy or insecurity beneath the surface
- Warmth that's been withdrawn
- What happens when they're not the center

**Character logic:** This is someone whose fire has become dangerous—to others or themselves.

**Examples:**
- A leader whose charisma has become manipulation
- Someone whose confidence hides deep insecurity
- A character who can't stand anyone else getting attention

---

## King of Wands

### Upright: The Visionary

**Core meaning:**
- Leadership, vision, entrepreneurship
- Big picture thinking, bold decisions
- Fire directed toward creation
- Authority earned through action

**Psychological translation:** "I see what we're building. Follow me."

**Character question:** What is this character's vision—and how do they inspire others to pursue it?

**What you're defining:**
- Their leadership style
- The vision they're pursuing
- How they inspire and direct others
- Their relationship to power and action

**Character logic:** This is someone who leads from the front. They have a vision and the fire to make it real.

**Examples:**
- A founder building something that didn't exist before
- Someone whose boldness inspires loyalty
- A character who sees further than everyone else

### Reversed: The Tyrant

**Core meaning:**
- Arrogance, ruthlessness, impulsiveness
- Vision corrupted by ego
- Leadership without listening
- Power that burns rather than builds

**Psychological translation:** "My way or nothing. I don't care what it costs."

**Character question:** How has this character's ambition corrupted their leadership?

**What you're defining:**
- Arrogance masquerading as confidence
- What they've sacrificed for their vision
- The destruction in their wake
- Who they've stopped listening to

**Character logic:** This is someone whose fire has become destructive—even if the vision is still there.

**Examples:**
- A visionary who's become cruel in pursuit of the goal
- Someone whose boldness has become recklessness with others' lives
- A character whose ego has outgrown their wisdom

---

# Cups (Water — Emotion/Relationships/Dreams)

## Ace of Cups

### Upright: The Opening

**Core meaning:**
- New love, emotional beginning
- The heart opening
- Intuition, compassion, connection
- Emotional abundance offered

**Psychological translation:** "Something is opening in me. I can feel again."

**Character question:** What emotional beginning is this character experiencing—and are they ready to receive it?

**What you're defining:**
- A new emotional capacity
- Opening to love, connection, or feeling
- Their readiness to receive
- What's flowing into their life

**Character logic:** This is someone whose heart is opening—to love, to feeling, to connection.

**Examples:**
- Someone falling in love unexpectedly
- A person whose emotional numbness is finally lifting
- A character discovering they're capable of feelings they'd denied

### Reversed: The Blockage

**Core meaning:**
- Emotional blockage, repressed feelings
- Love offered but not received
- The heart closed
- Intuition ignored

**Psychological translation:** "Something's trying to reach me. I won't let it."

**Character question:** What is this character refusing to feel—or unable to receive?

**What you're defining:**
- Emotional walls
- Why they can't receive love or connection
- What they're repressing
- The cost of staying closed

**Character logic:** This is someone whose heart is closed—whether for protection or from damage.

**Examples:**
- Someone who can't accept love even when it's offered
- A person whose emotions have been shut down so long they don't know how to open
- A character running from feeling something they can't control

---

## Two of Cups

### Upright: The Connection

**Core meaning:**
- Partnership, mutual attraction, bond
- Two becoming something together
- Harmony in relationship
- Equal exchange of heart

**Psychological translation:** "We see each other. We fit."

**Character question:** What partnership defines this character—and what do they become together that they couldn't alone?

**What you're defining:**
- A significant bond (romantic or otherwise)
- What they give and receive
- How partnership changes them
- The harmony between them

**Character logic:** This is someone in real partnership—equal, mutual, transformative.

**Examples:**
- Two people who make each other better
- A partnership where both parties are fully seen
- A character whose bond with another defines a chapter of their life

### Reversed: The Imbalance

**Core meaning:**
- Imbalance in relationship, disconnection
- Partnership that isn't mutual
- Self-love deficit
- The break before or after connection

**Psychological translation:** "We're not meeting as equals. Something's off."

**Character question:** What imbalance is threatening this character's connection—or what partnership has failed?

**What you're defining:**
- Where equality has been lost
- What one gives that the other doesn't
- The disconnection between two people
- Whether repair is possible

**Character logic:** This is someone in a partnership that isn't working—or mourning one that ended.

**Examples:**
- Someone giving everything to someone who gives nothing
- A relationship where one person has outgrown the other
- A character whose inability to love themselves poisons their partnerships

---

## Three of Cups

### Upright: The Celebration

**Core meaning:**
- Friendship, celebration, community
- Joy shared with others
- Support network, found family
- Happiness multiplied by sharing

**Psychological translation:** "These are my people. This is joy."

**Character question:** Who does this character celebrate with—and what community holds them?

**What you're defining:**
- Their friendships and found family
- How they experience communal joy
- What they celebrate together
- The support they give and receive

**Character logic:** This is someone surrounded by their people, in a moment of shared joy.

**Examples:**
- A friend group that's become family
- Someone whose community showed up when they needed it
- A character experiencing belonging

### Reversed: The Exclusion

**Core meaning:**
- Isolation, exclusion, overindulgence
- Friendship gone sour
- Celebration without substance
- Loneliness in the crowd

**Psychological translation:** "Everyone's celebrating. I'm on the outside."

**Character question:** What community has this character lost—or what celebration feels hollow?

**What you're defining:**
- Exclusion or falling out
- Friendships that have gone wrong
- The emptiness of superficial connection
- What they've lost or never had

**Character logic:** This is someone outside the circle—or inside it and still alone.

**Examples:**
- Someone whose friend group moved on without them
- A person at parties who still feels fundamentally alone
- A character whose overindulgence has replaced real connection

---

## Four of Cups

### Upright: The Apathy

**Core meaning:**
- Apathy, contemplation, disconnection
- Boredom with what's available
- Missing the offer because you're looking elsewhere
- Emotional withdrawal

**Psychological translation:** "I don't want what's in front of me. I don't know what I want."

**Character question:** What is this character refusing to see—or why have they withdrawn from what's offered?

**What you're defining:**
- Emotional flatness or boredom
- What they're overlooking
- Why they've withdrawn
- The offer they can't see (or won't take)

**Character logic:** This is someone staring at the ground while the universe offers something. They might be meditating—or just missing the point.

**Examples:**
- Someone bored with a life others would envy
- A person so focused on what they've lost they can't see what's available
- A character in a contemplative withdrawal that might be growth or might be avoidance

### Reversed: The Awakening

**Core meaning:**
- Renewed interest, acceptance
- Seeing what was offered
- Emerging from withdrawal
- New perspective on old options

**Psychological translation:** "Wait—what was I missing?"

**Character question:** What is this character finally seeing—or what are they emerging from?

**What you're defining:**
- The end of apathy
- What they're finally ready to accept
- The new perspective that changed things
- Reengagement with life

**Character logic:** This is someone whose eyes are opening—seeing what was there all along.

**Examples:**
- Someone realizing they already have what they were looking for
- A person emerging from depression to see the support that was always there
- A character accepting an offer they'd previously dismissed

---

## Five of Cups

### Upright: The Grief

**Core meaning:**
- Loss, grief, disappointment
- Focusing on what's spilled
- Regret and mourning
- The cups behind you that you can't see

**Psychological translation:** "Look at what I lost. I can't see anything else."

**Character question:** What loss is this character mourning—and what are they failing to see behind them?

**What you're defining:**
- What they've lost
- How they're processing grief
- What they're overlooking in their sorrow
- Whether they're stuck or moving through

**Character logic:** This is someone in grief, staring at what's gone. The remaining cups are behind them—they may not know they're there.

**Examples:**
- Someone who lost a relationship and can't see anything else
- A person whose regret has become their identity
- A character mourning something while life continues around them

### Reversed: The Recovery

**Core meaning:**
- Acceptance, moving on, recovery
- Seeing what remains
- Grief processed (or avoided)
- Turning around

**Psychological translation:** "It still hurts, but I can see what's left."

**Character question:** What loss is this character learning to accept—or what grief are they bypassing?

**What you're defining:**
- Movement through grief
- What they're finally seeing
- Whether this is healthy acceptance or premature "moving on"
- What remains after loss

**Character logic:** This is someone turning around—either ready to move forward or pretending they are.

**Examples:**
- Someone who's finally processing a long-held grief
- A person beginning to rebuild after loss
- A character who claims to be "over it" but isn't

---

## Six of Cups

### Upright: The Nostalgia

**Core meaning:**
- Nostalgia, childhood, innocence
- Past memories, old connections
- The sweetness of what was
- Return to simpler times

**Psychological translation:** "Remember when? It was simpler then."

**Character question:** What past is this character returning to—and is it healing or avoidance?

**What you're defining:**
- Their relationship to the past
- What they're nostalgic for
- Old connections resurfacing
- Whether memory is serving them or trapping them

**Character logic:** This is someone touched by the past—revisiting, reconnecting, or longing.

**Examples:**
- Someone returning to their hometown after years away
- A person reconnecting with a childhood friend
- A character whose past holds something they need now

### Reversed: The Stuck

**Core meaning:**
- Living in the past, inability to move on
- Childhood trauma surfacing
- Nostalgia as avoidance
- Outgrowing what was

**Psychological translation:** "I keep going back there. I can't seem to leave."

**Character question:** How is the past holding this character—trapped, haunted, or refusing to grow?

**What you're defining:**
- Inability to leave the past
- Trauma surfacing
- Nostalgia that's become a cage
- What they need to outgrow

**Character logic:** This is someone whose past has too much power—either because they cling to it or because it won't let go.

**Examples:**
- Someone whose childhood still controls their adult choices
- A person who's idealized the past until the present can't compete
- A character who needs to finally move beyond where they came from

---

## Seven of Cups

### Upright: The Fantasy

**Core meaning:**
- Fantasy, illusion, choices
- Too many options, wishful thinking
- Dreams without action
- The dazzle of possibility

**Psychological translation:** "I could do anything. I can't choose. I choose nothing."

**Character question:** What fantasy is this character lost in—and what's real underneath?

**What you're defining:**
- Their relationship to dreams and illusions
- What they're fantasizing about instead of doing
- The paralysis of too many options
- What they actually want (under all the noise)

**Character logic:** This is someone drowning in possibility—seeing everything, choosing nothing.

**Examples:**
- A person with a thousand plans and no action
- Someone whose daydreams have replaced their life
- A character who can't commit because something better might come

### Reversed: The Clarity

**Core meaning:**
- Clarity, determination, choosing
- Illusions dispelled
- Reality faced
- One path selected from many

**Psychological translation:** "I see through it now. I know what I actually want."

**Character question:** What illusion is this character seeing through—and what are they choosing instead?

**What you're defining:**
- Clarity after confusion
- The illusion that fell away
- What they're finally choosing
- How they handle reality after fantasy

**Character logic:** This is someone who's cut through the fog—or had it cut for them.

**Examples:**
- Someone who finally realized what they actually want
- A person whose fantasy shattered and now they're dealing with what's real
- A character making a hard choice after avoiding it forever

---

## Eight of Cups

### Upright: The Departure

**Core meaning:**
- Leaving, walking away, seeking deeper meaning
- Abandoning what no longer serves
- The journey away from comfort
- Disappointment that demands departure

**Psychological translation:** "This isn't enough. I have to go find what is."

**Character question:** What is this character walking away from—and what are they walking toward?

**What you're defining:**
- What they're leaving (relationship, life, identity)
- Why it's no longer enough
- What they're seeking
- The courage (or desperation) to leave

**Character logic:** This is someone whose back is turned. They're walking away from something most people would keep.

**Examples:**
- Someone leaving a comfortable life for an uncertain calling
- A person walking out of a relationship that looks fine from outside
- A character whose dissatisfaction finally outweighed their fear

### Reversed: The Staying

**Core meaning:**
- Fear of change, staying too long
- Aimless wandering, no direction
- Returning to what was left
- Leaving without purpose

**Psychological translation:** "I should go, but I can't. Or I left and I'm lost."

**Character question:** Why is this character staying when they should leave—or wandering with no destination?

**What you're defining:**
- Fear of leaving
- Aimlessness after departure
- What keeps them somewhere that isn't enough
- The return they might make

**Character logic:** This is someone either stuck in a life they should leave, or lost after leaving.

**Examples:**
- Someone who knows they should go but can't take the step
- A person who left everything and now wanders without purpose
- A character considering returning to what they abandoned

---

## Nine of Cups

### Upright: The Contentment

**Core meaning:**
- Contentment, satisfaction, wishes fulfilled
- Emotional security and gratitude
- The wish come true
- Abundance of the heart

**Psychological translation:** "I have what I wanted. I can enjoy it."

**Character question:** What wish has been fulfilled for this character—and can they actually enjoy it?

**What you're defining:**
- What they have that they wanted
- Their capacity for contentment
- Emotional abundance
- The wish and its fulfillment

**Character logic:** This is someone whose cups are full. They got what they wanted.

**Examples:**
- Someone whose life has become what they dreamed
- A person finally at peace with what they have
- A character experiencing earned satisfaction

### Reversed: The Dissatisfaction

**Core meaning:**
- Dissatisfaction despite success
- Wishes fulfilled that weren't what they seemed
- Complacency or greed
- The dream achieved that disappoints

**Psychological translation:** "I got what I wanted. Why doesn't it feel like I thought?"

**Character question:** What has this character achieved that failed to satisfy—or what are they still grasping for?

**What you're defining:**
- The gap between wish and fulfillment
- What's missing despite having "everything"
- Whether the problem is the wish or the wishing
- What contentment would actually require

**Character logic:** This is someone who got what they wanted and found it wasn't enough—or who can't stop wanting more.

**Examples:**
- Someone who achieved the dream and felt nothing
- A person whose greed grew to match their success
- A character whose wish was granted exactly as stated—and that was the problem

---

## Ten of Cups

### Upright: The Fulfillment

**Core meaning:**
- Emotional fulfillment, family harmony
- Love complete, the happy ending
- Everything in its right place
- Joy that includes others

**Psychological translation:** "This is what happiness looks like. I'm living it."

**Character question:** What does emotional fulfillment look like for this character—and have they achieved it?

**What you're defining:**
- Their vision of fulfillment
- Family and relationships in harmony
- The "happy ending" (or its pursuit)
- What complete love looks like

**Character logic:** This is someone in the after—the rainbow, the family, the peace. The question is whether it's real or aspirational.

**Examples:**
- A family that actually functions with love
- Someone who's built the life they wanted
- A character whose relationships are genuinely nourishing

### Reversed: The Dysfunction

**Core meaning:**
- Family dysfunction, broken harmony
- The dream of love that failed
- Values in conflict
- Happiness performative or absent

**Psychological translation:** "It was supposed to be perfect. It isn't."

**Character question:** What has gone wrong in this character's vision of fulfillment—or what are they performing?

**What you're defining:**
- What's broken in the picture
- Family dysfunction or alienation
- The gap between performance and reality
- What "happy" would actually require

**Character logic:** This is someone whose rainbow is fake—or fading.

**Examples:**
- A family that looks perfect and isn't
- Someone whose idea of fulfillment turned out to be someone else's dream
- A character performing happiness while dying inside

---

## Page of Cups

### Upright: The Dreamer

**Core meaning:**
- Creativity, intuition, sensitivity
- Emotional beginnings, new feelings
- The artist's soul, the open heart
- Messages from the subconscious

**Psychological translation:** "I feel things deeply. I don't know what to do with it yet."

**Character question:** What is this character beginning to feel—and what does their sensitivity let them see?

**What you're defining:**
- Emotional or creative awakening
- Their sensitivity and what it costs them
- New feelings they don't quite understand
- The messages they're receiving

**Character logic:** This is someone whose heart is open and young—vulnerable, creative, attuned.

**Examples:**
- A young artist just discovering their medium
- Someone feeling something they can't name yet
- A character whose emotional openness is both gift and liability

### Reversed: The Wounded Dreamer

**Core meaning:**
- Emotional immaturity, creative blocks
- Sensitivity turned to vulnerability
- The message ignored
- Dreams deferred or corrupted

**Psychological translation:** "I feel too much. It's breaking me."

**Character question:** How has this character's sensitivity become a wound—or what dream have they abandoned?

**What you're defining:**
- Sensitivity overwhelmed
- Creative blocks from emotional damage
- Messages they're afraid to receive
- The dreamer whose dreams hurt

**Character logic:** This is someone whose open heart has been hurt—or whose dreams have turned against them.

**Examples:**
- A sensitive person who's been mocked for it
- Someone whose creativity dried up after trauma
- A character who closed off their feelings to survive

---

## Knight of Cups

### Upright: The Romantic

**Core meaning:**
- Romance, charm, imagination
- Following the heart
- The poet, the lover, the dreamer who moves
- Idealism in action

**Psychological translation:** "My heart says go. I'm going."

**Character question:** What is this character pursuing with their heart—and what does their idealism cost them?

**What you're defining:**
- What they're pursuing romantically or creatively
- Their idealism and its power
- How they charm and persuade
- Whether their heart leads them well

**Character logic:** This is someone who follows feeling into action. Romantic, charming, possibly unrealistic.

**Examples:**
- A person who falls in love completely every time
- An artist who pursues vision over practicality
- A character whose idealism inspires others (even when it fails)

### Reversed: The Moody Dreamer

**Core meaning:**
- Moodiness, unrealistic expectations
- Romance that disappoints
- Idealism curdled to cynicism
- The lover who can't commit

**Psychological translation:** "Nothing is as beautiful as I imagined it. Everything disappoints."

**Character question:** How has this character's idealism been wounded—or how does it wound others?

**What you're defining:**
- Disappointment from unrealistic expectations
- Moodiness from unmet romantic needs
- The idealist becoming cynic
- Commitment problems rooted in fantasy

**Character logic:** This is someone whose romantic heart has been hurt—or whose idealism has become a weapon.

**Examples:**
- Someone who can't commit because no one matches the fantasy
- A person whose charm has become manipulation
- A character whose beautiful vision has turned bitter

---

## Queen of Cups

### Upright: The Empath

**Core meaning:**
- Compassion, intuition, emotional security
- Deep understanding of others
- The heart that holds space
- Nurturing through emotional intelligence

**Psychological translation:** "I see what you're feeling. Let me hold it with you."

**Character question:** What does this character understand about others—and what does holding everyone's feelings cost them?

**What you're defining:**
- Their emotional intelligence
- How they nurture and hold space
- Their intuitive gifts
- The cost of feeling everyone's feelings

**Character logic:** This is someone who feels deeply and helps others feel. They understand currents others miss.

**Examples:**
- A therapist or healer who truly sees people
- Someone everyone comes to with their problems
- A character whose empathy is their greatest gift and burden

### Reversed: The Drowning Empath

**Core meaning:**
- Emotional overwhelm, martyrdom
- Intuition blocked or misused
- Giving too much, boundaries collapsed
- The empath who's lost themselves

**Psychological translation:** "I've absorbed so much, I don't know where they end and I begin."

**Character question:** How has this character lost themselves in others' emotions—or how have they shut down?

**What you're defining:**
- Boundary collapse
- Emotional exhaustion from overgiving
- Intuition that's blocked or unreliable
- What happens when the empath breaks

**Character logic:** This is someone whose gift has become a curse—drowning in others or shutting down completely.

**Examples:**
- A caretaker who's depleted themselves completely
- Someone whose emotional sensitivity has become a wall instead of a door
- A character manipulating through emotional intelligence

---

## King of Cups

### Upright: The Wise Heart

**Core meaning:**
- Emotional balance, wisdom in feeling
- Diplomacy, calm authority
- The heart that rules with compassion
- Mastery of emotion without suppression

**Psychological translation:** "I feel everything. I control how I respond."

**Character question:** How does this character hold emotional power—and what does their balance make possible?

**What you're defining:**
- Emotional mastery
- Leadership through emotional intelligence
- The balance of feeling and control
- How they help others navigate feeling

**Character logic:** This is someone who feels deeply but isn't ruled by feeling. They have emotional power and use it wisely.

**Examples:**
- A leader whose calm steadies everyone around them
- Someone who's achieved real emotional maturity through hard work
- A character whose wisdom comes from having felt everything

### Reversed: The Cold King

**Core meaning:**
- Emotional manipulation, volatility
- Suppression masquerading as control
- The heart that's frozen or weaponized
- Moodiness in power

**Psychological translation:** "I don't feel—or I feel too much and I'll make you pay for it."

**Character question:** How has this character's emotional power become dangerous—to others or themselves?

**What you're defining:**
- Emotional control that's actually suppression
- Power used for manipulation
- The volatility beneath the surface
- What happens when the king loses composure

**Character logic:** This is someone whose emotional power has gone wrong—either ice or explosion.

**Examples:**
- A leader who manipulates through emotional intelligence
- Someone whose calm is actually numbness
- A character whose suppressed emotions finally detonate

---

# Swords (Air — Intellect/Conflict/Truth)

## Ace of Swords

### Upright: The Breakthrough

**Core meaning:**
- Clarity, breakthrough, truth
- Mental force, new idea
- Cutting through confusion
- The moment of insight

**Psychological translation:** "I see it now. I understand."

**Character question:** What truth is this character seeing clearly—and what will they do with it?

**What you're defining:**
- A moment of clarity
- A new idea or perspective
- Their relationship to truth
- What changes when the fog lifts

**Character logic:** This is someone who's just understood something. The sword is raised—the question is what they'll cut.

**Examples:**
- Someone who's just had a breakthrough insight
- A person finally seeing a situation clearly
- A character whose new idea will change everything

### Reversed: The Confusion

**Core meaning:**
- Confusion, lack of clarity
- Truth blocked or distorted
- Mental chaos, bad ideas
- The insight that won't come

**Psychological translation:** "I can't see clearly. I can't think straight."

**Character question:** What is blocking this character's clarity—or what false clarity are they operating under?

**What you're defining:**
- Mental fog or chaos
- Confusion about truth
- Bad ideas taken for good ones
- What they can't see

**Character logic:** This is someone whose sword is dull or pointed the wrong way.

**Examples:**
- Someone who thinks they understand but doesn't
- A person whose thinking has been compromised
- A character lost in mental confusion

---

## Two of Swords

### Upright: The Stalemate

**Core meaning:**
- Difficult decisions, stalemate
- Denial, blocked emotions
- Refusing to see, refusing to choose
- The uncomfortable middle

**Psychological translation:** "I can't decide. I won't look."

**Character question:** What decision is this character refusing to make—and what are they refusing to see?

**What you're defining:**
- A decision they're avoiding
- What they won't look at
- The tension of indecision
- What both options cost

**Character logic:** This is someone blindfolded, swords crossed, balanced precariously. They can't stay here—but they are.

**Examples:**
- Someone who won't choose between two people
- A person avoiding information that would force a decision
- A character in deliberate denial

### Reversed: The Forced Choice

**Core meaning:**
- Information overload, lies revealed
- Forced decision, the blindfold removed
- Overwhelm or release from indecision
- Truth you can't unsee

**Psychological translation:** "I can see now. I didn't want to."

**Character question:** What has this character been forced to see—or what decision has been made for them?

**What you're defining:**
- The end of denial
- Information that forces choice
- Overwhelm from too much truth
- How they handle having to decide

**Character logic:** This is someone whose blindfold just came off—ready or not.

**Examples:**
- Someone who received information they couldn't ignore
- A person whose stalling ran out of time
- A character whose denial was stripped away

---

## Three of Swords

### Upright: The Heartbreak

**Core meaning:**
- Heartbreak, sorrow, grief
- Painful truth, necessary wound
- The words that cut
- Loss that can't be unfelt

**Psychological translation:** "This hurts more than I knew I could hurt."

**Character question:** What has pierced this character's heart—and what truth came with the wound?

**What you're defining:**
- The nature of the heartbreak
- What truth accompanied the pain
- How they're experiencing grief
- Whether this wound will heal or fester

**Character logic:** This is someone in acute emotional pain—the kind that comes with clarity.

**Examples:**
- Someone who just learned a devastating truth
- A person in the middle of heartbreak
- A character whose loss is fresh and sharp

### Reversed: The Healing

**Core meaning:**
- Recovery, releasing pain, forgiveness
- Grief processing (or suppressed)
- The wound that's finally healing
- Denial of pain

**Psychological translation:** "It's starting to hurt less. Or I'm pretending it doesn't hurt."

**Character question:** Is this character genuinely healing—or suppressing pain that will return?

**What you're defining:**
- Movement through grief
- Whether healing is real or performed
- What forgiveness looks like (or doesn't)
- What remains after the acute pain passes

**Character logic:** This is someone past the worst—either genuinely healing or convincing themselves they are.

**Examples:**
- Someone who's finally processing an old wound
- A person who's "over it" but isn't
- A character on the edge of real forgiveness

---

## Four of Swords

### Upright: The Rest

**Core meaning:**
- Rest, recovery, contemplation
- Necessary retreat, mental restoration
- Solitude for healing
- The pause before the next battle

**Psychological translation:** "I need to stop. I need to think. I need to heal."

**Character question:** What is this character recovering from—and what are they preparing for?

**What you're defining:**
- Why they need rest
- What they're processing in solitude
- The recovery they're in
- What comes after the rest

**Character logic:** This is someone who's stepped back—to heal, to think, to prepare.

**Examples:**
- Someone recovering from burnout
- A person in deliberate retreat to figure things out
- A character healing wounds before the next fight

### Reversed: The Restlessness

**Core meaning:**
- Restlessness, burnout, inability to rest
- Recovery interrupted
- Forced back into action too soon
- Mental exhaustion without relief

**Psychological translation:** "I can't rest. I can't stop. I'll collapse if I do."

**Character question:** What is preventing this character from resting—or what dragged them back before they were ready?

**What you're defining:**
- Inability to find rest
- Recovery that was interrupted
- What keeps them awake
- The cost of not stopping

**Character logic:** This is someone who needs rest and can't get it—or won't take it.

**Examples:**
- Someone whose mind won't quiet
- A person forced back to work before healing
- A character who's afraid of what happens if they stop

---

## Five of Swords

### Upright: The Pyrrhic Victory

**Core meaning:**
- Conflict, defeat, hollow victory
- Winning at any cost
- Betrayal, hostility
- The win that loses everything that mattered

**Psychological translation:** "I won. Look at what it cost."

**Character question:** What has this character won that wasn't worth winning—or what battle did they lose?

**What you're defining:**
- The conflict and its costs
- Whether they're the victor or the defeated
- What was sacrificed to win
- The hollow feeling after

**Character logic:** This is someone standing in the aftermath of conflict—holding the swords, alone.

**Examples:**
- Someone who won an argument and lost a relationship
- A person who got what they wanted and destroyed something in the process
- A character who achieved victory through betrayal

### Reversed: The Reconciliation

**Core meaning:**
- Reconciliation, moving on
- Regret, making amends
- Picking up the pieces
- Learning from conflict

**Psychological translation:** "I see what that cost. Can I fix it?"

**Character question:** What conflict is this character trying to repair—or what are they learning from defeat?

**What you're defining:**
- Attempts at repair
- What they regret
- Whether reconciliation is possible
- Growth from conflict

**Character logic:** This is someone dealing with the aftermath—trying to repair, or learning to live with what happened.

**Examples:**
- Someone trying to apologize for how they won
- A person who lost and is figuring out what to learn from it
- A character picking up the pieces of a relationship they damaged

---

## Six of Swords

### Upright: The Transition

**Core meaning:**
- Transition, moving on, leaving trouble behind
- Passage through difficulty
- Mental relief through change
- The journey toward calmer waters

**Psychological translation:** "I'm leaving. It's not easy, but it's necessary."

**Character question:** What is this character moving away from—and what do they hope to find?

**What you're defining:**
- What they're leaving
- The difficulty of the passage
- What they're carrying with them
- What calmer waters look like

**Character logic:** This is someone in transit—moving from something hard toward something (hopefully) better.

**Examples:**
- Someone leaving a bad situation with whatever they could carry
- A person in the difficult middle of major life transition
- A character moving toward healing, slowly

### Reversed: The Stuck

**Core meaning:**
- Stuck in transition, unfinished business
- Can't leave, can't move on
- Return to troubled waters
- The passage that won't complete

**Psychological translation:** "I thought I was leaving. I can't seem to get away."

**Character question:** What is keeping this character from completing their transition?

**What you're defining:**
- What's holding them in the difficult place
- Unfinished business that pulls them back
- The transition that stalled
- Whether they'll ever reach the other shore

**Character logic:** This is someone stuck in the passage—unable to leave completely or move forward fully.

**Examples:**
- Someone who left but keeps getting pulled back
- A person whose escape was incomplete
- A character trapped in limbo between old and new

---

## Seven of Swords

### Upright: The Deception

**Core meaning:**
- Deception, strategy, stealth
- Getting away with something
- Acting alone, avoiding detection
- Cunning that might be necessary or corrupt

**Psychological translation:** "I'm taking what I need and hoping no one notices."

**Character question:** What is this character stealing, hiding, or escaping with—and is it justified?

**What you're defining:**
- The deception and its nature
- Whether this is survival cunning or moral failure
- What they're trying to get away with
- The risk of getting caught

**Character logic:** This is someone operating in shadows—whether that's clever strategy or corruption depends on context.

**Examples:**
- Someone escaping with what they need to survive
- A person playing political games to get ahead
- A character whose small dishonesty is about to catch up

### Reversed: The Confession

**Core meaning:**
- Getting caught, coming clean
- Conscience, turning back
- Deception failing
- Choosing honesty over strategy

**Psychological translation:** "I can't keep this up. It's over—or I'm ending it."

**Character question:** Is this character getting caught—or choosing to come clean?

**What you're defining:**
- Whether exposure is forced or chosen
- What happens when the deception ends
- The conscience that won't stay quiet
- The cost of honesty

**Character logic:** This is someone whose stealth has ended—whether by choice or discovery.

**Examples:**
- Someone who confessed before they were caught
- A person whose scheme just fell apart
- A character whose lies have finally run out

---

## Eight of Swords

### Upright: The Imprisonment

**Core meaning:**
- Restriction, imprisonment, feeling trapped
- Self-imposed limitations
- Victim mentality, powerlessness
- The cage you can't see out of

**Psychological translation:** "I'm trapped. I can't see any way out."

**Character question:** What is trapping this character—and how much of it is real versus perceived?

**What you're defining:**
- The nature of their imprisonment (external or internal)
- What they can't see
- Self-imposed vs. genuine limitation
- What would happen if they moved

**Character logic:** This is someone who believes they're trapped. They might be—or they might be standing in an unlocked cage.

**Examples:**
- Someone in a situation they feel they can't leave
- A person whose own beliefs are the prison
- A character who can't see the exit that's three feet away

### Reversed: The Liberation

**Core meaning:**
- Freedom, release, new perspective
- Self-acceptance, removing blindfolds
- Escape from limitation
- Seeing the cage was open all along

**Psychological translation:** "Wait—I can move. I can leave. I'm not as stuck as I thought."

**Character question:** What limitation is this character finally escaping—and what did they need to see?

**What you're defining:**
- The shift in perspective
- How they got free
- What they can do now that they couldn't before
- The relief (or terror) of freedom

**Character logic:** This is someone whose blindfold just came off—seeing the cage was always open.

**Examples:**
- Someone who finally left a situation they thought was inescapable
- A person who changed their belief and changed their reality
- A character stepping out of their self-imposed limitations

---

## Nine of Swords

### Upright: The Nightmare

**Core meaning:**
- Anxiety, fear, nightmares
- Mental anguish, dark thoughts
- The 3 AM terror
- Suffering that's worse in your head

**Psychological translation:** "I can't stop thinking about it. It's eating me alive."

**Character question:** What is this character unable to stop thinking about—and is the threat as real as it feels?

**What you're defining:**
- The nature of their anxiety
- What haunts them
- The gap (if any) between fear and reality
- How they're coping (or not)

**Character logic:** This is someone in mental anguish—the nightmare may be real or may be anxiety making everything worse.

**Examples:**
- Someone who can't sleep from worry
- A person whose guilt won't let them rest
- A character whose anxiety has grown larger than the actual problem

### Reversed: The Dawn

**Core meaning:**
- Recovery, hope, coping
- Anxiety releasing its grip
- Reaching out for help
- The nightmare ending

**Psychological translation:** "It's morning. I survived. Maybe it's not as bad as I thought."

**Character question:** What is this character's anxiety releasing—or what help are they finally accepting?

**What you're defining:**
- The easing of mental anguish
- Whether recovery is genuine or temporary
- What they did to get through
- What the morning looks like

**Character logic:** This is someone whose darkest hour is passing—or who's finally reaching for help.

**Examples:**
- Someone whose worst fears didn't come true
- A person who finally told someone what they were going through
- A character learning to manage their anxiety

---

## Ten of Swords

### Upright: The End

**Core meaning:**
- Painful ending, betrayal complete
- Rock bottom, total defeat
- The worst is over
- Ending that forces new beginning

**Psychological translation:** "It's over. It's really over. The worst has happened."

**Character question:** What has ended completely for this character—and what does rock bottom look like?

**What you're defining:**
- The nature of the ending
- What was destroyed or betrayed
- The strange relief of the worst being done
- What remains when it's over

**Character logic:** This is someone at rock bottom. Ten swords—no more can fall. The only direction from here is up.

**Examples:**
- Someone whose worst fears came true
- A person who lost everything and survived
- A character at the end of a chapter, ready or not

### Reversed: The Survival

**Core meaning:**
- Survival, recovery, worst avoided
- Rising after defeat
- Lessons learned from pain
- The ending that didn't destroy them

**Psychological translation:** "I lived through it. I'm still here. Now what?"

**Character question:** What has this character survived—and how are they different now?

**What you're defining:**
- What they came through
- How they're rising
- What they learned from the fall
- The new beginning after destruction

**Character logic:** This is someone getting back up—the swords are still there, but they didn't die.

**Examples:**
- Someone rebuilding after total collapse
- A person who survived betrayal and is changed by it
- A character who hit bottom and is starting the climb

---

## Page of Swords

### Upright: The Vigilant

**Core meaning:**
- Curiosity, mental energy, vigilance
- Truth-seeking, new ideas
- The mind awakening to inquiry
- Alert to everything

**Psychological translation:** "I want to know. I'm watching. I'm thinking."

**Character question:** What is this character investigating—and what drives their curiosity?

**What you're defining:**
- Their mental energy and curiosity
- What they're watching or investigating
- Their relationship to truth
- The vigilance (productive or paranoid)

**Character logic:** This is someone whose mind is sharp and alert—they notice things others miss.

**Examples:**
- A young journalist asking uncomfortable questions
- Someone who's always watching, always thinking
- A character whose curiosity leads them into trouble

### Reversed: The Scattered

**Core meaning:**
- Scattered thoughts, paranoia
- Deception (doing or receiving)
- Hasty conclusions, gossip
- Mental energy without focus

**Psychological translation:** "I can't focus. Everyone's lying. Or I am."

**Character question:** What is scattered in this character's thinking—or what lies are they involved with?

**What you're defining:**
- Mental chaos or paranoia
- Deception (committed or believed)
- Conclusions jumped to
- The cost of unfocused mental energy

**Character logic:** This is someone whose sharp mind has turned against them—or against others.

**Examples:**
- A person whose suspicion sees enemies everywhere
- Someone spreading rumors or lies
- A character whose intelligence is scattered into anxiety

---

## Knight of Swords

### Upright: The Charge

**Core meaning:**
- Ambition, fast action, determination
- Charging ahead mentally
- Cutting through obstacles
- Intelligence in aggressive motion

**Psychological translation:** "I know what I think. I'm going to say it. Move."

**Character question:** What is this character charging toward—and what are they cutting through?

**What you're defining:**
- Their intellectual ambition
- How they cut through obstacles
- The speed of their action
- What they're not considering in their rush

**Character logic:** This is someone whose mind is a weapon in motion—fast, sharp, possibly reckless.

**Examples:**
- A debater who wins but makes enemies
- Someone pursuing truth regardless of cost
- A character whose intelligence is a battering ram

### Reversed: The Reckless

**Core meaning:**
- Recklessness, aggression, burnout
- Intelligence without wisdom
- Hasty decisions, scattered energy
- The charge that hit a wall

**Psychological translation:** "I moved too fast. I cut the wrong things."

**Character question:** What has this character's mental aggression cost them?

**What you're defining:**
- Intellectual recklessness
- Damage from hasty decisions
- What they cut that they shouldn't have
- The burnout from constant charging

**Character logic:** This is someone whose mental charge has gone wrong—crashed, scattered, or destructive.

**Examples:**
- Someone whose aggressive debate style has alienated everyone
- A person who made a decision too fast and can't undo it
- A character whose brilliance has become a liability

---

## Queen of Swords

### Upright: The Clarity

**Core meaning:**
- Clear thinking, direct communication
- Independence, boundaries
- Perception without illusion
- Truth wielded with precision

**Psychological translation:** "I see clearly. I speak directly. I don't pretend."

**Character question:** What does this character see that others won't admit—and how do their boundaries serve them?

**What you're defining:**
- Their intellectual clarity
- How they communicate truth
- Their boundaries and independence
- What being this perceptive costs them

**Character logic:** This is someone who sees clearly and speaks plainly. They're not cruel—but they're not comfortable either.

**Examples:**
- A person who always tells you what you need to hear
- Someone whose boundaries are firm and necessary
- A character whose perception cuts through everyone's illusions

### Reversed: The Cold

**Core meaning:**
- Coldness, cruelty, isolation
- Perception weaponized
- Boundaries as walls
- Truth without compassion

**Psychological translation:** "I see everything wrong with you. Why should I hide it?"

**Character question:** How has this character's clarity become cruelty—or their independence become isolation?

**What you're defining:**
- Perception used to wound
- Coldness that was once just clarity
- Isolation from being too cutting
- What they've lost by being this sharp

**Character logic:** This is someone whose clear sight has become a weapon—against others or themselves.

**Examples:**
- Someone whose "honesty" is actually cruelty
- A person whose independence has become loneliness
- A character who's driven everyone away with their sharp tongue

---

## King of Swords

### Upright: The Authority

**Core meaning:**
- Intellectual authority, clear judgment
- Truth and ethics
- Power through mental mastery
- Leadership of the mind

**Psychological translation:** "I've thought this through. Here's the truth. Here's what's right."

**Character question:** What authority does this character hold—and how do they use their intellectual power?

**What you're defining:**
- Their intellectual leadership
- How they make judgments
- Their relationship to truth and ethics
- The weight of their analytical power

**Character logic:** This is someone whose mind commands respect. They've earned their authority through clarity and wisdom.

**Examples:**
- A judge whose rulings are fair and thoughtful
- Someone whose intellectual authority shapes how others think
- A character who leads through reason and truth

### Reversed: The Tyrant Mind

**Core meaning:**
- Manipulation, abuse of power
- Cold rationality without heart
- Intellectual tyranny
- Using truth as a weapon

**Psychological translation:** "I'm smarter than you. I'll use that to control you."

**Character question:** How does this character abuse their intellectual power?

**What you're defining:**
- Mind used for manipulation
- Truth deployed as weapon
- Cold logic without ethics
- The damage their intelligence does

**Character logic:** This is someone whose mental power has become oppressive—to others or themselves.

**Examples:**
- A leader who manipulates through superior reasoning
- Someone whose intelligence is used to demean others
- A character whose cold logic has frozen out their humanity

---

# Pentacles (Earth — Material/Practical/Physical)

## Ace of Pentacles

### Upright: The Opportunity

**Core meaning:**
- New opportunity, prosperity beginning
- Material or financial seed
- Manifestation, abundance starting
- The gift you can grow

**Psychological translation:** "This is real. This is something I can build on."

**Character question:** What opportunity is this character receiving—and will they cultivate it?

**What you're defining:**
- A practical new beginning
- Financial or material opportunity
- Their relationship to resources
- What they could build from here

**Character logic:** This is someone being handed something real—a job, money, opportunity, something tangible. What they do with it is the question.

**Examples:**
- Someone receiving their first real opportunity
- A person whose practical situation just changed
- A character with a seed they could grow into something substantial

### Reversed: The Missed Opportunity

**Core meaning:**
- Missed opportunity, poor planning
- Material instability
- Abundance blocked or wasted
- The seed that wasn't planted

**Psychological translation:** "I had something real. I lost it—or I can't reach it."

**Character question:** What opportunity is this character missing—or what material security eludes them?

**What you're defining:**
- Opportunities missed or wasted
- Financial or practical instability
- What's blocking material success
- The abundance they can't access

**Character logic:** This is someone whose material opportunity went wrong—missed, wasted, or blocked.

**Examples:**
- Someone who let a real chance pass them by
- A person whose financial ground is unstable
- A character unable to access the opportunities others see

---

## Two of Pentacles

### Upright: The Balance

**Core meaning:**
- Balance, adaptability, juggling priorities
- Managing multiple responsibilities
- Staying flexible under pressure
- The dance of keeping everything in the air

**Psychological translation:** "I'm managing. Barely. But I'm managing."

**Character question:** What is this character juggling—and how long can they keep it up?

**What you're defining:**
- What they're balancing
- Their adaptability under pressure
- The strain of juggling
- What drops if they stop

**Character logic:** This is someone keeping multiple things in the air—work, life, obligations. The balance is working, for now.

**Examples:**
- Someone working two jobs while raising kids
- A person managing competing demands with surprising grace
- A character whose life requires constant rebalancing

### Reversed: The Overwhelm

**Core meaning:**
- Imbalance, overcommitment
- Dropping balls, unable to cope
- Poor financial management
- The juggling that's failing

**Psychological translation:** "I can't keep up. Things are falling."

**Character question:** What has this character been unable to balance—and what's falling?

**What you're defining:**
- What they've overcommitted to
- What's dropping
- The strain of failed balance
- What they need to let go of

**Character logic:** This is someone whose juggling has failed—things are falling, or about to.

**Examples:**
- Someone whose life has become unmanageable
- A person whose financial situation is out of control
- A character who took on too much and is watching it fall apart

---

## Three of Pentacles

### Upright: The Collaboration

**Core meaning:**
- Teamwork, collaboration, skill
- Building something together
- Learning and craftsmanship
- Work recognized by others

**Psychological translation:** "We're building something real, together. The work matters."

**Character question:** What is this character building with others—and what role do they play?

**What you're defining:**
- Collaborative work
- Their skills and contribution
- The team or partnership
- What's being built

**Character logic:** This is someone part of something larger—skilled, contributing, working with others toward something real.

**Examples:**
- An apprentice learning from masters
- Part of a team building something meaningful
- Someone whose skills are valued in collaboration

### Reversed: The Disconnect

**Core meaning:**
- Lack of teamwork, disharmony
- Skills unrecognized, poor quality
- Working alone when collaboration is needed
- The build that's failing

**Psychological translation:** "We're not working together. This isn't coming out right."

**Character question:** What collaboration is failing for this character—or why can't they work with others?

**What you're defining:**
- Breakdown in teamwork
- Skills undervalued or lacking
- Why collaboration isn't working
- What suffers when people can't work together

**Character logic:** This is someone whose teamwork has broken down—or whose skills aren't being recognized.

**Examples:**
- Someone whose ideas are ignored by the team
- A person unable to collaborate effectively
- A character whose work quality is suffering from isolation

---

## Four of Pentacles

### Upright: The Holding

**Core meaning:**
- Security, conservation, control
- Holding tight to what you have
- Protection (or possessiveness)
- Fear of loss manifesting as grip

**Psychological translation:** "I have this. I'm not letting go."

**Character question:** What is this character holding onto—and is it security or fear?

**What you're defining:**
- What they're protecting
- Security vs. possessiveness
- Their relationship to material things
- What they fear losing

**Character logic:** This is someone with a tight grip—on money, resources, security. The question is whether it's wise caution or fearful hoarding.

**Examples:**
- Someone who grew up poor and now saves obsessively
- A person protecting what they've built from any threat
- A character whose security has become a prison

### Reversed: The Release

**Core meaning:**
- Releasing control, generosity
- Financial loss, reckless spending
- Letting go (healthy or not)
- Greed or its opposite

**Psychological translation:** "I'm letting go—by choice or by force."

**Character question:** What is this character releasing their grip on—and is it growth or loss?

**What you're defining:**
- Release of material attachment
- Whether letting go is wisdom or recklessness
- Financial instability from release
- What they're learning about holding/releasing

**Character logic:** This is someone whose grip has loosened—either opening their hands generously or watching things slip away.

**Examples:**
- Someone learning to be generous after years of hoarding
- A person whose financial security has crumbled
- A character finally letting go of material obsession

---

## Five of Pentacles

### Upright: The Hardship

**Core meaning:**
- Financial loss, poverty, hardship
- Feeling left out in the cold
- Material struggle
- Help that might be nearby but unnoticed

**Psychological translation:** "I'm outside. I'm cold. I don't know where to go."

**Character question:** What hardship is this character experiencing—and what help are they not seeing?

**What you're defining:**
- The nature of their material struggle
- Their isolation or exclusion
- Help that exists but isn't accessed
- How they cope with scarcity

**Character logic:** This is someone in material difficulty—outside the warmth, struggling. There's often a church window lit behind them, if they'd only turn around.

**Examples:**
- Someone who's lost everything and doesn't know where to go
- A person too proud to ask for available help
- A character excluded from security others take for granted

### Reversed: The Recovery

**Core meaning:**
- Recovery, improvement, help accepted
- Turning point in hardship
- Finding the resources that were there
- Spiritual poverty even in material recovery

**Psychological translation:** "I found help. Or I'm starting to recover. Or I've recovered everything but my spirit."

**Character question:** What recovery is this character beginning—and what did the hardship teach them?

**What you're defining:**
- The turn from hardship
- Help finally accepted
- What they learned from struggle
- Recovery that might be only material

**Character logic:** This is someone whose material situation is improving—or who found the help that was there all along.

**Examples:**
- Someone who finally asked for help and received it
- A person rebuilding after hitting bottom
- A character who's financially recovered but spiritually still cold

---

## Six of Pentacles

### Upright: The Exchange

**Core meaning:**
- Generosity, giving and receiving
- Charity, sharing wealth
- Balance of resources
- Help that flows both ways

**Psychological translation:** "I have enough to share. Or: I need help and someone's giving it."

**Character question:** Is this character giving or receiving—and how do they relate to each role?

**What you're defining:**
- Their position (giver or receiver)
- How they relate to generosity
- The balance of exchange
- Power dynamics in giving/receiving

**Character logic:** This is someone in an exchange—giving or receiving resources. The question is whether it's equal, charitable, or controlling.

**Examples:**
- A philanthropist who gives genuinely
- Someone learning to receive without shame
- A character whose charity has power dynamics

### Reversed: The Strings

**Core meaning:**
- Strings attached, debt, unfair exchange
- Charity with conditions
- Giving or receiving that's corrupted
- Power imbalance in resources

**Psychological translation:** "This help comes with a price. Or I'm giving to control."

**Character question:** What strings are attached to this character's giving or receiving?

**What you're defining:**
- The corruption of exchange
- Debt (financial or emotional)
- Power plays through resources
- What the "gift" actually costs

**Character logic:** This is someone in a corrupt exchange—giving with strings or receiving with debt.

**Examples:**
- Someone whose generosity is really control
- A person trapped by obligation to their "benefactor"
- A character who uses money to manipulate

---

## Seven of Pentacles

### Upright: The Assessment

**Core meaning:**
- Patience, long-term view, assessment
- Waiting for the harvest
- Evaluating what's been built
- Perseverance with uncertainty

**Psychological translation:** "I've been working. I'm not sure yet if it's paying off."

**Character question:** What is this character assessing—and do they have the patience to wait for the harvest?

**What you're defining:**
- The long-term project they're evaluating
- Their patience (or lack thereof)
- Whether the investment will pay off
- The uncertainty of waiting

**Character logic:** This is someone looking at what they've planted, not sure yet if it will bear fruit.

**Examples:**
- An entrepreneur mid-journey, checking progress
- Someone who's invested years in something and isn't sure it's working
- A character taking stock of their life so far

### Reversed: The Impatience

**Core meaning:**
- Impatience, wasted effort, poor returns
- Giving up too soon
- Assessment revealing failure
- The investment that didn't pay

**Psychological translation:** "I've waited too long. It's not working. Or I can't wait anymore."

**Character question:** What has this character invested in that isn't paying off—or what are they giving up on too soon?

**What you're defining:**
- Wasted effort or poor investment
- Impatience destroying the harvest
- The assessment that reveals failure
- Whether giving up is wise or premature

**Character logic:** This is someone whose investment isn't paying off—or who can't wait long enough to find out.

**Examples:**
- Someone who quit right before the breakthrough
- A person whose long-term effort genuinely failed
- A character too impatient to let their work mature

---

## Eight of Pentacles

### Upright: The Craft

**Core meaning:**
- Skill development, diligence, mastery
- Dedication to craft
- Apprenticeship, learning
- Work that develops expertise

**Psychological translation:** "I'm getting better. The work is teaching me."

**Character question:** What craft is this character developing—and what does mastery mean to them?

**What you're defining:**
- Their skill and its development
- Dedication to improvement
- The joy (or discipline) of practice
- What they're working toward

**Character logic:** This is someone at the workbench—focused, improving, building skill through repetition.

**Examples:**
- An apprentice becoming a master through practice
- Someone finding purpose in dedicated work
- A character whose craft defines them

### Reversed: The Perfunctory

**Core meaning:**
- Poor quality, lack of focus
- Work without passion or growth
- Perfectionism or boredom
- Skill stagnating

**Psychological translation:** "I'm going through the motions. I'm not growing."

**Character question:** What has gone wrong with this character's relationship to their craft?

**What you're defining:**
- Work without engagement
- Skill that's stopped developing
- Perfectionism blocking completion
- Boredom with mastery

**Character logic:** This is someone whose relationship to their work has soured—through boredom, perfectionism, or loss of purpose.

**Examples:**
- Someone who's mastered their craft and finds it meaningless
- A person whose perfectionism prevents finishing anything
- A character going through motions without growth

---

## Nine of Pentacles

### Upright: The Achievement

**Core meaning:**
- Abundance, luxury, self-sufficiency
- Independence earned through work
- Enjoying the fruits of labor
- Material success, refinement

**Psychological translation:** "I built this. I can enjoy it. I don't need anyone's help."

**Character question:** What has this character achieved independently—and can they enjoy it?

**What you're defining:**
- Material success and its source
- Self-sufficiency and independence
- Their relationship to luxury and comfort
- What they've earned

**Character logic:** This is someone standing in their garden—everything they have, they built. The question is whether they can enjoy it.

**Examples:**
- Someone who's achieved financial independence through their own work
- A person surrounded by the fruits of their labor
- A character who has everything—and might be lonely in it

### Reversed: The Gilded Cage

**Core meaning:**
- Financial setback, dependence
- Success at the cost of something else
- Luxury without freedom
- The achievement that doesn't satisfy

**Psychological translation:** "I have everything—except what I actually wanted."

**Character question:** What has this character's success cost them—or what dependence underlies their apparent independence?

**What you're defining:**
- The hidden cost of achievement
- Dependence beneath apparent success
- What's missing despite material abundance
- Financial instability under the surface

**Character logic:** This is someone whose success is incomplete, hollow, or dependent on something they don't want to acknowledge.

**Examples:**
- Someone whose wealth came from compromise
- A person who's financially successful and deeply unhappy
- A character whose independence is actually dependence on something harmful

---

## Ten of Pentacles

### Upright: The Legacy

**Core meaning:**
- Legacy, inheritance, long-term success
- Family wealth, establishment
- What's built to last
- The end of material building

**Psychological translation:** "This is what I'll leave behind. This is what I inherited."

**Character question:** What legacy does this character hold—and what will they pass on?

**What you're defining:**
- What they've inherited or built
- Family and generational wealth (material or otherwise)
- What lasts beyond them
- Their place in something larger

**Character logic:** This is someone connected to something lasting—receiving from those before, passing to those after.

**Examples:**
- An heir to a family legacy
- Someone who's built something that will outlast them
- A character thinking about what they'll leave behind

### Reversed: The Burden

**Core meaning:**
- Family conflict, disinheritance
- Legacy as burden
- Financial instability despite appearances
- The inheritance that costs more than it gives

**Psychological translation:** "This legacy is poisoned. Or I've been cut off from it."

**Character question:** What family legacy is this character burdened by—or cut off from?

**What you're defining:**
- Family conflict over resources
- Legacy that's more burden than gift
- Being cut off from inheritance
- Generational problems

**Character logic:** This is someone whose relationship to legacy has gone wrong—burdened by inheritance or excluded from it.

**Examples:**
- Someone whose family fortune comes with unbearable expectations
- A person cut out of the will
- A character inheriting problems, not just wealth

---

## Page of Pentacles

### Upright: The Student

**Core meaning:**
- New financial opportunity, study
- Practical beginnings, manifestation starting
- Learning a trade, grounded ambition
- The seed of material success

**Psychological translation:** "I'm learning. I'm starting. This is real."

**Character question:** What practical skill or opportunity is this character beginning to develop?

**What you're defining:**
- Their practical ambition
- What they're learning
- New financial or material opportunity
- Grounded, realistic beginnings

**Character logic:** This is someone at the start of practical development—studying, planning, grounded and ready to build.

**Examples:**
- A student learning a trade
- Someone with a solid business idea just beginning
- A character whose practical dreams are taking shape

### Reversed: The Unfocused

**Core meaning:**
- Lack of progress, poor planning
- Opportunity squandered
- Impractical dreams, unfocused
- The start that didn't happen

**Psychological translation:** "I have plans. I just... haven't started."

**Character question:** What practical beginning is this character failing to make—and why?

**What you're defining:**
- Opportunities not taken
- Dreams without practical grounding
- Lack of focus on material needs
- What's keeping them from starting

**Character logic:** This is someone whose practical beginnings aren't materializing—through poor planning, distraction, or fear.

**Examples:**
- Someone with eternal plans but no action
- A person whose business idea never quite launches
- A character whose dreams are impractical

---

## Knight of Pentacles

### Upright: The Steady

**Core meaning:**
- Hard work, routine, responsibility
- Steady progress, reliability
- Methodical approach, dedication
- Slow and steady wins

**Psychological translation:** "I show up. I do the work. Every day."

**Character question:** What is this character steadily building—and what does their reliability cost them?

**What you're defining:**
- Their work ethic and reliability
- What they're building slowly
- The power of consistency
- What they sacrifice for steadiness

**Character logic:** This is someone who shows up and does the work—not flashy, but absolutely reliable.

**Examples:**
- The employee who's been there 20 years and everything depends on them
- Someone building wealth slowly and surely
- A character whose consistency is their superpower

### Reversed: The Stuck

**Core meaning:**
- Stagnation, laziness, stubbornness
- Routine without progress
- Boredom, being stuck
- Reliability curdled to rigidity

**Psychological translation:** "I'm doing the same thing every day. Nothing's changing. Nothing will."

**Character question:** What has this character's steadiness become—stagnation or stubbornness?

**What you're defining:**
- Routine without growth
- Work without progress
- Stubbornness blocking change
- The rut they're in

**Character logic:** This is someone whose steadiness has become a trap—working hard but going nowhere.

**Examples:**
- Someone who's done the same job for years with no advancement
- A person whose routine has become a prison
- A character too stubborn to try a new approach

---

## Queen of Pentacles

### Upright: The Provider

**Core meaning:**
- Nurturing, practical care, abundance
- Creating security for others
- Grounded prosperity, generous provision
- Making the home abundant

**Psychological translation:** "Everyone is fed. Everyone is warm. I made sure of it."

**Character question:** What does this character provide for others—and who provides for them?

**What you're defining:**
- How they create practical security
- Their nurturing through material means
- The abundance they cultivate
- Their groundedness and warmth

**Character logic:** This is someone who makes things work—practically, generously, warmly. Their domain is abundant.

**Examples:**
- A parent whose home is always warm and full
- Someone whose practical care is how they show love
- A character who creates security wherever they go

### Reversed: The Neglected

**Core meaning:**
- Neglect of self or others, imbalance
- Material security at cost of self
- Dependence, failure to provide
- Work-life imbalance

**Psychological translation:** "I've taken care of everyone except myself. Or I can't take care of anyone."

**Character question:** Who is this character neglecting—themselves or others?

**What you're defining:**
- Self-neglect in service to others
- Failure to provide practical security
- Material focus crowding out other needs
- The cost of endless provision

**Character logic:** This is someone whose practical care has gone wrong—either depleting themselves or failing to provide.

**Examples:**
- A caregiver who's given everything and has nothing left
- Someone whose pursuit of security has cost them relationships
- A character unable to create the stability they or others need

---

## King of Pentacles

### Upright: The Builder

**Core meaning:**
- Abundance, security, leadership
- Material success through discipline
- Building empires, wealth mastery
- Generosity from abundance

**Psychological translation:** "I built this. I can share it. It's solid."

**Character question:** What has this character built—and how do they wield their material power?

**What you're defining:**
- Their material success
- How they lead in practical matters
- The empire they've created
- Their relationship to wealth and sharing it

**Character logic:** This is someone who's built something real—financially successful, practically powerful, potentially generous.

**Examples:**
- A self-made success who remembers where they came from
- Someone whose business acumen is matched by wisdom
- A character who wields material power responsibly

### Reversed: The Miser

**Core meaning:**
- Greed, materialism, corruption
- Wealth hoarded or squandered
- Using money for control
- Success corrupted

**Psychological translation:** "This is mine. All of it. I'm not sharing."

**Character question:** How has this character's material success corrupted them?

**What you're defining:**
- Greed or obsession with wealth
- Using resources for control
- The corruption of material success
- What they've sacrificed for money

**Character logic:** This is someone whose relationship to money has become toxic—hoarding, controlling, or corrupted.

**Examples:**
- A wealthy person who uses money to manipulate
- Someone so focused on wealth they've lost everything else
- A character whose success has made them cruel