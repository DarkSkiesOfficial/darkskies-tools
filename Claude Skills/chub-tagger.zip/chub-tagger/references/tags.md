# Chub.ai Tags Reference

This file contains all curated tags for Chub.ai character uploads, organized by follower count (highest to lowest).

## Usage Notes

- **Prioritize high-follower tags** (10k+) for maximum discoverability
- **Multiple similar tags are intentional** for coverage (e.g., "OC" and "Original Character")
- **"Mother" tags** (Mother, Mommy, Mom, Dommy Mommy, Muscle Mommy, motherly) should ONLY be used when the character IS a mother, not when they're YOUR mother
- **"Teenager" tag** is for 18-19 year old characters only (legal adults)
- **POV tags** (Malepov, Fempov, anypov/Any POV) indicate supported perspectives
- **NSFW content guidelines** are handled by the NSFW, SFW, and "SFW <-> NSFW" tags

## High Priority Tags (10k+ Followers)

NSFW - 131,944 Followers
Female - 94,406 Followers
Dominant - 43,495 Followers
Roleplay - 39,843 Followers
Romance - 33,237 Followers
Submissive - 24,862 Followers
Size Difference - 22,943 Followers
Love - 21,018 Followers
Milf - 20,300 Followers
Anime - 19,580 Followers
Human - 19,087 Followers
Furry - 19,001 Followers
OC - 17,222 Followers
Fantasy - 17,067 Followers
SFW <-> NSFW - 15,497 Followers
Scenario - 15,178 Followers
Huge Breasts - 15,113 Followers
Teenager - 15,032 Followers
Yandere - 14,203 Followers
Cute - 14,007 Followers
Game Characters - 13,509 Followers
Breeding Kink - 13,477 Followers
Humiliation - 13,337 Followers
English - 13,123 Followers
Malepov - 13,102 Followers
Mother - 13,080 Followers
femdom - 12,922 Followers
Mommy - 12,408 Followers
Sadistic - 12,196 Followers
Fempov - 11,485 Followers
Monster Girl - 10,684 Followers
NTR - 10,538 Followers
Non-Human - 10,532 Followers
anypov - 10,269 Followers
Muscular - 10,093 Followers
Big Breast - 10,036 Followers

## Very Popular Tags (5k-10k Followers)

Big Butt - 9,211 Followers
Mature - 8,995 Followers
Smut - 8,816 Followers
RPG - 8,785 Followers
Slave - 8,737 Followers
can be wholesome, can be sexy - 8,720 Followers
Wholesome - 8,693 Followers
BDSM - 8,573 Followers
Tomboy - 8,429 Followers
Impregnation - 7,811 Followers
horny - 7,651 Followers
Anime Game Characters - 7,584 Followers
Original Character - 7,376 Followers
Any POV - 7,277 Followers
Villain - 7,254 Followers
Anthro - 6,989 Followers
Huge Butt - 6,901 Followers
Demon - 6,852 Followers
Horror - 6,833 Followers
Violent - 6,548 Followers
Pokemon - 6,397 Followers
Chubby - 6,295 Followers
Romantic - 6,099 Followers
Huge Ass - 6,093 Followers
Dark fantasy - 5,951 Followers
Virgin - 5,907 Followers
tsundere - 5,878 Followers
Netori - 5,844 Followers
girlfriend - 5,804 Followers
Drama - 5,799 Followers
Goth - 5,797 Followers
Multiple Girls - 5,581 Followers
Obsessive - 5,316 Followers
Games - 5,316 Followers
Anime Character - 5,289 Followers
Cheating - 5,266 Followers
Wife - 5,204 Followers
Sizeplay - 5,185 Followers
breeding - 5,126 Followers
Feral - 5,029 Followers

## Popular Tags (3k-5k Followers)

Tall woman - 4,959 Followers
Bully - 4,953 Followers
Adventure - 4,897 Followers
Hypnosis - 4,869 Followers
shy - 4,803 Followers
Brat - 4,774 Followers
sexy - 4,751 Followers
Gentle Femdom - 4,691 Followers
Maid - 4,578 Followers
videogame - 4,575 Followers
succubus - 4,559 Followers
Elf - 4,475 Followers
childhood friend - 4,445 Followers
Seductive - 4,444 Followers
Animals - 4,372 Followers
Bisexual - 4,294 Followers
Pervert - 4,280 Followers
SFW - 4,278 Followers
teacher - 4,256 Followers
Action - 4,181 Followers
kinky - 4,178 Followers
thick thighs - 4,151 Followers
Flirty - 4,147 Followers
Video Games - 4,147 Followers
Lesbian - 4,144 Followers
Possessive - 4,125 Followers
Fictional Character - 4,095 Followers
Monsters - 4,055 Followers
Corruption - 4,044 Followers
Manga - 3,985 Followers
Dommy Mommy - 3,983 Followers
Vampire - 3,975 Followers
Pregnant - 3,935 Followers
Fetish - 3,933 Followers
Petite - 3,862 Followers
Giantess - 3,838 Followers
Shortstack - 3,803 Followers
catgirl - 3,761 Followers
Older female - 3,659 Followers
Magic - 3,639 Followers
School - 3,636 Followers
Robot - 3,588 Followers
large breasts - 3,576 Followers
Big boobies - 3,515 Followers
Mom - 3,510 Followers
innocent - 3,503 Followers
Movies & TV - 3,487 Followers
monstergirl - 3,432 Followers
Harem - 3,430 Followers
Dominant <-> Submissive - 3,386 Followers
Alien - 3,369 Followers
Science Fiction - 3,346 Followers
Comedy - 3,332 Followers
transformation - 3,251 Followers
student - 3,241 Followers
Goddess - 3,240 Followers
monster - 3,149 Followers
Multiple Greetings - 3,129 Followers
exhibitionism - 3,079 Followers
big breasts - 3,056 Followers
motherly - 3,032 Followers
manipulative - 3,027 Followers
Sweat - 3,008 Followers

## Well-Known Tags (2k-3k Followers)

Famous People - 2,955 Followers
NonEnglish - 2,949 Followers
Enemies to Lovers - 2,897 Followers
Fat - 2,837 Followers
VTuber - 2,831 Followers
thick - 2,811 Followers
Petplay - 2,807 Followers
roommate - 2,782 Followers
Cuckolding - 2,781 Followers
Feet - 2,756 Followers
Demon Girl - 2,670 Followers
small breasts - 2,636 Followers
Dragon - 2,631 Followers
Lewd - 2,617 Followers
Masturbation - 2,614 Followers
Simulator - 2,599 Followers
Royalty - 2,571 Followers
Depressed - 2,569 Followers
gyaru - 2,537 Followers
switch - 2,528 Followers
Thicc - 2,528 Followers
demihuman - 2,509 Followers
Gilf - 2,491 Followers
Cartoon - 2,483 Followers
bratty - 2,453 Followers
teasing - 2,450 Followers
Evil - 2,397 Followers
Bondage - 2,395 Followers
Massive Ass - 2,303 Followers
Entertainment - 2,256 Followers
brainwashing - 2,220 Followers
Military - 2,198 Followers
Medieval - 2,177 Followers
Japanese - 2,164 Followers
Robot Girl - 2,157 Followers
anti-NTR - 2,150 Followers
bbw - 2,145 Followers
Pregnancy - 2,128 Followers
Princess - 2,102 Followers
Foxgirl - 2,094 Followers
nerd - 2,093 Followers
Big thighs - 2,067 Followers
Tentacles - 2,066 Followers
Netorare - 2,044 Followers
Dark-Skinned - 2,034 Followers
Cat Girl - 2,029 Followers

## Established Tags (1k-2k Followers)

funny - 1,992 Followers
Slice of Life - 1,974 Followers
Angst - 1,973 Followers
Isekai - 1,962 Followers
Superhero - 1,905 Followers
Nympho - 1,898 Followers
Strong Woman - 1,890 Followers
video game character - 1,842 Followers
Muscle Mommy - 1,834 Followers
Public - 1,831 Followers
Ghost - 1,816 Followers
History - 1,816 Followers
Religion - 1,813 Followers
stalker - 1,808 Followers
WLW - 1,789 Followers
Android - 1,787 Followers
Multiple Scenarios - 1,778 Followers
Post-apocalypse - 1,773 Followers
Nonhuman Character - 1,770 Followers
Mystery - 1,762 Followers
Psychopath - 1,753 Followers
neet - 1,736 Followers
dog girl - 1,733 Followers
Asian - 1,703 Followers
Gay🏳️‍🌈 - 1,688 Followers
Angel - 1,676 Followers
twins - 1,667 Followers
Threesome - 1,665 Followers
Dead Dove - 1,662 Followers
clingy - 1,653 Followers
Body modification - 1,646 Followers
Black - 1,641 Followers
Kitsune - 1,637 Followers
Curvy Figure - 1,617 Followers
Anthropomorphic Animals - 1,611 Followers
Flat Chest - 1,607 Followers
big tits - 1,606 Followers
Fluff - 1,601 Followers
Loving wife - 1,601 Followers
Mental illness - 1,599 Followers
kemonomimi - 1,596 Followers
Massive Breasts - 1,596 Followers
Married - 1,590 Followers
Wolfgirl - 1,570 Followers
Master-Servant - 1,570 Followers
Dog - 1,543 Followers
Cuddles - 1,541 Followers
Abuse Victim - 1,539 Followers
Sci-fi - 1,537 Followers
Bully Victim - 1,534 Followers
Dumb - 1,523 Followers
werewolf - 1,516 Followers
huge boobs - 1,513 Followers
True Love - 1,507 Followers
Gentle - 1,506 Followers
Goblin girl - 1,505 Followers
best friend - 1,490 Followers
Bunny Girl - 1,486 Followers
Genderswap - 1,476 Followers
woman - 1,473 Followers
Dragon Girl - 1,440 Followers
Scalie - 1,425 Followers
Fictional - 1,422 Followers
Demi-Human - 1,393 Followers
Supernatural - 1,381 Followers
big boobs - 1,380 Followers
Mafia - 1,367 Followers
tall - 1,353 Followers
nun - 1,348 Followers
Witch - 1,339 Followers
Aggressive - 1,336 Followers
Crazy - 1,321 Followers
bitch - 1,315 Followers
Latina - 1,305 Followers
Slowburn - 1,304 Followers
queen - 1,302 Followers
sweet - 1,298 Followers
Rich Girl - 1,287 Followers
Spanish - 1,255 Followers
Office lady - 1,251 Followers
Anthropomorphic - 1,250 Followers
Cyberpunk - 1,235 Followers
College Student - 1,234 Followers
Breast Expansion - 1,230 Followers
caring - 1,221 Followers
kind - 1,206 Followers
blonde - 1,202 Followers
Pets - 1,199 Followers
Voluptous - 1,199 Followers
Survival - 1,197 Followers
college - 1,190 Followers
Older Woman - 1,180 Followers
cute speech pattern - 1,179 Followers
Magical Girl - 1,170 Followers
can be wholesome - 1,158 Followers
short - 1,136 Followers
Insect - 1,130 Followers
Muscle - 1,129 Followers
Adorable - 1,117 Followers
Futapov - 1,114 Followers
loyal - 1,107 Followers
Psychological Horror - 1,105 Followers
Insane - 1,105 Followers
Alternate Universe - 1,089 Followers
Autistic - 1,088 Followers
Redhead - 1,085 Followers
Perverted - 1,082 Followers
zombie - 1,079 Followers
beautiful - 1,078 Followers
Cartoon character - 1,075 Followers
Lonely - 1,069 Followers
Modern day - 1,064 Followers
Public Sex - 1,062 Followers
Female Knight - 1,061 Followers
Celebrity - 1,060 Followers
idol - 1,053 Followers
Kuudere - 1,051 Followers
Police Officer - 1,040 Followers
emotionless - 1,025 Followers
Playful - 1,022 Followers
Criminal - 1,020 Followers
Breastfeeding - 1,018 Followers
Video Game - 1,017 Followers
Zombie Apocalypse - 1,015 Followers
Loving - 1,007 Followers
student-teacher - 1,007 Followers
Español - 1,007 Followers
Nudist - 1,005 Followers
Friendly - 1,003 Followers
Technology - 1,000 Followers

## Recognized Tags (500-1k Followers)

Drunk - 995 Followers
Tanned - 994 Followers
Rude - 976 Followers
Hag - 975 Followers
Dark Elf - 971 Followers
Soft Femdom - 965 Followers
Dark Romance - 957 Followers
wide hips - 938 Followers
Naive - 926 Followers
Soldier - 897 Followers
Slight Yandere - 891 Followers
Hate sex - 879 Followers
Chinese - 867 Followers
Cowgirl - 862 Followers
shrink - 854 Followers
somnophilia - 853 Followers
Fairy - 851 Followers
God - 846 Followers
Noble - 839 Followers
Daddy Kink - 838 Followers
smug - 832 Followers
Deepthroat - 829 Followers
chastity - 829 Followers
casual sex - 822 Followers
open world - 813 Followers
fox girl - 806 Followers
Mythology - 805 Followers
Orc - 802 Followers
Doll - 800 Followers
Disney - 795 Followers
Hyper - 792 Followers
Friends to Lovers - 789 Followers
Historical - 762 Followers
Eldritch - 759 Followers
delinquent - 755 Followers
Music - 754 Followers
Books - 754 Followers
Group - 745 Followers
oblivious - 740 Followers
Nature - 738 Followers
Space - 734 Followers
Savior - 734 Followers
Reverse NTR - 732 Followers
Pubic Hair - 731 Followers
stepmother - 728 Followers
netorase - 722 Followers
Politics - 720 Followers
Monster Boy - 712 Followers
Kidnapper - 712 Followers
doctor - 707 Followers
Horse - 706 Followers
Science - 695 Followers
Pony - 694 Followers
Slime - 690 Followers
Kobold - 690 Followers
Undeniably a coom bot - 690 Followers
Cuckquean - 689 Followers
sex toys - 677 Followers
Warrior - 676 Followers
Nymphomaniac - 676 Followers
Alien Girl - 672 Followers
Russian - 672 Followers
nurse - 667 Followers
Stupid - 666 Followers
Gothic - 662 Followers
black hair - 650 Followers
Parasite - 647 Followers
Assassin - 642 Followers
Masochist - 639 Followers
Mind Control - 633 Followers
Girl - 633 Followers
sad - 626 Followers
casual nudity - 624 Followers
goblin - 616 Followers
revenge - 611 Followers
Arranged Marriage - 609 Followers
cruel - 607 Followers
A cute girl who loves you - 605 Followers
armpits - 600 Followers
Neighbor - 598 Followers
possession - 589 Followers
War - 587 Followers
Father - 586 Followers
Girlfailure - 578 Followers
cat - 572 Followers
babysitter - 570 Followers
Needy - 567 Followers
Wolf - 565 Followers
Silly - 563 Followers
SPH - 558 Followers
Jealous - 555 Followers
obese - 551 Followers
Exhibitionist - 549 Followers
young adult - 539 Followers
sugar mommy - 536 Followers
Pet Play - 533 Followers
Sexually Frustrated - 526 Followers
Giant - 525 Followers
Philosophy - 523 Followers
Power bottom - 518 Followers
Thighs - 518 Followers
Interracial - 518 Followers
Kissing - 516 Followers
nerdy - 515 Followers
Latex - 515 Followers
Classmate - 513 Followers
oyakodon - 513 Followers
streamer - 512 Followers
Post-NTR - 511 Followers
Realistic - 500 Followers

## Niche Tags (Under 500 Followers)

These tags are not included in the main list but can be considered if they're highly relevant to the character. Check Chub.ai to verify they exist before use.

glasses - 496 Followers
Gamer - 492 Followers
Prison - 491 Followers
Alcoholic - 490 Followers
Interspecies - 485 Followers
shapeshifter - 474 Followers
Servant - 472 Followers
traumatized - 471 Followers
Blonde Hair - 468 Followers
sisters - 466 Followers
Centaur - 465 Followers
ebony - 465 Followers

---

## Confusing Tag Glossary

**NTR (Netorare)** - "Cuckold" scenario where someone's romantic partner is stolen/seduced by another person. The focus is on the pain/humiliation of being cheated on. Often controversial content.

**Netori** - Reverse perspective of NTR - YOU are the one stealing/seducing someone else's partner. You're the "home wrecker."

**Reverse NTR** - Your partner is obsessively devoted to you and won't be stolen, or scenarios where you prevent/reverse an NTR situation.

**Netorase** - Consensual sharing/swinging where a partner enjoys watching their significant other with others. No betrayal element.

**anti-NTR** - Explicitly NO cheating/NTR content. Used to signal safe, faithful relationships.

**Post-NTR** - Scenarios that take place after an NTR event has occurred, often dealing with aftermath/consequences.

**Dead Dove** - Warning tag meaning "Dead Dove: Do Not Eat" (from Arrested Development). Signals disturbing/dark content - "you were warned, don't complain." Used for extreme or taboo themes.

**Cuckolding** - Similar to NTR but more fetish-focused. Partner is aware and may be humiliated.

**Cuckquean** - Female version of cuckolding (woman whose partner is with others).

**SPH** - Small Penis Humiliation. Fetish content.

**Futapov** - Point of view as a futanari character (character with both male and female anatomy).

**WLW** - "Women Loving Women" - lesbian/sapphic relationships.

**oyakodon** - Japanese slang (literally "parent-child rice bowl") for sexual scenarios involving a parent and child together. Often mother-daughter scenarios in fiction.

**Sizeplay** - Content involving size differences (giants, shrinking, growth) in sexual/romantic contexts.

**BBW** - "Big Beautiful Woman" - plus-sized women.

**Gilf** - "Grandmother I'd Like to..." - elderly female characters in sexual contexts.

**gyaru** - Japanese fashion subculture - tanned skin, bleached hair, flashy makeup, confident personality.

**kemonomimi** - Japanese term for "animal ears" - characters with animal ears/tails but otherwise human.
