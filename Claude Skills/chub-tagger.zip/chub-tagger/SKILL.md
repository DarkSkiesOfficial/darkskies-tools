---
name: chub-tagger
description: Generate appropriate tags for SillyTavern/Chub.ai character cards. Use when the user requests tags for a character they're preparing to upload, says "I need tags for this character," or when finalizing character card uploads to Chub.ai.
---

# Chub Tagger

## Overview

This skill provides a curated database of Chub.ai tags with follower counts and generates optimal tag suggestions for SillyTavern character cards being uploaded to Chub.ai. It prioritizes high-follower tags for maximum discoverability while considering niche tags when highly relevant.

## When to Use This Skill

Use this skill when:
- User says "I need tags for this character" or similar
- User is preparing to upload a character to Chub.ai
- User asks for tag suggestions for a character card
- User mentions needing Chub tags or Chub.ai tags

## Tag Selection Process

### Step 1: Load the Tag Database

Read the complete tag list from `references/tags.md` before making suggestions. This file contains all curated tags organized by follower count.

### Step 2: Analyze the Character

When suggesting tags, consider these aspects of the character:

**Core Identity:**
- Species/race (Human, Furry, Monster Girl, Elf, Demon, etc.)
- Gender presentation (Female, if applicable)
- Character origin (OC, Original Character, Anime Character, Game Characters, etc.)
- Setting/genre (Fantasy, Sci-fi, Modern day, Medieval, Cyberpunk, etc.)

**Personality & Behavior:**
- Dominant/submissive dynamics
- Personality archetypes (Yandere, tsundere, Kuudere, etc.)
- Behavioral traits (shy, Flirty, Aggressive, Sadistic, etc.)
- Emotional states (Depressed, Lonely, clingy, etc.)

**Relationships & Roles:**
- Role types (teacher, Maid, student, girlfriend, Wife, etc.)
- Relationship dynamics (childhood friend, Enemies to Lovers, roommate, etc.)
- Social position (Royalty, Noble, Princess, etc.)

**Physical Attributes:**
- Body type/build (Chubby, Muscular, Petite, etc.)
- Height (Tall woman, tall, short, Giantess, etc.)
- Specific features when prominent in the character design

**Content Flags:**
- NSFW/SFW status (NSFW, SFW, "SFW <-> NSFW", "can be wholesome, can be sexy")
- POV support (Malepov, Fempov, anypov/Any POV)
- Content themes (Romance, Wholesome, Horror, Dark fantasy, etc.)
- Special kinks/themes when central to the character

**Scenario & Format:**
- Number of greetings (Multiple Greetings, Multiple Scenarios)
- Scenario type (Roleplay, Scenario, RPG, Adventure, etc.)
- Special mechanics (transformation, Hypnosis, Simulator, etc.)

### Step 3: Prioritize Tags

**Priority order:**
1. **High-priority tags (10k+ followers)** - Maximum discoverability
2. **Very popular tags (5k-10k followers)** - Strong discoverability
3. **Popular tags (3k-5k followers)** - Good discoverability
4. **Established tags (1k-3k followers)** - When highly relevant
5. **Recognized tags (500-1k followers)** - When specific and accurate
6. **Niche tags (<500 followers)** - Only when extremely relevant

Aim for **8-15 tags total**, weighted toward high-follower tags.

### Step 4: Verify Special Cases

**Mother tags - CRITICAL:**
Only use Mother, Mommy, Mom, Dommy Mommy, Muscle Mommy, or motherly when the character IS a mother (has children). Do NOT use these tags if the character is just maternal/nurturing or in a "mommy dom" dynamic without actually being a parent.

**Teenager tag:**
Only use for 18-19 year old characters (legal adults). Never for minors.

**POV tags:**
Always include at least one POV tag (Malepov, Fempov, anypov/Any POV) unless the character is genuinely POV-flexible, in which case use both anypov and Any POV for coverage.

**Duplicate tags:**
Include intentional duplicates for coverage (e.g., both "OC" and "Original Character", both "anypov" and "Any POV").

### Step 5: Format the Output

Present tags in a clean, copy-paste-ready format with clear separation between verified and inferred tags:

```
**Suggested Tags for [Character Name]:**

**Verified Tags (500+ followers):**
[Tag 1], [Tag 2], [Tag 3], [Tag 4], [Tag 5], [Tag 6], [Tag 7], [Tag 8]

**Inferred Tags (verify on Chub before adding):**
[Tag A], [Tag B], [Tag C]
```

If franchise tags are relevant (e.g., Pokemon, Disney, specific game/anime titles), include them in the inferred section even if not in the curated list.

Follow the suggestion with:
1. Brief explanation of why major tags were chosen
2. Notes on any confusing slang terms used (reference the glossary in tags.md)
3. Reminder to verify inferred tags exist on Chub.ai before adding

### Step 6: Consider Inferred Tags

After selecting from the curated list, consider sub-500 follower tags for specific traits not covered:

**Common inferred tag patterns:**
- Physical traits: airhead, scars, piercings, tattoos, freckles, etc.
- Character archetypes: amazon, himbo, tomgirl, etc.
- Specific settings: cult, mafia, yakuza, underground, etc.
- Personality specifics: smart, intelligent, bookworm, athletic, etc.
- Franchise/IP tags: specific game titles, anime series, etc.

**Guidelines for inferred tags:**
- Use lowercase unless it's a proper noun/franchise name
- Keep it simple (1-2 words max)
- Base naming on patterns seen in the curated list
- Only suggest when highly relevant and specific
- Always mark as [verify] in output

## Tag Database Reference

The complete curated tag list is stored in `references/tags.md`, organized by follower count:
- High Priority Tags (10k+ followers)
- Very Popular Tags (5k-10k followers)
- Popular Tags (3k-5k followers)
- Well-Known Tags (2k-3k followers)
- Established Tags (1k-2k followers)
- Recognized Tags (500-1k followers)
- Niche Tags (<500 followers)
- Confusing Tag Glossary (definitions for slang terms like NTR, Dead Dove, etc.)

Always read this file before making tag suggestions to ensure accuracy and proper spelling/capitalization. Reference the glossary when suggesting or explaining confusing slang terms.

## Examples

**Example 1: High Fantasy Knight Character**

Character: Female knight, loyal protector, can be romantic or platonic, multiple greetings

**Verified Tags (500+ followers):**
Female, Fantasy, Female Knight, Warrior, Romance, Roleplay, OC, Original Character, loyal, anypov, Any POV, Multiple Greetings, Medieval

**Inferred Tags (verify on Chub):**
armor, swordfighter

---

**Example 2: Modern Yandere Girlfriend**

Character: Obsessive girlfriend, stalker tendencies, NSFW possible, dominant

**Verified Tags (500+ followers):**
Female, Yandere, girlfriend, Obsessive, stalker, Dominant, Romance, NSFW, Modern day, Possessive, Malepov, OC, Original Character

**Inferred Tags (verify on Chub):**
None needed - well covered by verified tags

*Note: "Yandere" means obsessively possessive to the point of violence/extreme behavior.*

---

**Example 3: Furry Catgirl Cafe Worker**

Character: Shy catgirl working at a cafe, wholesome with NSFW potential, anthro design

**Verified Tags (500+ followers):**
Female, Furry, catgirl, Cat Girl, Anthro, shy, Cute, Wholesome, SFW <-> NSFW, Roleplay, anypov, Any POV, OC, Original Character

**Inferred Tags (verify on Chub):**
cafe, barista

---

**Example 4: Pokemon Gardevoir Character**

Character: Gardevoir from Pokemon, psychic abilities, elegant and protective

**Verified Tags (500+ followers):**
Female, Pokemon, Non-Human, Game Characters, Psychic (if exists), Elegant (if exists), anypov, Any POV

**Inferred Tags (verify on Chub):**
Gardevoir, psychic-type, protective

*Note: Franchise-specific tags like "Gardevoir" should be verified on Chub as they may have dedicated followings.*
