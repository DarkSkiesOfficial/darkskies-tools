---
name: wyvern-tagger
description: Generate appropriate tags for SillyTavern/Wyvern character cards. Use when the user requests tags for a character being uploaded to Wyvern, mentions "Wyvern tags," or is cross-posting a card to Wyvern. Unlike Chub's organic tag system, Wyvern uses a fixed taxonomy with a hard cap of 25 tags.
---

# Wyvern Tagger

## Overview

This skill generates tag suggestions for character cards being uploaded to Wyvern. Wyvern uses a **fixed taxonomy** of predefined tags organized into categories, with a **hard limit of 25 tags per card**.

This is fundamentally different from Chub.ai's organic, follower-driven tag system. On Wyvern, you're selecting from a curated list, not inventing tags or chasing follower counts.

---

## ⛔ CRITICAL: Tags MUST Come From the Database

**You may ONLY suggest tags that exist in `wyvern-tags.md`.**

This is not flexible. Wyvern's tag system is rigidly controlled—creators cannot make their own tags. If a tag isn't in the database file, it doesn't exist on the platform and cannot be used.

**Before suggesting ANY tag:**
1. Verify it exists exactly as written in `wyvern-tags.md`
2. If you think "this would fit" but it's not in the list—**you cannot use it**
3. Do not improvise, approximate, or suggest "similar" tags that don't exist

The database includes descriptions for each tag to help you understand when they apply. Use those descriptions to make accurate selections.

---

## MANDATORY FIRST STEP: Content Rating Assessment

**Before suggesting ANY tags, you MUST determine the content rating.** Wyvern uses three rating tiers. Getting this wrong can result in card removal.

### ⚠️ CRITICAL: Read the ENTIRE Card First

**You MUST read the ENTIRE card before assessing content rating.** This means:

- `first_mes` (the main greeting)
- ALL entries in `alternate_greetings`
- `description` and `personality` fields
- Any `scenario` or `system_prompt` content
- Example dialogues in `mes_example`

**The highest content level found in ANY part of the card determines the rating.**

A card with five wholesome café greetings and one bedroom scene is an **EXPLICIT** card. Not "mostly NONE with one exception"—EXPLICIT, full stop.

**Common failure mode:** Reading only the first greeting and assuming it's representative. Many cards escalate intentionally—the creator notes or greeting labels may even say "Greet 5 (NSFW)" and you'll miss it if you only skim the opening.

**Do not trust your assumptions. Do not sample. Read everything.**

---

### Wyvern's Official Content Ratings

These definitions are directly from Wyvern's moderation wiki:

#### NONE (SFW)
No worse than shows, games, and movies rated 16+. This allows for:
- Light-to-moderate mature themes
- Violence, death, depression, war
- SFW romance and flirty themes

**Key point:** "None" doesn't mean "no mature themes"—it means no *extreme* themes and nothing sexual.

#### MATURE (NSFW without sexual content)
Content that contains extreme themes too much for None, but doesn't feature anything sexual, lewd, or explicit. This includes:
- Heavy violence and gore
- Extreme mental health issues and depression
- Suicide
- Discrimination

**Special case:** Themes like prostitution and brothels can be Mature-rated, but ONLY if the portrayal itself isn't sexual in nature.

#### EXPLICIT (NSFW with sexual content)
Anything sexual, whether it's a full-on sexbot or an otherwise SFW character that describes sexual behavior. This includes:
- Full sexual content
- Describing intimate body parts (breasts, butts, hips, feet, etc.)
- Sexual scenarios or behavior descriptions
- Lewd or suggestive content

**Key point:** You don't need graphic sex scenes to hit Explicit. Describing a character's breasts or having a "turn-ons" section with physical details = Explicit.

---

### Content Rating Flowchart

Run through this decision tree IN ORDER. Stop at the first "YES."

```
┌─────────────────────────────────────────────────────────────────┐
│ STEP 1: Does this card depict a minor in a romantic or sexual  │
│         context?                                                │
├─────────────────────────────────────────────────────────────────┤
│ YES → ⛔ PROHIBITED - Cannot be uploaded to Wyvern              │
│ NO  → Continue to Step 2                                        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 2: Does this card contain ANY of the following?           │
│         • Bestiality                                            │
│         • Necrophilia                                           │
│         • Scat                                                  │
│         • Vomit (sexual context)                                │
│         • Guro (erotic gore)                                    │
│         • Hate speech                                           │
│         • Real-world individuals                                │
│         • Stolen content                                        │
├─────────────────────────────────────────────────────────────────┤
│ YES → ⛔ PROHIBITED - Review Wyvern's Content Policy            │
│ NO  → Continue to Step 3                                        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 3: Does this card contain ANY sexual content, lewd        │
│         content, OR descriptions of intimate body parts        │
│         (breasts, butts, hips, feet, etc.)?                    │
├─────────────────────────────────────────────────────────────────┤
│ YES → 🔞 EXPLICIT                                               │
│ NO  → Continue to Step 4                                        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 4: Does this card contain ANY of the following?           │
│         • Heavy violence or gore                                │
│         • Extreme mental health issues                          │
│         • Suicide                                               │
│         • Discrimination                                        │
│         • Non-sexual prostitution/brothel themes                │
├─────────────────────────────────────────────────────────────────┤
│ YES → ⚠️ MATURE                                                 │
│ NO  → ✅ NONE                                                   │
└─────────────────────────────────────────────────────────────────┘
```

### Output Format for Rating

Always present the rating FIRST, before tags:

```
## Content Rating: [NONE / MATURE / EXPLICIT]

**Rating Rationale:**
- [Specific element that triggered this rating]
- [Location in card where this was found, if relevant]
- [Any borderline considerations]
```

If the card is PROHIBITED, stop there and explain why. Do not proceed to tagging.

---

## Required Tags

Wyvern requires specific tags when certain content is present. These are **mandatory**, not suggestions:

| Content | Required Tag | Notes |
|---------|--------------|-------|
| Sexbot / explicit scenarios / smutty greetings | **Shameless Smut** | For explicit sexual writing. Not strictly necessary if an otherwise-SFW bot just has a couple sexual details or one alt greeting that skips to spicy content. |
| Nudity or lewd/explicit images | **Erotic Image** | For images specifically, not writing. Some characters need both this AND Shameless Smut. |
| Anthropomorphic animals | **Anthro** | Animals with human characteristics |
| Furry characters | **Furry** | Humanlike animals. Use your best judgment between Anthro and Furry. |
| Dubious consent scenarios | **Consensual Non-Consent** | Any characters where consent is dubious |
| NTR, Feet, Vore, Incest, or other divisive kinks | **The specific tag** | These have strong reactions—many users filter FOR them, many BLOCK them. Tag when mentioned in character or plot. |

---

## Core Philosophy: Signal Over Completeness

With only 25 slots, every tag must earn its place. The goal isn't to describe everything about the character—it's to help users **find** your card when searching for specific content.

**Ask for each potential tag:** "Would someone actively filter by this?"

### Tags That Usually AREN'T Worth a Slot

- **Human** — Unless non-human species are relevant, most characters are assumed human
- **English** — Default assumption; only tag NonEnglish if the card is in another language
- **Straight** — Default assumption for most romance cards; tag sexualities that deviate
- **Modern** — Only worth tagging if the modern setting is distinctive (vs. "just not historical")
- **Female/Male** — Only if gender is a key discovery vector or the character's identity is thematically important
- **Prose** — Default format assumption; save the slot

### Tags That ARE Worth Slots

- **Non-human species** — Lamia, Kitsune, Vampire, etc. (people actively filter for these)
- **Specific archetypes** — Yandere, Tsundere, Himbo, Femme Fatale (these have dedicated audiences)
- **Distinctive genres** — Cyberpunk, Post-Apocalyptic, Isekai (setting-seekers filter by these)
- **Content warnings** — Mature category tags help users find OR avoid specific content
- **Kinks** — Explicit category tags are highly filterable for NSFW seekers
- **Format** — AliChat, JED, PList/SBF are worth tagging (distinctive styles)
- **POV tags** — AnyPOV, FemPOV, MalePOV are primary user filters

---

## Category Breakdown

Wyvern organizes tags into **10 categories**. All available tags are listed in `wyvern-tags.md`. Here's how to approach each category:

### 1. FORMAT (Pick 1 if distinctive)

| Tag | When to Use |
|-----|-------------|
| **Prose** | Default novel-style formatting—often skippable |
| **AliChat** | Example dialogue-driven cards—WORTH tagging, distinctive style |
| **PList/SBF** | Structured data cards—WORTH tagging, niche audience |
| **RAW** | Script/screenplay rips—WORTH tagging, very specific |
| **Plaintext** | Minimal formatting—only if notably sparse |
| **JED** | JED format specifically—WORTH tagging if used |

**Recommendation:** Only tag format if it's AliChat, PList, RAW, or JED. Prose is assumed.

### 2. PERSPECTIVE (Pick 1-2)

| Tag | When to Use |
|-----|-------------|
| **First Person** | Character has active internal voice |
| **Second Person** | "You do X" narration style |
| **Third Person** | Observer narration |
| **AnyPOV** | Card works regardless of user gender—VALUABLE tag |
| **FemPOV** | Written specifically for female users |
| **MalePOV** | Written specifically for male users |

**Recommendation:** POV tags (AnyPOV/FemPOV/MalePOV) are almost always worth including—they're primary filters for users.

### 3. IDENTITY (Pick 1-3 as relevant)

This covers the character's gender, sexuality, and presentation.

**Gender tags worth including:**
- Non-binary, Trans, Genderfluid — If applicable (distinctive)
- Group — If multiple characters
- Template — If it's a template card

**Sexuality tags worth including:**
- Gay, Bisexual — If relevant to the character/scenarios
- Straight — Usually skip (assumed default)

**Presentation tags worth including:**
- Tomboy, Femboy — These have dedicated audiences, always tag if applicable

### 4. GENERAL (Your main tag budget — Pick 5-10)

This massive category covers source, genre, setting, themes, and more. This is where most of your distinctiveness lives.

**Source Material (pick if applicable):**
- 🎌 Anime, Cartoon, Comic Book, 🎥 Movie, 📺 TV Show, 📖 Book, 🎮 Video Game
- 💡 Original — Worth tagging for OC cards

**Genre (pick 1-3 that DEFINE the card):**
- 🧝 Fantasy, 🚀 Sci-Fi, 👹 Horror, ❤️ Romance, 💥 Action, 😂 Comedy, 🎭 Drama
- Slice of Life, 👻 Supernatural, 🕵️ Mystery, 🔪 Thriller, 🏞️ Adventure
- Isekai, RPG — Distinctive enough to always tag if applicable

**Setting (pick if distinctive):**
- 🖥 Modern — Usually skip unless distinctively modern
- 🏰 Historical, ⚜ Medieval, Futuristic, Cyberpunk, Steampunk — Worth tagging
- Post-Apocalyptic, Dystopian — Worth tagging
- Office, Beach, Forest, City — Only if setting is central

**Themes/Tone:**
- 🌠 Wish Fulfillment, 🎀 Fluff, 💔 Angst — Worth tagging, sets expectations
- 🌍 Realistic, Psychological — If defining characteristics
- Slow-Burn — Has dedicated audience, always tag if applicable

**Special Categories:**
- 🙈 Furry, 👺 Monster — Always tag if applicable
- Multiple Characters — Worth tagging
- Narrator, Utility — For non-standard cards

**Holiday tags** — Only if the card is specifically themed (🎃 Halloween, 🎄 Christmas, etc.)

### 5. OCCUPATION (Pick 1-2 if central)

Only tag occupations that are **central to the character concept**. A character who happens to have a job doesn't need the occupation tagged—but a "hot professor" card absolutely needs "Professor."

**High-value occupation tags:**
- Student, Teacher/Professor — Very common searches
- Maid/Butler — Dedicated audience
- Royalty, Criminal, Assassin — If central to concept
- VTuber, Streamer — Niche but dedicated audience
- Superhero, Supervillain — Genre-defining

### 6. SPECIES (Pick 1-2 if non-human)

**Skip "Human"** — it's assumed.

If the character is non-human, this is HIGH PRIORITY tagging. Species tags are major filters.

**Always tag if applicable:**
- Elf, Vampire, Werewolf, Demon, Angel, Succubus
- Dragon, Mermaid, Neko, Kitsune
- Furry-adjacent: Anthro, Demihuman
- Monster types: Lamia, Arachne, Centaur, Goblin, Orc
- Sci-fi: Alien, Machine, Mutant
- Divine: God, Demi-God, Cosmic Entity

### 7. ARCHETYPE (Pick 1-3 if clear fit)

These are personality/trope tags with **dedicated audiences**. If your character fits cleanly, TAG IT.

**High-value archetypes:**
- 🔪 Yandere, 😡 Tsundere, ❄️ Kuudere, 🤐 Dandere — The "dere" types have huge audiences
- Himbo — This tag has a cult following
- Femme Fatale, Manic Pixie Dream Girl — Classic tropes
- Anti-Hero, Tragic Villain, Fallen Hero — For morally complex characters
- Mentally Ill, Cursed, Broken Bird — For darker character concepts
- Enemy to Lover, Forbidden Love, Soulmate — Relationship dynamics

### 8. MATURE (Pick as needed for content warnings)

These function as **content warnings**. Use them when the content applies.

**Tag if present:**
- Graphic Violence, Mental Illness, Substances, War
- Abuse, Slavery, Discrimination — With note that real-life depictions must not glorify
- Murder Hobo — For chaotic violent characters
- Loss — For grief/trauma themes

### 9. EXPLICIT (Pick as needed for NSFW content)

For NSFW cards, these are **highly filterable**. Users actively search by kink.

**Remember:** Some tags are REQUIRED when the content applies (see Required Tags section above).

**Common high-value explicit tags:**
- Shameless Smut — General "this is horny" signal
- MILF, DILF, GILF — If applicable
- Harem, Reverse Harem — If applicable
- Bondage, Domination, Submission — BDSM spectrum
- Breeding — Very popular kink tag
- Specific kinks as applicable

**Note:** Don't over-tag kinks. Focus on the 2-4 that are CENTRAL to the character/scenarios.

### 10. MISCELLANEOUS (Pick 2-5 for personality color)

These are personality/vibe tags. Use them to round out the character.

**High-value personality tags:**
- Shy, Confident, Energetic, Nerdy, Goth — Core personality vibes
- NEET — Has dedicated audience
- Motherly, Fatherly, Sisterly, Brotherly — For those dynamics
- Doormat, Alpha, Omega — Power dynamic tags
- Rich, Poor — If class is relevant
- Older, Younger — If age dynamic is relevant

---

## The 25-Tag Budget System

Think of your 25 tags as a budget. Here's a suggested allocation:

| Category | Suggested Slots | Notes |
|----------|-----------------|-------|
| Perspective | 1-2 | Almost always include POV tag |
| Format | 0-1 | Only if distinctive (AliChat, JED, etc.) |
| Identity | 1-2 | Gender presentation, sexuality if relevant |
| General | 6-10 | Your main distinctiveness budget |
| Occupation | 0-2 | Only if central to concept |
| Species | 0-2 | Skip if human |
| Archetype | 1-3 | If clear trope fits exist |
| Mature | 0-3 | As content requires |
| Explicit | 0-5 | For NSFW, focus on central kinks |
| Miscellaneous | 2-4 | Personality rounding |

**Total target: 15-22 tags**

Leave a few slots empty rather than padding with low-value tags. Every tag should be something a user might actively filter by.

---

## Tag Selection Process

### Step 1: Load Reference

Read `wyvern-tags.md` for the complete tag list. **Only tags in this file can be used.**

### Step 2: Identify Non-Negotiables

What tags does this character REQUIRE?
- POV tag (almost always)
- Species (if non-human)
- Core genre (1-2 that define it)
- Required tags from the Required Tags section
- Content level indicators

### Step 3: Find Distinctive Features

What makes this character findable?
- Archetypes that fit
- Occupation if central
- Setting if distinctive
- Relationship dynamic if applicable

### Step 4: Add Personality Color

What vibes/personality tags round this out?
- 2-4 miscellaneous personality tags
- Themes/tone tags from General

### Step 5: Content Tags (if applicable)

For mature/explicit content:
- Mature category warnings as needed
- 2-4 central kinks/explicit tags, not everything possible

### Step 6: Verify and Count

1. **Verify every tag exists in `wyvern-tags.md`** — If it's not there, you cannot use it
2. Count your tags
3. If over 25, cut the least distinctive ones
4. If under 20, consider if you're missing anything important

---

## Output Format

Present the content rating FIRST, then tags grouped by category:

```
## Content Rating: [NONE / MATURE / EXPLICIT]

**Rating Rationale:**
- [Key element(s) that determined this rating]
- [Location in card if relevant]
- [Any borderline considerations noted]

---

**Wyvern Tags for [Character Name]:** (X/25)

**Perspective:** [tags]
**Identity:** [tags]  
**General:** [tags]
**Species:** [tags]
**Archetype:** [tags]
**Occupation:** [tags]
**Mature:** [tags]
**Explicit:** [tags]
**Miscellaneous:** [tags]

**Tag Count:** X/25
```

Follow with:
1. Brief explanation of key tag choices
2. Note any close-call decisions (tags that could be swapped)
3. Any tags that were deliberately omitted and why

---

## Examples

### Example 1: NSFW-Forward Succubus

Character: Succubus coworker, office setting, dominant, explicit content focus

**Content Rating: EXPLICIT**

**Rating Rationale:**
- Succubus inherently implies sexual content
- Card is explicitly designed for NSFW scenarios
- Contains sexual content descriptions and kink elements

---

**Wyvern Tags for [Name]:** (21/25)

**Perspective:** AnyPOV
**Identity:** Female, Bisexual
**General:** 💡 Original, 🧝 Fantasy, ❤️ Romance, 😂 Comedy, 🌠 Wish Fulfillment, Office
**Species:** Succubus, Demon
**Archetype:** Femme Fatale
**Occupation:** White Collar
**Explicit:** Shameless Smut, Domination, Breeding, Free Use
**Miscellaneous:** Confident, Energetic

**Tag Count:** 21/25

*Key choices: Heavy explicit budget for NSFW-forward card. "Shameless Smut" required for sexbot-adjacent content. "Office" setting tag is worth it since it's central to the scenario. "White Collar" occupation suggests professional environment.*

---

### Example 2: Slice-of-Life College Student (Clean)

Character: Volleyball player, golden retriever energy, wholesome romance, no explicit content

**Content Rating: NONE**

**Rating Rationale:**
- No sexual content or anatomical descriptions anywhere in card
- No heavy violence, gore, or dark themes
- Romance is wholesome/fluffy
- Character has insecurities but no mental health crisis depiction
- Turn-ons are emotional (loyalty, playfulness) not physical

---

**Wyvern Tags for [Name]:** (17/25)

**Perspective:** AnyPOV
**Identity:** Female
**General:** 💡 Original, ❤️ Romance, 😂 Comedy, Slice of Life, 🎀 Fluff, Sports ⚽
**Occupation:** Athlete, Student
**Archetype:** 💖 Deredere, Wandere, Underdog
**Miscellaneous:** Energetic, Shy, 🏡 Neighborly

**Tag Count:** 17/25

*Key choices: "Sports" and "Athlete" are must-haves. "Wandere" = golden retriever energy. "Deredere" = sweet and positive. Clean card with no Mature or Explicit tags needed.*

---

## Common Mistakes to Avoid

1. **Using tags that don't exist** — ONLY use tags from `wyvern-tags.md`. No improvisation.
2. **Tagging "Human"** — Wastes a slot on the default assumption
3. **Over-tagging kinks** — Focus on 2-4 central ones, not everything possible
4. **Tagging format "Prose"** — It's assumed, save the slot
5. **Multiple similar genre tags** — Pick the 2-3 most defining, not all adjacent ones
6. **Tagging obvious setting** — "Modern" usually isn't distinctive enough
7. **Forgetting POV tags** — These are primary user filters
8. **Under-tagging species** — Non-human species are high-value discovery tags
9. **Only reading the first greeting** — ALWAYS check ALL greetings. A single NSFW greeting makes the whole card EXPLICIT.
10. **Rating body descriptions as NONE** — Describing breasts, butts, hips, feet = EXPLICIT per Wyvern guidelines

---

## The Most Important Rules

1. **Tags MUST exist in `wyvern-tags.md`.** No exceptions, no improvisation.

2. **Content rating is determined by the MOST explicit content anywhere in the card.** It doesn't matter if 90% of the card is fluffy slice-of-life. If greeting 5 describes her curves, that card is EXPLICIT. Period.

3. **Body part descriptions = EXPLICIT.** Per Wyvern's guidelines, describing intimate body parts (breasts, butts, hips, feet) makes the card Explicit even without sexual scenarios.

Read. Everything. Verify tags. Then output.
