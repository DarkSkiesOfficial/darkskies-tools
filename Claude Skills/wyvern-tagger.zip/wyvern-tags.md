# Wyvern Tags Reference

Complete tag list for Wyvern character uploads, organized by category.

---

## FORMAT

| Tag | Description |
|-----|-------------|
| Prose | Novel-style formatting (default, often skippable) |
| AliChat | Example dialogue-driven cards |
| PList/SBF | Structured data, minimal dialogue/prose |
| RAW | Straight rip from source material (script/screenplay) |
| Plaintext | Minimal formatting |
| JED | JED format specifically |

---

## PERSPECTIVE

| Tag | Description |
|-----|-------------|
| First Person | Character speaks with active internal voice |
| Second Person | "You do X" narration style |
| Third Person | Observer narration |
| AnyPOV | {{user}} can self-insert regardless of gender |
| FemPOV | Written for female-identifying {{user}} |
| MalePOV | Written for male-identifying {{user}} |

---

## IDENTITY

### Gender
| Tag | Description |
|-----|-------------|
| Male | Character identifies as male |
| Female | Character identifies as female |
| Non-Binary | Character identifies as non-binary |
| 🏳️‍⚧️ Trans | Character's gender differs from assigned birth sex |
| Genderfluid | Character identifies as genderfluid |
| No Identity | Character with no gender identity |
| Group | Card includes multiple characters of different genders |
| Template | Card designed as template for other cards |

### Sexuality
| Tag | Description |
|-----|-------------|
| Gay | Character identifies as homosexual |
| Bisexual | Character identifies as bisexual |
| Straight | Character identifies as heterosexual (often skippable—assumed default) |

### Presentation
| Tag | Description |
|-----|-------------|
| Tomboy | Woman who engages in culturally male activities |
| Femboy | Usually cis male expressing traditionally feminine behaviors |

---

## GENERAL

### Source Material
| Tag | Description |
|-----|-------------|
| 🎌 Anime | From anime or manga |
| Cartoon | From animated TV/movie |
| Comic Book | From comic book series |
| 🎥 Movie | From live-action film |
| 📺 TV Show | From live-action TV |
| 📖 Book | From novel or short story |
| 🎮 Video Game | From video game |
| 💡 Original | Created by the author (OC) |

### Genre
| Tag | Description |
|-----|-------------|
| 🧝 Fantasy | Magic, mythical creatures, otherworldly settings |
| 🚀 Sci-Fi | Advanced technology, space, futuristic |
| 🖥 Modern | Contemporary (often skippable unless distinctive) |
| 🏰 Historical | Specific time periods, cultures, events |
| 👹 Horror | Supernatural, suspense, gore |
| ❤️ Romance | Love, relationships, dating |
| 💥 Action | Fighting, adventure, excitement |
| 😂 Comedy | Humor, jokes, satire |
| 🎭 Drama | Conflict, emotion, tension |
| Slice of Life | Everyday events, relationships, experiences |
| 👻 Supernatural | Magic, ghosts, otherworldly beings |
| 🕵️ Mystery | Puzzles, clues, suspense |
| 🔪 Thriller | Suspense, danger, excitement |
| 🏞️ Adventure | Exploration, quests, challenges |
| Isekai | {{user}} transported to another world |
| RPG | Story with role-playing game elements (stats, leveling) |
| 🗣️ Chatter | More like texting than traditional RP |
| 🌍 Realistic | Everyday life, grounded |
| 🌠 Wish Fulfillment | Fulfilling desires, dreams, fantasies |
| 🎀 Fluff | Sweetness, cuteness, light-heartedness |
| 💔 Angst | Sadness, pain, tragedy, emotional turmoil |
| 🙈 Furry | Anthropomorphic animals |
| 👺 Monster | Mythical creatures, beasts, supernatural beings |
| Religious | Deities, faith, spiritual beliefs |
| Political | Government, power, social issues |
| Philosophical | Deep thoughts, ideas, concepts |
| 🏫 Educational | Learning, knowledge, information |
| 🧪 Experimental | New ideas, techniques, approaches |
| 🤝 Collab | Created in collaboration |
| Multiple Characters | Card features more than one character |
| Psychological | Mind-bending, reality-questioning |
| Utility | Card for non-roleplay use |
| Mythology | Myths and stories from cultures/religions |
| Narrator | Card acts as story narrator |
| Slow-Burn | Slower-paced romance, deep emotional connection |

### Settings
| Tag | Description |
|-----|-------------|
| Steampunk | Victorian-era tech, airships, clockwork |
| Cyberpunk | Futuristic tech, hackers, dystopia |
| 🖤 Gothic | Dark romance, horror, Victorian aesthetics |
| ⚜ Medieval | Knights, castles, dragons |
| Futuristic | Advanced tech, space, cybernetics |
| Post-Apocalyptic | After catastrophic event |
| Dystopian | Unjust society, prevalent suffering |
| Office | Work, business, corporate |
| Beach | Sand, sun, surf |
| Forest | Trees, animals, nature |
| City | Buildings, streets, urban |
| Concert | Music, bands, performances |
| Restaurant | Food, dining, cooking |
| Sports ⚽ | Competition, athleticism |

### Seasons/Holidays
| Tag | Description |
|-----|-------------|
| 🎃 Halloween | Pumpkins, ghosts, costumes |
| 🎄 Christmas | Santa, presents, snow |
| 💘 Valentine | Hearts, flowers, romance |
| 🕎 Hanukkah | Menorahs, dreidels, latkes |
| 🐰 Easter | Bunnies, eggs, chocolate |
| 🌙 Ramadan | Mosques, lanterns, dates |
| 🏳️‍🌈 Pride | Rainbows, LGBTQ+ pride |
| 🏴‍☠️ Pirate | Ships, treasure, swashbuckling |
| 🍂 Fall | Leaves, pumpkins, harvest |
| ❄️ Winter | Snow, ice, holidays |
| 🌸 Spring | Flowers, rain, rebirth |
| ☀️ Summer | Sun, beach, vacation |

---

## OCCUPATION

| Tag | Description |
|-----|-------------|
| Unemployed | No job |
| Student | Studying at school/college |
| Superhero | Heroic powers/abilities |
| Criminal | Breaks the law |
| Crime Boss | Controls criminal organizations |
| Royalty | Royal family member |
| Artist | Creates art |
| Musician | Plays instruments/sings |
| Writer | Writes books/stories/articles |
| Actor | Performs in plays/movies/TV |
| Athlete | Participates in sports |
| Scientist | Studies natural world |
| Doctor | Treats patients |
| Nurse | Cares for patients |
| Teacher | Educates students |
| Engineer | Designs machines/structures |
| Programmer | Writes code |
| Chef | Cooks in restaurant/kitchen |
| Baker | Bakes bread/cakes/pastries |
| Barista | Makes/serves coffee |
| Waiter/Waitress | Serves food/drinks |
| Bartender | Mixes/serves drinks at bar |
| Police Officer | Law enforcement |
| Firefighter | Extinguishes fires, rescues |
| Military | Armed forces |
| Pilot | Flies planes/helicopters |
| Flight Attendant | Assists passengers on flights |
| Astronaut | Space explorer |
| Explorer | Travels to unknown lands |
| Adventurer | Seeks danger/excitement |
| Detective | Solves crimes/mysteries |
| Spy | Gathers intelligence covertly |
| Thief | Steals |
| Assassin | Contract killer |
| Massuese (Massage Therapist) | Gives massages |
| Professor | University/college educator |
| Librarian | Works in library |
| Politician | Public official |
| Lawyer | Legal representative |
| Judge | Presides over legal proceedings |
| CEO | Chief executive |
| Therapist | Mental health professional |
| Psychic | Claims supernatural abilities |
| Ghost Hunter | Paranormal investigator |
| Occultist | Practices magic/mysticism |
| Monster Hunter | Slays supernatural creatures |
| Mechanic | Repairs machinery |
| Plumber | Fixes pipes/drains |
| Prison Guard | Supervises inmates |
| Prisoner | Incarcerated |
| Test Subject | Participates in experiments |
| Con Artist | Deceives for personal gain |
| Bounty Hunter | Captures fugitives for reward |
| Stylist | Cuts/styles hair |
| 🎤 VTuber | Virtual YouTuber |
| Streamer | Broadcasts live video |
| Influencer | Promotes on social media |
| Cosplayer | Dresses as fictional characters |
| Mercenary | Hired combatant |
| Nun/Priest | Religious order member |
| Supervillain | Evil, often with powers |
| Maid/Butler | Domestic servant |
| Shopkeeper | Maintains a shop |
| Craftsman | Skilled in a trade |
| Magician | Wields magic |
| Blue Collar | Manual labor job |
| White Collar | Office/professional job |
| Bodyguard | Guards important individuals |

---

## SPECIES

| Tag | Description |
|-----|-------------|
| Human | Regular human (often skippable—assumed) |
| Superhuman | Human with superpowers |
| Elf | Pointy-eared, long-lived, magical |
| Lamia | Snake body, human upper body |
| Demihuman | Mix of human and non-human traits |
| Dwarf | Short, stocky, crafting-focused |
| Halfling | Small, nimble (hobbit-like) |
| Orc | Brutish, aggressive, strong |
| Goblin | Small, sneaky, mischievous |
| Troll | Large, regenerating, often brutish |
| Arachne | Human upper body, spider lower body |
| Kobold | Small, reptilian, often dragon-adjacent |
| Naga | Serpent-like, often magical |
| Centaur | Human upper body, horse lower body |
| Minotaur | Bull head, human body |
| Fairy | Small, winged, magical |
| Tiefling | Humanoid with demonic heritage |
| Fae | Magical nature creature |
| Giants | Large, powerful |
| Object | Non-living items |
| Gnome | Small, earthy, crafty |
| Vampire | Blood-drinking, immortal |
| Werewolf | Shapeshifts to wolf form |
| Undead | Died but remains animate |
| Succubus (Incubus) | Seductive demon |
| Demon | Malevolent supernatural being |
| Angel | Celestial being |
| Dragon | Large, often fire-breathing reptile |
| Mermaid | Half-human, half-fish |
| Neko | Cat-like humanoid |
| Kitsune | Fox-like humanoid, shapeshifting |
| Mutant | Genetic mutations/superhuman abilities |
| Alien | From another planet/dimension |
| God | Divine being |
| Anthro | Anthropomorphic animal (general) |
| Machine | Mechanical/robotic |
| Plant | Made of or resembling plant life |
| Cosmic Entity | Powerful eldritch being |
| Abyssal Horror | Terrifying void creature |
| Spirit | Being between worlds |
| Shifter | Can transform form/appearance |
| Compartment Creature | Collectible creatures (Pokemon-style) |
| Reptilian | Scaled humanoid |
| Demi-God | Divine-mortal offspring |
| Wendigo | Horned forest spirit, cannibalistic |

---

## ARCHETYPE

| Tag | Description |
|-----|-------------|
| Anti-Hero | Morally ambiguous protagonist |
| 🦸 Protagonist | Main hero |
| 😈 Antagonist | Main villain |
| Trickster Mentor | Wise but mischievous guide |
| Reluctant Hero | Thrust into heroism unwillingly |
| Broken Bird | Traumatic past, struggles to connect |
| Gentle Giant | Imposing but kind |
| Chaotic Neutral | Unpredictable, follows own moral compass |
| Mastermind | Highly intelligent strategist |
| Eternal Optimist | Positive despite adversity |
| Well-Intentioned Extremist | Harmful actions for "greater good" |
| Lovable Rogue | Charming rule-bender |
| Reluctant Companion | Joins out of obligation |
| Mentally Ill | Struggles with mental health |
| Cursed | Afflicted by supernatural curse |
| Tragic Villain | Actions driven by past trauma |
| Uncaring Villain | Indifferent to suffering |
| Master of Manipulation | Excels at deceiving/controlling |
| Bumbling Buffoon | Clumsy, foolish |
| Noble Savage | Embodies purity of nature |
| Femme Fatale | Seductive and dangerous |
| Manic Pixie Dream Girl | Quirky, exists to inspire protagonist |
| Knight in Sour Armor | Cynical but still fights for justice |
| Byronic Hero | Complex, brooding, dark past |
| Person Next Door | Relatable, ordinary |
| Chosen One | Destined for greatness |
| 🔪 Yandere | Sweet outside, possessive/obsessive inside |
| 😡 Tsundere | Cold outside, warm inside |
| ❄️ Kuudere | Composed outside, emotional inside |
| 🤐 Dandere | Quiet/shy outside, friendly inside |
| 👑 Himedere | Princess-like, expects royal treatment |
| Oujidere | Prince-like, expects royal treatment |
| 💖 Deredere | Sweet, always positive |
| Undere | Submissive, eager to please |
| 🦂 Mayadere | Mysterious with hidden dark side |
| Deredevil | Sweet/innocent but secretly badass |
| Underdog | Outmatched or underestimated |
| Redeemed Villain | Former villain now good |
| Fallen Hero | Former hero turned sinister |
| Enemy to Lover | Former adversary, now romantic |
| Forbidden Love | Secret or against society's rules |
| Soulmate | Bonded/destined to be together |
| Opposites Attract | Fundamentally different personalities attracted |
| Jester 🤡 | Comedic time-waster |
| Creator | Visionary perfectionist |
| Dorodere | Acts loving but secretly disgusted |
| Utsudere | Normally gloomy, lifted by love interest |
| Wandere | Golden retriever energy, cheerful |
| Hinedere | Negative at first, affectionate after love appears |
| Himbo | Strong, polite, loveable, not bright |
| Yoidere | Loves alcohol, drunkenly honest/affectionate |

---

## MATURE

| Tag | Description |
|-----|-------------|
| Graphic Violence | Extreme violence beyond typical |
| Mental Illness | Heavy depression, psychosis, disorders |
| Substances | Alcoholism, drug addiction |
| War | Extreme war depictions or trauma |
| Abuse | Domestic violence, exploitation, cruelty |
| Slavery | Forced servitude, captivity (must not glorify if based on reality) |
| Murder Hobo | Overly violent, attacks without thinking |
| Loss | Deep traumatic loss |
| Discrimination | Hate/prejudice toward groups (must not glorify if based on reality) |

---

## EXPLICIT

| Tag | Description |
|-----|-------------|
| Shameless Smut | Explicit sexual content, general signal |
| Erotic Image | Card features lewd/explicit images |
| MILF | "Mom I'd Like to Fuck" |
| DILF | "Dad I'd Like to Fuck" |
| GILF | "Grandparent I'd Like to Fuck" |
| Harem | Male surrounded by interested females |
| Reverse Harem | Female surrounded by interested males |
| Exotic Dancer | Erotic dance performer |
| Sex Work | Sexual acts for pay |
| Porn Star | Performs in adult films |
| Bondage | Restraints to restrict movement |
| Ear Play | Ear stimulation |
| Breeding | Impregnation kink |
| Impact Play | Striking body for pleasure/pain |
| Repulsion | Aroused despite disgust |
| Reluctance | Hesitant but consenting |
| Gagging | Devices to restrict speech |
| Hypnosis | Hypnotic techniques for pleasure/control |
| Scent Play | Scents/pheromones for arousal |
| Wax Play | Hot wax for sensation |
| Knife Play | Sharp objects for stimulation/fear |
| Blood Play | Blood for arousal |
| Claiming | Marking partner as owned |
| Choking | Restricting airflow |
| Discipline | Rules/punishments to control behavior |
| Domination | Exerting power/control |
| Submission | Yielding/obeying |
| Sadism | Enjoying inflicting pain |
| Masochism | Enjoying receiving pain |
| Petplay | Roleplaying as animal |
| Exhibitionism | Exposing self or public sex |
| Voyeurism | Watching others without knowledge |
| Master-Slave | Complete control dynamic |
| Role-playing | Acting out fantasies |
| Sensory Deprivation | Blindfolds, earplugs, etc. |
| Temperature Play | Hot or cold substances |
| Electro Play | Electrical stimulation |
| Humiliation | Pleasure from humiliating/being humiliated |
| Breath Play | Breathing restriction |
| Orgasm Control | Controlling/delaying orgasm |
| Degradation | Pleasure from degrading/being degraded |
| Praise Kink | Pleasure from praise |
| Fear Play | Inducing fear consensually |
| Consensual Non-Consent | Pre-negotiated "non-consent" roleplay |
| Vore | Being eaten/eating |
| Inflation | Inflating/being inflated |
| Transformation | Transforming/being transformed |
| Feet | Foot fetish |
| Cock and Ball Torture | Pain to male genitals |
| Incest | Sexual/romantic with blood relatives |
| Face Sitting | Sitting on partner's face |
| Armpits | Armpit fetish |
| Breast Milk | Lactation arousal |
| Fingering | Genital stimulation with fingers |
| Fisting | Hand insertion |
| Gloves | Glove fetish |
| Hair | Hair fetish |
| Hands | Hand fetish |
| Medical | Medical scenario arousal |
| Navel | Belly button fetish |
| Odor | Body odor arousal |
| Piercings | Piercing fetish |
| Pregnancy | Pregnancy fetish |
| Spanking | Spanking fetish |
| Sploshing | Covered in substances |
| Stomach | Stomach/abdomen fetish |
| Tattoos | Tattoo fetish |
| Teeth | Teeth fetish |
| Tickling | Tickle fetish |
| Wet and Messy | Mud, paint, food, etc. |
| Wrestling | Wrestling arousal |
| BBW | Big beautiful women attraction |
| BBC | Big black cock attraction |
| NTR | Partner stolen/seduced by third party |
| Cuckold | Watching partner with another |
| Cunnilingus | Oral sex on vagina |
| Free Use | Being used as object for gratification |
| Latex | Latex clothing/material fetish |
| Leather | Leather clothing/material fetish |
| Uniform | Uniform fetish |
| Chastity | Devices preventing sex/orgasm |
| Anal Play | Anal activities |
| Raceplay | Racial theme roleplay |
| Watersports/Piss kink | Urine fetish |
| Size Play | Size difference scenarios |
| Sissification | Feminizing male partner |
| Futanari | Both sex organs + female features |
| Pegging | Strap-on penetration by female |
| Parent Play | Parent-child dynamic roleplay |
| Tentacles | Tentacle play |
| Wholesome and Sexy | Both sexual and wholesome themes |
| Switch | Can be dominant or submissive |
| Somnophilia | Sleeping person attraction |

---

## MISCELLANEOUS

| Tag | Description |
|-----|-------------|
| Shy | Reserved, timid socially |
| 🔎 Other | Doesn't fit other categories |
| 🏡 Neighborly | Friendly, helpful |
| Energetic | Full of energy |
| Confident | Self-assured |
| Nerdy | Intellectually curious, niche interests |
| Goth | Dark, edgy aesthetic |
| Metalhead | Heavy metal enthusiast |
| Gamer | Plays video games |
| NEET | No job, no money, no independence |
| Motherly | Protective, nurturing vibes (not necessarily a mom) |
| Fatherly | Dad jokes, protective (not necessarily a dad) |
| Sisterly | Sister vibes |
| Brotherly | Brother vibes |
| Doomer | Pessimistic about future |
| Zoomer | Generation Z (1997-2012, must be 18+) |
| Boomer | Baby Boomer generation |
| Millennial | Millennial generation |
| Patriotic | Loves their country |
| Rebel | Resists authority |
| Hippie | Peace, love, harmony |
| Stoner | Enjoys marijuana |
| Nutjob | Crazy, believes conspiracies |
| Weeb | Obsessed with Japanese culture |
| Otaku | Obsessed with anime/manga |
| Brony | MLP fan |
| K-Pop | Korean pop fan |
| Raver | EDM/rave culture |
| Doormat | Submissive, easily manipulated |
| Alpha | Dominant, assertive |
| Beta | Submissive, passive |
| Omega | Submissive, passive, nurturing |
| Sigma | Independent, aloof, charismatic |
| Grump | Irritable |
| Rich | Financially secure |
| Poor | Struggles financially |
| Older | On the older side |
| Younger | On the younger side (adult) |
| Rescuer | Saves another from danger |
| Shitpost | Dumb/comedic, not serious |
| Partner | In committed romantic relationship |
| Spouse | Married |
| Best Friend | Very strong friendship |